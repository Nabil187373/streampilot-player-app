# Playback redirect validation repair — 2026-11-01

## Changes

- Enforce a configured non-empty provider hostname allowlist for initial playback hosts and redirect destinations, while preserving the documented empty-allowlist behavior for user-supplied public provider hosts.
- Keep the exact production source-hostname → public HTTP IP binding as a separate exception. It still requires an exact configured source and destination and uses a pinned dispatcher.
- Reject unbound IP-literal redirect destinations with a fixed `ip_literal_not_allowed` diagnostic. The diagnostic does not expose the IP literal, path, query, or credentials.
- Preserve explicit development-only provider-domain suffix trust and grant-scoped nested assets. Domain matching remains label-boundary-safe.
- Preserve the narrow public movie-media IP redirect path; the new generic IP-literal rejection does not override that separate compatibility path.
- Correct the playback diagnostics fixture so its simulated asset-stage test passes the required session store and its manifest bootstrap returns a valid HLS manifest.

## Verification

- Server Node test suite: 138 passed, 0 failed, 1 skipped (TLS fixture unavailable in this environment), 139 total.
- TypeScript check: `node node_modules/typescript/bin/tsc --noEmit` passed.
- Frontend Vitest suite was not run in this Linux workspace: the retained dependency archive contains Windows-native Rolldown/Vitest optional binaries, and a fresh `npm ci` did not complete here. Run `npm.cmd ci` and `npm.cmd test` on Windows before treating the whole project as fully verified.
