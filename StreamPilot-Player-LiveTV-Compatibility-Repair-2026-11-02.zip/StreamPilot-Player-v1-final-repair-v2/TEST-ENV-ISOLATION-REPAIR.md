# StreamPilot Player — Test Environment Isolation Repair

## Scope

This repair changes automated-test setup only. It does not change production connector, playback, redirect, media, or security behavior.

## Root cause reproduced

The five failures in the supplied log are reproducible when developer-shell environment variables are inherited by the Node test process:

- `ALLOW_HTTP_PROVIDER=1` makes tests intended to reject HTTP accept it.
- `PROVIDER_HOST_ALLOWLIST=provider.example` causes tests using other mock hosts to fail at the allowlist stage, before their private-address or redirect assertions run.
- `PLAYBACK_LOCAL_HOST_DIAGNOSTICS=1` plus `NODE_ENV=development` adds development-only diagnostic fields, breaking a test that expects the production-safe/minimal diagnostic shape.

In a clean environment, the same backend tests passed before the repair. With the contaminated variables, five tests failed, matching the supplied report.

## Changes

- Added `server/test-env.mjs` to clear provider/playback environment variables at the start of each backend test process.
- Imported the helper first in all backend test suites invoked by the package test script.
- Made the private-address test explicitly allow its mock hostname so it reaches the DNS/private-address check.
- Made the redirect test explicitly allow both the initial and redirect mock hostnames so it reaches redirect address validation.
- Made the HTTP opt-in test explicitly configure disabled/enabled behavior rather than relying on ambient shell state.
- Made the minimal-diagnostic assertion explicitly disable local diagnostics and restore the prior values afterward.

No production security checks were weakened. No provider credentials, real provider URLs, database settings, or migrations were added or changed.

## Verification in this workspace

Backend Node test suites were run twice:

1. Clean environment.
2. Contaminated environment with `ALLOW_HTTP_PROVIDER=1`, `PROVIDER_HOST_ALLOWLIST=provider.example`, `PLAYBACK_HOST_ALLOWLIST=cdn.example`, `NODE_ENV=development`, and `PLAYBACK_LOCAL_HOST_DIAGNOSTICS=1`.

Both runs produced identical results:

- 109 tests
- 108 passed
- 0 failed
- 1 skipped

TypeScript check: `node node_modules/typescript/bin/tsc --noEmit` passed.

## Verification limitations

- `npm ci` could not complete in this workspace because registry.npmjs.org DNS resolution returned `EAI_AGAIN`.
- The available cached `node_modules` was from a Windows installation and did not include the Linux Rolldown native binding. Therefore Vitest and the Vite production build could not be run in this Linux workspace.
- The user previously reported 32/32 frontend Vitest tests passing on Windows before this test-only change. That result has not been rerun against this repaired ZIP.
- No real provider stream or device playback was tested as part of this repair.

Run `npm.cmd ci`, `npm.cmd test`, and `npm.cmd run build` on the user's Windows machine to complete cross-platform verification.
