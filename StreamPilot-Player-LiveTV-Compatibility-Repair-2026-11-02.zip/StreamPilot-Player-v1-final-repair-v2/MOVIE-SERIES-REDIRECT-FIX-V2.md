> **Superseded configuration note (2026-11-02):** The commands below document an earlier development-only test setup. Normal customer-provider playback now supports validated public CDN hostnames and public IP redirects without adding provider hosts to `PROVIDER_HOST_ALLOWLIST` or `PLAYBACK_HOST_ALLOWLIST`. Do not set those variables to make a provider work. Keep the HTTP warning, DNS/public-address checks, per-hop validation, and pinned transport active.

# Movie and Series media redirect fix v2

## Root cause addressed

`handleMovieMediaRequest` passed `httpIpRedirectBinding: null` and `httpIpRedirectTrust: null` into `fetchValidated`. Those explicit nulls overrode the server-only local-development settings parsed by `fetchValidated`, so movie and episode media requests could never use the configured exact public-IP binding or same-port public-IP redirect trust. Live playback used the settings and therefore behaved differently.

## Change

The movie/episode media handler no longer overrides those settings with `null`. It now uses the same validated defaults as the live playback path. The wildcard same-port trust setting remains development-only. The exact `PLAYBACK_HTTP_IP_REDIRECT_BINDING=source-hostname=PUBLIC_IP` setting is now available in production as an explicit operator approval: it requires the source hostname in `PLAYBACK_HOST_ALLOWLIST`, `ALLOW_HTTP_PROVIDER=1`, the exact configured public IP, a single redirect hop, public-address validation, and a pinned destination connection. It does not trust arbitrary public IPs or redirect chains.

## Local test configuration for a provider that redirects media to a public IP on the same port

For a controlled local test, set:

```powershell
$env:ALLOW_HTTP_PROVIDER = "1"
$env:PROVIDER_HOST_ALLOWLIST = "ts.linkmac.uk"
$env:PLAYBACK_HOST_ALLOWLIST = "ts.linkmac.uk"
$env:PLAYBACK_HTTP_IP_REDIRECT_TRUST = "ts.linkmac.uk"
npm.cmd run dev
```

This permits only a one-hop HTTP redirect from the allowlisted source hostname to a public IP on the same port. It is a development-only wildcard exception. Private, loopback, link-local, reserved, and otherwise forbidden addresses remain blocked. HTTP is unencrypted and must not be used with real credentials on an untrusted network.

If a provider uses a different port for the redirect target, use the exact binding form instead, after verifying the public destination IP:

```powershell
$env:PLAYBACK_HTTP_IP_REDIRECT_BINDING = "ts.linkmac.uk=PUBLIC_IP"
```

For production, prefer HTTPS. If the provider genuinely requires an HTTP IP redirect, independently verify the exact IP and configure the exact binding instead of the wildcard trust setting. Do not add a redirect destination to a global hostname allowlist as a workaround.

## Verification

- `node --test server/media.test.mjs`: 14 passed.
- Full backend Node test suite: 104 passed, 1 skipped, 0 failed.
- `tsc --noEmit`: passed.
- Vitest frontend suite and Vite build could not be rerun in this Linux build environment because the installed dependency tree is missing Rolldown's optional native binding. The Windows project should run `npm.cmd ci`, `npm.cmd test`, and `npm.cmd run build` before use.
- Real provider playback remains to be verified on the user's machine.
