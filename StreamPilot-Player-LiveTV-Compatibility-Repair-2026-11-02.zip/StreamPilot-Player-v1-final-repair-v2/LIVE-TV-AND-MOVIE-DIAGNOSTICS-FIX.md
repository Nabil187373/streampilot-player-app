# StreamPilot Live TV and Movie Diagnostics Fix

## Changes

### Xtream Live TV activation
- The Xtream connection previously populated the Library's `items` state but did not add the imported channels to `playlistLibrary`.
- The dedicated Live TV workspace reads from `playlistLibrary`, so it displayed its empty state while Library cards could still preview channels.
- Xtream import now creates and activates a `Provider playlist` in the shared playlist library, resets favorites/selection, and opens Live TV after a successful import.
- The imported channel IDs and `playbackBlocked` flags are preserved so channel playback continues to request server-side grants.

### Movie playback diagnostics
- Movie media failures now retain a narrowly allowlisted set of local diagnostics on the session-bound movie grant.
- The diagnostic response can report stage, redirect count, rejected hostname/scheme, safe destination-rejection reason, and (only where the existing local diagnostic logic permits it) a public redirect IP and port.
- Provider URLs, paths, query strings, usernames, passwords, tokens, and raw upstream response bodies are never retained or returned.
- The movie player now displays these safe diagnostics instead of collapsing every host/redirect failure to a generic message.

## Verification performed in the build environment
- Backend Node test suite: 106 passed, 0 failed, 1 skipped.
- TypeScript `tsc --noEmit`: passed.
- JavaScript syntax checks for the modified server module: passed.
- Vitest frontend suite and Vite production build could not be run in this Linux environment because the available Rolldown installation lacks its platform-native binding. Run both on the Windows development machine with the installed project dependencies.

## Important
- This patch does not claim movie playback is fixed. It makes the movie rejection diagnosable without exposing provider secrets.
- HTTP provider compatibility and development redirect trust must remain local-only. Do not deploy these test settings or use them with credentials on an untrusted network.
