@echo off
setlocal
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed or is not on PATH.
  echo Install a current LTS release from https://nodejs.org/ and reopen this terminal.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo npm is not available on PATH. Reinstall Node.js with npm included.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing project dependencies. This requires npm registry access.
  call npm install
  if errorlevel 1 (
    echo Dependency installation failed. Check registry/DNS/network access and retry.
    pause
    exit /b 1
  )
)
call npm run dev
