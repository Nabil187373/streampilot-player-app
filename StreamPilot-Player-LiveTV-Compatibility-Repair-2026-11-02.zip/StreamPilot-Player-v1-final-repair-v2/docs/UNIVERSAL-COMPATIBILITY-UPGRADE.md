# Universal compatibility upgrade — current implementation

This upgrade is intentionally incremental. It does not claim that every provider, codec, or device is supported.

## Implemented in this revision

- A provider adapter registry now dispatches remote playlist imports between the Xtream M3U export path and generic M3U import path. The existing Xtream player API connector continues to own authenticated live/VOD/series catalogues.
- Provider entry hostnames are user-supplied and do not require a deployment allowlist by default. Every hostname is resolved and validated, and the production pinned transport connects to the validated address. Private, reserved, loopback, link-local, and metadata destinations remain blocked. The hostAllowlist setting is retained for narrowly scoped, operator-approved redirect compatibility paths rather than as a general provider allowlist.
- Normal customer-authorized Live TV, VOD, redirect, and HLS asset hosts do not require deployment-wide allowlist entries. They are independently checked for public routability and connected through validated, pinned outbound transports.
- The Live TV and VOD video elements are mounted in one persistent app-level player dock. Internal navigation no longer unmounts the active media element and destroys its HLS instance.
- HLS.js audio tracks are enumerated and can be selected. If the default advertised codec is not supported by MediaSource and an advertised AAC/MP4A track is available, the player selects that alternate track.
- Muted autoplay has a persistent, visible “Enable sound” action.
- Local and remote M3U parsers recognize underscore aliases and preserve EXTINF custom attributes, EXTGRP, EXT-VLCOPT and KODIPROP metadata. These directives are preserved as metadata and are not blindly applied as HTTP headers.
- Added registry and parser regression tests. The Node test script also includes the standalone FFmpeg utility tests.

## Known limits / next engineering phases

- The archive is a local-first prototype. Provider sessions and catalogue metadata remain in memory; no production tenant database or durable credential vault is introduced here.
- The current import bounds (40 MiB and 20,000 entries) remain deliberate until catalogue ingestion is backed by durable storage and server-side pagination. Raising them without that storage would risk memory exhaustion.
- Stalker/Ministra authentication is not implemented.
- Browser audio cannot decode every provider codec. The player can select another advertised audio track; it cannot manufacture a compatible track if the provider supplies none. FFmpeg is present as a standalone utility but is not wired into the normal playback route.
- Native HLS browsers do not expose the same audio-track controls as HLS.js in every platform.
- Public IPv4 and IPv6 redirect destinations are supported when independently validated and pinned to the exact public address. Private, loopback, link-local, reserved, and metadata destinations remain blocked; a redirect from an IP-literal destination is not followed.
- Android, Android TV, iOS, iPadOS, Tizen and webOS require their respective native packaging and playback-engine work; the current browser app does not establish native platform support.

## Validation

Run with the repository's documented Node requirement (Node.js 22.19 or newer):

```sh
npm ci
npm test
npm run build
```

Use only authorised provider test accounts and streams. Never commit provider credentials or `.env` files.
