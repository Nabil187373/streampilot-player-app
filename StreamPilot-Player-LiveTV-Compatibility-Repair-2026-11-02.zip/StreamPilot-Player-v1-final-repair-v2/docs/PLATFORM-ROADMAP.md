# Platform roadmap and exit criteria

## Phase 0 — browser foundation and secure provider playback (current)

- [x] Standalone Vite/React/TypeScript browser application
- [x] Local M3U/M3U8/TXT import and common EXTINF metadata parsing
- [x] HLS browser playback adapter (hls.js with native-HLS fallback)
- [x] Responsive browser UI, search, filters, and session-only favorites
- [x] Same-origin server-side Xtream live-channel metadata import
- [x] Xtream VOD category/item catalogue endpoints and a separate movie-media proxy route
- [x] Short-lived, session-bound playback grants for live HLS
- [ ] Complete live-grant renewal/recovery verification across hls.js and native-HLS browsers
- [ ] Series catalogue, seasons, episodes, and series playback
- [ ] Persistent playlist library and durable favorites
- [ ] Production activation API and license enforcement
- [ ] Local smoke test on the target Windows environment
- [ ] Verify provider playback against user-authorized sample sources

**Exit gate:** automated tests and production build pass; DNS-pinned provider egress and HLS URI rewriting have regression coverage; sample live HLS and Xtream movie playback are verified in supported browsers; limitations are documented.

## Phase 1 — TV web playback spike

- Create dedicated packaging workspaces for webOS and Tizen, without unexpectedly changing the browser foundation.
- Verify remote focus/navigation, app lifecycle, video playback, supported codecs, storage limits, timeout behavior, and resume behavior on simulators and real TV hardware.
- Record TV model year, OS version, stream type, and result for every test.
- Do not claim platform support based only on desktop Chrome playback.

**Exit gate:** tested proof of playback on at least one representative LG TV/webOS environment and one Samsung TV/Tizen environment, with a documented supported-model boundary.

## Phase 2 — activation backend (after explicit approval)

- Review the existing Supabase schema, Auth setup, RLS policies, and service deployments read-only.
- Design and stage API endpoints; do not edit production tables as part of an initial client spike.
- Hash/expire activation codes; enforce device limits and revocation server-side; issue revocable device/session credentials.
- Test invalid/reused/expired codes and cross-account isolation.

**Exit gate:** security review and automated tests pass in a staging environment.

## Phase 3 — complete Xtream experience

- Keep the implemented live-channel import and VOD/movie catalogue/media route separate from claims about a complete media library.
- Implement series categories, series details, seasons, episodes, and playback where the authorised provider API supports them.
- Review credential handling and playback authorization for every platform.
- Never log usernames/passwords or claim every stream type is compatible.

**Exit gate:** authorised provider test environment passes authentication, live/VOD/series listing where available, playback, cancellation, invalid-credential, network-loss, and credential-handling tests.

## Phase 4 — native clients

- Android TV + phone/tablet client, likely Kotlin/Media3 with adaptive layouts.
- iOS/iPadOS universal app, using Apple frameworks and appropriate store purchase/activation policies.
- Share API contracts, parser tests/fixtures, design tokens, and business requirements, while allowing native navigation and playback behavior.

## Phase 5 — store readiness

- Product/legal review for content rights, metadata, activation/payment model, privacy labels, and data collection disclosures.
- Create per-platform store listings, screenshots, icons, support/privacy URLs, test credentials where reviewers need them, and review instructions.
- Run hardware/device tests and platform checklists; submit only when the relevant client actually works.
- No store approval date or acceptance is guaranteed.
