# Test plan for the v1 foundation

## Automated tests

- M3U with standard `#EXTINF` metadata.
- Windows CRLF line endings and UTF-8 BOM.
- Empty playlist and malformed rows.
- Category inference for live, movies and series.

## Browser checks

- Local file import and user-readable errors.
- URL import with a CORS-denied URL to confirm the failure message is clear.
- Search, category filtering, favorites, selecting a stream and dismissing notices.
- HLS playback in Chrome/Edge; test native HLS in Safari when available.
- Narrow/mobile layout and keyboard focus visibility.
- Refresh clears in-memory prototype state as documented.
- Activation/Xtream forms explicitly state that they are nonfunctional and do not accept/send/store credentials.

## Compatibility record template

| Field | Value |
|---|---|
| Device and model year | |
| OS / firmware version | |
| App build hash | |
| Source type | M3U file / URL / authorized Xtream test |
| Media format / codec | |
| Video starts | Pass / fail |
| Remote/touch controls | Pass / fail |
| Network interruption recovery | Pass / fail |
| Memory / stability | Pass / fail |
| Notes / logs (no credentials) | |
