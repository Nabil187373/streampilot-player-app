# Architecture direction

## Principle
One product and license system, multiple platform clients. Share contracts, playlist parsing fixtures, design tokens, and business rules where practical; do not assume one playback engine or one binary can serve every platform.

## Target clients

| Target | Likely client approach | Status |
|---|---|---|
| Windows/macOS/Linux browsers | Responsive TypeScript web app with browser-supported playback | Prototype started |
| LG webOS TV | Web app package using webOS TV SDK/CLI; test target model years | Not started |
| Samsung Tizen TV | Tizen web app package; Samsung SDK/certificate/test process | Not started |
| Android TV / Google TV | Android TV application; Kotlin + Jetpack Media3 is the proposed direction | Not started |
| Android phones/tablets | Shared Android app with adaptive mobile/TV layouts, if target SDK/UX review supports one listing | Not started |
| iPhone/iPad | Universal iOS/iPadOS app with adaptive layouts and Apple media frameworks | Not started |

## Proposed service boundary

`TV/mobile/web client -> HTTPS Player API -> license/activation domain service -> reviewed persistence layer`

The API will eventually handle activation-code redemption, license status, device linking, device limits, revocation, and audit events. Provider playlists should be handled with an explicit credential strategy and should not require our backend to relay video unless a later, reviewed use case requires it.

## Data model concepts (not migrations)

- `player_licenses`: product entitlement and expiry/status.
- `activation_codes`: hashed, single-use, expiring codes, status, associated license.
- `player_devices`: server-issued device ID, platform, human-readable label, last-seen and status.
- `player_activations`: relationship between license/device, activation and revocation timestamps.
- `player_audit_events`: security-relevant admin and activation actions.

These are concepts only. Do not implement database changes until the existing schema and RLS policies have been reviewed and the user explicitly approves.

## Important boundaries

- Player app licenses and reseller/service credits are separate financial ledgers.
- A MAC address can be a support/search value only; never treat it as proof of identity.
- Client apps must never contain privileged server keys.
- Browser CORS, TV codec limitations, stream headers, codecs, DRM, and provider behavior can vary by platform; compatibility claims require a test record.


## Provider compatibility and playback lifecycle (current web prototype)

Remote playlist ingestion uses a provider-adapter registry. The current registered adapters are the generic M3U importer and Xtream M3U-export importer; authenticated Xtream API connections remain in the dedicated Xtream connector. Stalker/Ministra is not implemented.

Provider entry hostnames are user-supplied and do not require a deployment allowlist by default. Each destination is DNS-validated and outbound sockets are pinned to validated addresses; private/reserved/loopback/link-local destinations are rejected. The current hostAllowlist setting is retained for narrowly scoped, operator-approved redirect compatibility paths; it is not a general-purpose list of every allowed provider. IP-literal redirects remain denied unless the exact production binding policy is explicitly configured.

The web prototype's Live TV and VOD media elements live in one app-level persistent player dock. They are not children of route/view-specific content, so internal navigation does not unmount the active media element. HLS.js exposes alternate audio tracks where the manifest provides them; the player prefers an advertised AAC/MP4A track if its default advertised audio codec is unsupported by MediaSource. This is not a substitute for server-side transcoding, which remains a separate, unimplemented streaming feature.

Large playlist limits remain bounded (40 MiB / 20,000 entries) until durable catalogue storage and server-side pagination are implemented. Raising those limits while keeping all metadata in process memory would be unsafe.
