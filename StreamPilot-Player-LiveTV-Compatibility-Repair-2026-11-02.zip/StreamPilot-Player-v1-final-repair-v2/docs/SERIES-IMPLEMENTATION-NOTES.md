# Series catalogue implementation notes

## Implemented

- Xtream series categories are loaded on demand using `get_series_categories`.
- The selected category is loaded using `get_series`; the browser requests bounded pages from the local API.
- Selecting a show loads `get_series_info` and maps season/episode metadata.
- Episode IDs and validated container extensions stay in server-side per-session state.
- Episode playback uses an opaque short-lived media grant and the existing protected `/media/<grant>` route.
- Movie and episode grants carry an explicit media kind to avoid ID collisions.
- Local and remote M3U entries are classified as series when their group/title indicates series/season/episode or contains common labels such as `S01E02` and `1x02`.

## Compatibility boundaries

- Xtream provider responses vary. The implementation expects the common `get_series_categories`, `get_series`, and `get_series_info` response shapes.
- M3U has no universal structured season/episode schema. M3U series items are therefore a flat list, not a guaranteed show/season hierarchy.
- Provider playback hosts still need to satisfy the configured playback host allowlist and existing network safety rules.
- Browser playback still depends on browser-supported media codecs. Audio transcoding is not included in this series change.

## Verification

- `node --test server/connector.test.mjs server/api.test.mjs`: 36 passed, 0 failed.
- `node --check` passed for the changed server modules.
- Full Vite/TypeScript build could not be verified in the supplied inspection environment because its installed dependency/type-definition tree is incomplete (`TS2688` for chai, deep-eql, estree, react, and react-dom). Re-run `npm ci`, `npm test`, and `npm run build` on the Windows development machine before treating the UI as release-ready.
