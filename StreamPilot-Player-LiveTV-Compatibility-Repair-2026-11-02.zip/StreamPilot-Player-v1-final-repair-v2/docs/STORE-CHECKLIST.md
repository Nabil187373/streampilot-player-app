# Store readiness — future checklist

This is not a submission pack and does not imply approval. Re-check the platform rules before submission.

## Shared
- [ ] Final app name, icon and brand assets
- [ ] Tested feature list and known limitations
- [ ] Privacy policy and support contact published on a stable domain
- [ ] Content rights statement and no bundled unauthorized catalogue
- [ ] Data collection and credential-handling disclosures accurate
- [ ] Error states and offline behavior reviewed
- [ ] QA evidence, test instructions and platform/model coverage

## LG webOS
- [ ] webOS TV SDK/CLI and simulator installed
- [ ] Package metadata, app ID, icons and launch assets verified
- [ ] TV remote/focus behavior and supported media APIs tested
- [ ] Seller Lounge submission/self-checklist completed

## Samsung Tizen
- [ ] Tizen Studio/TV extensions configured
- [ ] Developer signing certificate profile created and backed up securely
- [ ] App package and config tested on emulator and target TV
- [ ] Remote/focus behavior, codecs and lifecycle tested
- [ ] Seller Office pretest/certification steps completed

## Android / Google Play
- [ ] Android TV and mobile layout/configuration checked separately
- [ ] Media3 codec/network behavior tested on representative devices
- [ ] Signing key stored safely; Android App Bundle reproducible
- [ ] Play store listing, screenshots, privacy/data-safety declarations complete
- [ ] TV quality requirements and current Play policy checks completed

## Apple App Store
- [ ] Universal iPhone/iPad layouts and supported OS baseline decided
- [ ] Playback framework, background behavior and external display policy tested
- [ ] Signing/certificates and App Store Connect metadata configured
- [ ] Privacy nutrition label, account/sign-in requirements, payments/activation, and current review rules checked
