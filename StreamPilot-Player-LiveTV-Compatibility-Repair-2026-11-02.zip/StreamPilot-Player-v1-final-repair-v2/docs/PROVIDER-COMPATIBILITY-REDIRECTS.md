# Provider compatibility and public-IP redirects

## Goal

Customers can import their own authorised M3U/M3U8 or Xtream provider and watch channels without manually configuring each provider or CDN hostname. A provider may use different live, VOD, CDN, and edge destinations, including public IP-literal redirect targets.

## Supported destination behavior

- Public DNS hostnames are resolved and every returned address is checked. Mixed or unsafe DNS answers are rejected.
- Public IPv4 and IPv6 literals are supported as initial destinations and as redirect destinations.
- A hostname may redirect to another public hostname or to a public IP literal.
- Public IP redirect targets are connected through a dispatcher pinned to the exact validated address; DNS is not consulted for the literal. The provider-selected port is preserved.
- Redirects are followed manually and bounded by the existing redirect limit. Once a request reaches an IP literal, that IP response may not redirect again.
- HTTP is supported when the app's HTTP compatibility confirmation/policy permits it. HTTPS retains normal certificate validation; an HTTPS IP literal must present a certificate valid for that IP.
- HLS manifest rewriting keeps upstream URLs and credentials server-side and routes nested playlists, segments, maps, and keys through session-bound opaque asset paths.

## Security requirements retained

- Reject loopback, private, link-local, carrier-grade NAT, reserved, benchmark, multicast, unspecified, and metadata-service destinations.
- Resolve DNS at each hostname hop, reject unsafe answers, and pin the outbound socket to a validated address to prevent a second untrusted lookup at connect time.
- Reject URL userinfo and fragments. Do not forward provider credentials or authorization headers to unrelated redirect origins.
- Reject redirect chains originating from an IP literal. Keep request timeouts, response-size limits, redirect limits, session/grant binding, rate limiting, and no-store behavior.
- Never return provider URLs, stream URLs, tokens, or credentials to browser state or diagnostics.
- Keep StreamPilot's own authorised stream-node/origin-protection redirect feature separate from customer-provider playback.

## Allowlist configuration

The normal customer-provider path does not require `PROVIDER_HOST_ALLOWLIST` or `PLAYBACK_HOST_ALLOWLIST`, and these legacy variables do not act as blanket allow/deny gates for ordinary user-authorized provider hosts, CDN redirects, or HLS assets. Leave them unset; do not add customer domains as a workaround. They are consulted only by narrow development-only compatibility exceptions. The production exact source-to-public-IP binding, when deliberately configured, is a separate explicit operator decision and is not required for ordinary public IP redirects.

## HTTP and 403 responses

HTTP does not encrypt playlist credentials or media traffic. The UI must retain its explicit user warning/confirmation for HTTP-only providers; HTTPS is preferred. A 403 is an upstream authorization/policy response, not a hostname-validation failure. Diagnose it separately (provider account/stream entitlement, required provider headers, source-IP restrictions, expired links, or provider-side anti-bot policy). Do not blindly retry, spoof arbitrary headers, or expose upstream response bodies/credentials.

## Regression coverage

`server/playback.test.mjs` covers automatic public IPv4 and IPv6 redirect support without deployment bindings, pinned dispatch, arbitrary public ports, private/reserved destination rejection, one-hop behavior, session-bound assets, and safe diagnostics. `server/media.test.mjs` covers the equivalent VOD/media path.
