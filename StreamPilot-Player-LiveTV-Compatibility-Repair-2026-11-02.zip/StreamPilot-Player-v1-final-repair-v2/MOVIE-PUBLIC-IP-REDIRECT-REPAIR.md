# StreamPilot Player — movie redirect compatibility repair

This build includes a targeted server-side fix for movie playback providers that redirect
authorized media requests from a public provider hostname to a public IP literal.

Safety properties:
- Initial provider hostnames and every redirect destination are resolved/validated.
- Private, loopback, link-local, reserved and otherwise forbidden addresses remain blocked.
- The accepted movie IP redirect is limited to GET/HEAD media requests, HTTP, and port 80
  or the original provider port.
- The destination IP is pinned in the outbound dispatcher; the hostname is not treated as
  a DNS name and is not re-resolved during the socket connection.
- An IP-literal destination cannot issue another redirect, so the compatibility path is
  one hop only.
- No provider credentials are forwarded as authorization headers to the redirect host.
- No per-provider IP binding or allowlist environment variable is required for this case.

Also fixed the unused `Maximize2` import that prevented TypeScript compilation.

Verification performed in the build environment:
- TypeScript `tsc --noEmit`: passed.
- Focused playback tests for development and production public-IP movie redirects: 2 passed.
- The full test suite could not be fully validated in this Linux environment because the
  uploaded dependency tree is Windows-built and the available Node runtime is 22.16.0
  (the project requires >=22.19.0). Do not interpret this as a full end-to-end provider
  playback certification. Your Windows Node 24 environment is the intended runtime.

No `.env`, provider credentials, `node_modules`, or `dist` output is included.
