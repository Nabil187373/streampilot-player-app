# StreamPilot Player — v1 foundation

A standalone, local-first proof of concept for the StreamPilot Player ecosystem. This repository is separate from all StreamPilot website, reseller-panel, and Supabase projects.

## What works in this foundation

- Responsive StreamPilot Player interface for desktop and mobile browser widths.
- Import local `.m3u`, `.m3u8`, or `.txt` playlist files.
- Parse common `#EXTINF` metadata, underscore aliases, `#EXTGRP`, `#EXTVLCOPT`, and `#KODIPROP`; preserve unknown EXTINF attributes as metadata rather than treating them as trusted network headers.
- Same-origin server-side Xtream live-channel metadata connector with outbound-request safeguards.
- Xtream VOD category/item catalogue endpoints and a separate server-side movie-media proxy route.
- HLS playback via `hls.js` where supported, with native HLS playback used when the browser supports it.
- A persistent, app-level playback dock that keeps Live TV, movie, and episode media elements mounted while navigating between internal views.
- HLS.js audio-track discovery and selection, with automatic preference for a browser-supported AAC track when the default advertised audio codec is unsupported.
- Provider adapter registry for remote M3U and Xtream-export playlist detection; Xtream API catalogue support remains implemented by the existing Xtream connector.
- Search imported entries, filter by library/live/movies/series/favorites, and mark favorites during the current session.
- A public HLS test stream for basic playback checks.
- Structured Xtream server URL, username, and password form. Credentials are used only for the active request and are not persisted.
- Basic M3U parser tests.

## Provider compatibility and network policy

Customer-authorized provider and CDN hostnames do not need deployment-wide allowlist entries. Normal playlist imports, initial Live TV streams, redirects, VOD media, and HLS assets are authorized by the provider URL or item held in the server-side session, then independently checked for valid HTTP(S) scheme, DNS answers, public routability, redirect limits, and pinned outbound connections. The legacy `PROVIDER_HOST_ALLOWLIST` and `PLAYBACK_HOST_ALLOWLIST` variables are not general hostname gates in this compatibility path; they are used only by narrow, explicitly enabled development compatibility exceptions. Private, loopback, link-local, reserved, and metadata-service destinations remain blocked.

The adapter registry currently dispatches remote M3U and Xtream-export playlist imports. Xtream account connections use the existing player API connector. Stalker/Ministra is not implemented yet and is not advertised as supported. The web player does not guarantee support for every codec or protocol; audio track selection can choose an alternate advertised track, but it cannot create an AAC track when the provider supplies only an unsupported codec. Server-side transcoding is not yet wired into normal playback. The Xtream Live URL builder currently requests the `.m3u8` live endpoint; providers that require a different live transport path still need provider-specific verification and are not yet certified.

## What is not implemented yet

This is **not** a production release or a store-ready app. It has no production activation API, license enforcement, secure credential store, account system, cloud sync, parental control, or native platform packaging. Authorised live HLS playback uses short-lived, in-memory sessions and same-origin proxy routes. Xtream VOD catalogue browsing, a protected movie-media route, and lazy Xtream series/episode browsing with protected episode playback are implemented. Local M3U movie/series entries are not a complete VOD/series playback implementation. The demo stream is sample media, not a bundled channel service. The app does not supply TV, movie, or series content.

## Run on Windows

Prerequisite: Node.js 22.19+ and npm, matching current Vite requirements.

1. Extract the ZIP to a folder such as `C:\Projects\StreamPilot-Player-v1`.
2. Open that folder in VS Code or Codex.
3. Open a terminal in the project folder and run:

   ```powershell
   npm install
   npm run dev
   ```

4. Open the local URL printed by the Node/Vite development server (normally `http://127.0.0.1:5173`).
5. To validate a production build, run `npm run build`. To run parser tests, run `npm test`.

### Restarting the correct development server

The connector is served by `node server/index.mjs --dev`, which is what `npm run dev` now starts. If an older plain Vite server is already running, stop that one first with `Ctrl+C`; do not run a second dev server alongside it. Then run `npm run dev` once and open the printed `127.0.0.1` URL. A plain `vite` process does not expose `/api/playlist/xtream`.

### HTTP and HTTPS provider connections

The current local prototype accepts both HTTP and HTTPS provider URLs. The Xtream and remote-playlist forms ask for confirmation before sending a request to an HTTP endpoint because HTTP does not encrypt credentials, playlist contents, or media traffic. Prefer HTTPS whenever the provider offers it; never change an HTTPS endpoint to HTTP as a workaround.

The HTTP confirmation is a user-facing risk warning, not a security upgrade. Server-side destination validation, DNS checks, pinned outbound connections, content-size limits, and redirect validation remain active for both schemes. The connector's `allowHttp` option can be set to `false` by a deployment integration, but this repository does not currently implement an `ALLOW_HTTP_PROVIDER` environment-variable switch.

Provider entry hostnames and public CDN hostnames do not need to be hardcoded in deployment allowlists. Public DNS hostnames and public IP-literal redirect destinations are validated at connection time. A hostname-to-public-IPv4/IPv6 redirect is supported without a deployment-specific IP binding and is connected through an exact-address pinned dispatcher. Private, loopback, link-local, reserved, and metadata-service destinations remain blocked; redirects from an IP literal are not followed, preventing redirect chains. Every HLS asset is validated and pinned independently.

`PLAYBACK_PROVIDER_DOMAIN_TRUST` is a development-only compatibility mechanism, not the production redirect architecture. Do not rely on it for production CDN support. Production redirect handling must remain grant-scoped, validate every destination, pin the validated address, enforce redirect limits, and avoid forwarding provider credentials across origins.

### Current IPTV format boundaries

The current browser prototype supports M3U/M3U8 imports, Xtream Codes API catalogue access, HLS playback, and browser-native formats that the device can decode. The Stalker/Ministra portal protocol is not implemented. RTSP, RTMP, UDP multicast, DRM-protected streams, and arbitrary proprietary protocols are not guaranteed by the browser player. Native platform clients and a reviewed server-side media/transcoding pipeline are separate future engineering work.

### Large provider playlists and timeouts

The connector streams M3U metadata instead of buffering a whole response, accepts at most 40 MiB of provider data and 20,000 entries, and cancels the upstream response at that entry cap. Provider imports and playback use DNS-validated, socket-pinned outbound transports; redirects are independently validated and pinned. Crossing 40 MiB is a `playlist_too_large` error; reaching 20,000 valid entries is a successful response with `entryLimitReached`, because further entries are intentionally not read. The default 20-second provider-connector deadline covers each outbound request and its response body; each of at most three validated redirect hops receives a fresh bounded deadline. A local operator may set `PROVIDER_REQUEST_TIMEOUT_MS` to an integer from 5,000 to 60,000 for an authorised provider with a known slower response time; invalid or unbounded values fall back to 20 seconds. This is not a retry mechanism and does not relax destination validation.

The local M3U parser preserves commas in channel titles, accepts double- or single-quoted common attributes, and applies `#EXTGRP` grouping metadata. `#EXTVLCOPT` transport-specific options are currently ignored; provider-specific authentication headers are not inferred or replayed. The UI renders playlist entries in small pages rather than mounting every imported channel card. Local file import has the same 40 MiB in-memory ceiling and 20,000-entry cap. Timeout errors safely identify either `network` (no usable provider response before the deadline) or `playlist_stream` (the response body stalled or aborted); they never include the playlist URL or credentials.

### Local secure HLS playback (Phase 1)

Provider playback accepts customer-supplied public provider/CDN hosts by default. `PLAYBACK_HOST_ALLOWLIST` is not a general restriction on customer-authorized provider or CDN hostnames in the normal playback path. Do not populate it to make a provider work. The legacy variable is only consulted by narrow development-only compatibility exceptions documented below. The UI asks customers to confirm an HTTP-only connection because HTTP does not encrypt credentials or media traffic; HTTPS is preferred. Live playback supports HLS. Xtream VOD catalogue browsing, a direct movie-media proxy, and Xtream series/episode browsing with protected episode playback are present. Audio transcoding is not implemented. RTSP, RTMP, UDP, and arbitrary media protocols are not supported by the browser playback path.

The playlist server, live-stream server, and CDN can legitimately use different hostnames or public IP addresses. Public CDN hostnames and public IP-literal redirect destinations are validated and pinned automatically, without a deployment-wide allowlist or a stable DNS requirement for an IP redirect. Every redirect and HLS asset is validated again. Public IP redirects preserve the provider-selected port, are pinned to the exact address, and are limited to one hostname-to-IP hop; redirects from an IP-literal destination are not followed.

Successful provider import creates a short-lived, HttpOnly, `SameSite=Strict` in-memory browser session. Playback grants are opaque, short-lived, bound to that session and one live item, and use same-origin proxy paths. Provider URLs and credentials never enter the browser state. The server clears expired session state regularly and all proxy responses use `Cache-Control: no-store`. In a HTTPS deployment, start the server with `NODE_ENV=production` (or explicitly set secure-cookie handling in deployment) so the session cookie has the `Secure` attribute. The local HTTP development server intentionally cannot use a `Secure` cookie.

Playback failures show only one of these fixed categories when the proxy can identify the stage: `session_expired`, `grant_rejected`, `host_not_allowed`, `upstream_unreachable`, `redirect_rejected`, `manifest_invalid`, `asset_rejected`, or `media_codec_error`. Any unexpected response remains a generic browser playback error. Categories never include provider hostnames, URLs, credentials, grants, query strings, response bodies, or raw exception text.

For a local troubleshooting session only, set `PLAYBACK_LOCAL_HOST_DIAGNOSTICS=1` before starting the server. When—and only when—`NODE_ENV` is not `production`, a `host_not_allowed` message may additionally show a validated DNS hostname, normalized scheme (`http` or `https`), whether the browser request was the initial `manifest` or a rewritten HLS `asset`, a bounded redirect count (0–3), one fixed stage such as `initial_live_stream`, `nested_playlist`, `segment`, `key`, `map`, or `redirect`, and one fixed validation result such as DNS resolution failed or a resolved private/reserved address. It never shows a port, path, query string, credentials, token, IP address, or raw upstream error, and it is not logged or sent to production clients. Do not use this setting in deployment.

If `npm install` fails because of DNS or registry access, resolve the npm network issue before debugging the app itself. Do not copy dependencies from unrelated websites.

## First test checklist

1. Open the app in a current Chrome or Edge browser.
2. Select **Import playlist** and choose an authorized M3U/M3U8 file.
3. Verify entries, categories, logos (if URLs are valid), search, and favorites.
4. Select an HLS-compatible local-file entry and test playback. Browser codecs, CORS, provider headers, geoblocking, and network policy may prevent an individual stream from playing.
5. Select **Load public HLS test stream** to test the player independently of a customer's provider.
6. Open **Connect Xtream** and use an authorised provider only. The connector imports live-channel metadata; separate lazy Xtream endpoints load movie and series categories, selected catalogue items, and episode metadata. Provider stream URLs and credentials stay server-side; the browser receives opaque playback grants.
7. Run `npm test` and `npm run build`.

## Data and security notes

- Imported entries are held in React memory. Refreshing clears the in-memory playlist and favorites.
- Direct browser playlist URL import has been removed. Browser CORS is not bypassed and no third-party proxy is used.
- The Xtream connector is same-origin and server-side. It rejects loopback, private, link-local, carrier-grade NAT, benchmark, and internal DNS destinations; validates DNS before each outbound request and redirect; follows at most three validated redirects; limits request body size, response content types, and request duration (20 seconds by default); and applies an in-memory per-IP limit of 10 playlist imports per minute per import endpoint. Authenticated catalogue and playback-grant operations use a separate session-scoped limit.
- Provider M3U data is parsed as a stream, never collected as one unbounded response. The connector applies a 40 MiB transport cap, 64 KiB per-line cap, and 20,000-entry cap. It cancels the provider response once 20,000 entries have been safely extracted, returns only metadata (never stream URLs), and reports that the entry cap was reached rather than claiming that a larger list was definitely truncated. These are deliberate separate limits, not an unlimited increase to the previous 3 MiB whole-response buffer.
- If the 20,000-entry cap is reached, use the provider's own package/category controls to request a smaller authorized playlist, then import that list. The connector does not guess provider-specific category endpoints or use credentials to make unrequested API calls.
- The connector API always responds with JSON (`ok: true` or `ok: false` plus a safe error code). The browser validates status, content type, empty bodies, and JSON before displaying an allowlisted message. It does not display raw provider responses or stack traces.
- Safe diagnostic categories include provider HTTP status errors, HTML response, JSON response, and unreadable/unknown response. Only the category and a numeric provider HTTP status (when present) reach the UI; playlist URLs, credentials, response bodies, and stack traces do not.
- Provider credentials are not logged, persisted, returned to the browser, or placed in stream URLs returned by the connector. The browser receives metadata only. Secure provider playback uses server-issued, short-lived, session-bound grants and same-origin proxy routes; this prototype remains in-memory and is not a production licensing or account system.
- HTTP and HTTPS provider URLs are supported by this prototype. The UI requires an explicit confirmation before connecting to HTTP-only providers because credentials, playlist contents, and media traffic are unencrypted. Prefer HTTPS whenever available. Server-side destination validation, redirect checks, and pinned outbound connections remain active for both schemes.
- Do not use `PROVIDER_HOST_ALLOWLIST` as a way to enable ordinary customer providers; normal provider import validates public destination addresses and pins outbound connections without a global hostname list. Do not place customer credentials in environment variables.
- The in-memory rate limiter resets on restart and is not sufficient for multi-instance deployment. Production deployment needs a shared limiter, network egress policy/firewall, TLS termination, server monitoring with secret redaction, and a threat-model review.
- Do not use production license codes or personal credentials in the activation mock.
- No existing StreamPilot website, deployment, domain, or database is required to run this project.

## Scope

This repo starts with a browser playback/playlist feasibility spike. The browser UI can later inform the desktop web player and TV web UI, but webOS/Tizen playback behavior must be verified on their SDKs/simulators and real TVs. Android and iOS require native clients or platform-specific projects; this web prototype does not claim to be those apps.

## Series catalogue support

Xtream connections expose a lazy series catalogue alongside the existing live and movie metadata paths. The app requests `get_series_categories`, loads only the selected category through `get_series`, then requests `get_series_info` for the selected show to display seasons and episodes. Episode media IDs and container extensions remain in server-side session state; the browser receives an opaque, short-lived media grant and playback uses the existing protected `/media/<grant>` route. The implementation does not download or import the provider's entire series library at connection time.

M3U playlists are classified as series when their group/title explicitly indicates series, seasons or episodes, or when common season/episode patterns such as `S01E02` and `1x02` appear. M3U sources do not have a universal structured series/season schema, so those entries are shown as a flat series list rather than a guaranteed season/episode hierarchy. Structured seasons and episodes currently depend on Xtream `get_series_info` responses.
