# Xtream Live API timeout diagnostics

This update adds a bounded, allowlisted `importAction` diagnostic to Xtream Live API timeout errors.

When a request times out while reading a JSON response, the connector can now report one of:

- `get_live_categories`
- `get_live_streams`

The action label is a fixed enum. No provider URL, username, password, query string, response body, or arbitrary upstream text is returned to the browser.

The development server startup line now prints the effective provider request timeout. The setting is read when the server starts, so changing the environment variable requires stopping and restarting the server in the same PowerShell window.

Default timeout: 20,000 ms. Supported range: 5,000–60,000 ms.

This diagnostic does not make a slow provider faster. It distinguishes which API request stalls so the next fix can target the actual endpoint. It also does not establish that a provider supports Xtream Codes; the provider must confirm the API path and authentication format.

## Verification in this workspace

- TypeScript: passed (`tsc --noEmit`).
- Backend Node tests: 108 passed, 0 failed, 1 skipped (local certificate fixture unavailable).
- Vitest and Vite build could not run in this Linux workspace because the ZIP contains Windows-installed dependencies and the Rolldown Linux native binding is unavailable. Re-run `npm.cmd ci`, `npm.cmd test`, and `npm.cmd run build` on Windows.
