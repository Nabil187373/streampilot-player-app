> **Superseded configuration note (2026-11-02):** The provider-specific allowlist commands below are historical and are no longer required. Normal customer-authorized provider/CDN destinations are validated and pinned without deployment-wide hostname allowlists. Do not add provider hosts to these environment variables as a compatibility workaround.

# Movie and Series playback redirect fix

This patch makes the direct movie/episode proxy use the same provider-domain redirect validation and pinned destination dispatcher as Live TV playback. The redirect exception remains development-only; the normal URL, DNS, public-address, scheme, and redirect-count checks remain active.

For the currently diagnosed local provider, after confirming the provider is authorised and accepting the HTTP credential-exposure risk, start the local server in PowerShell with:

```powershell
$env:ALLOW_HTTP_PROVIDER = "1"
$env:PROVIDER_HOST_ALLOWLIST = "linksansa.sbs"
$env:PLAYBACK_HOST_ALLOWLIST = "linksansa.sbs"
$env:PLAYBACK_PROVIDER_DOMAIN_TRUST = "linksansa.sbs=.1700.info"
$env:PLAYBACK_LOCAL_HOST_DIAGNOSTICS = "1"
npm.cmd run dev
```

The `.1700.info` suffix is only eligible as a redirect destination when the redirect comes from the exact configured `linksansa.sbs` source hostname. It is not added to the global allowlist, and unrelated domains or private/reserved addresses remain rejected. The exception is disabled in production. HTTP remains unencrypted and can expose provider credentials; use only on a trusted network and prefer HTTPS whenever the provider supports it.

Movies and series episodes share the `/media/:grant` handler, so this fixes both media types at the same server-side playback path. `server/media.test.mjs` includes a regression test for a provider-to-CDN redirect and verifies the destination dispatcher is used.

Validation performed in this build environment: all 102 backend Node tests passed; one platform-specific TLS certificate fixture test was skipped because the local X.509 fixture was unavailable. TypeScript `tsc --noEmit` passed. Vitest and Vite production build could not be run here because the preinstalled dependency tree is missing the platform-specific Rolldown native binding. Run `npm.cmd test` and `npm.cmd run build` on the Windows development machine after `npm.cmd ci` (Node >=22.19.0).
