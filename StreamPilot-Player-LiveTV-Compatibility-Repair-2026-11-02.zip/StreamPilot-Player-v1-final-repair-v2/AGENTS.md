# StreamPilot Player — engineering guardrails

## Scope protection
- Work only inside this StreamPilot Player project.
- Do not edit StreamPilot marketing sites, reseller panels, unrelated ZIPs, or other workspace projects.
- Do not connect to or mutate Supabase, DNS, hosting, billing, developer-console accounts, or app stores without explicit user authorization.
- Preserve working functionality; make small, reviewable changes and record exactly what was verified.

## Product decisions
- Product: StreamPilot Player.
- Target client roadmap: desktop/laptop browsers, Android phones/tablets/TV, iPhone/iPad, Samsung Tizen, and LG webOS.
- Current provider formats: M3U/M3U8 and Xtream Codes API. Stalker/Ministra is not implemented in this revision.
- Users supply their own playlists or credentials for content they are authorized to access. Do not bundle or imply licensing rights to channels or video catalogs.
- Keep Player app-license accounting separate from reseller/service credits.

## Security constraints
- Never put Supabase service-role keys or other server secrets in client apps.
- Never fake successful activation or claim a code/device was validated without a real server response.
- Keep provider credentials out of logs, analytics, browser state, and public diagnostics.
- Do not persist provider passwords until a reviewed per-platform secure-storage design exists.
- Enforce activation limits, expiry, device ownership, and revocation server-side when the activation service is implemented.
- A MAC address is not an authentication credential. Use server-issued, revocable device/session identifiers.
- Preserve DNS validation, pinned outbound connections, private/reserved-address rejection, redirect limits, and credential isolation.
- Do not create an unrestricted proxy or access provider content without authorization.
- HTTP is supported by the current prototype but is unencrypted. The UI must warn and obtain user confirmation before connecting over HTTP; HTTPS is preferred.
- Provider redirect handling and StreamPilot-owned authorized stream-node redirects are separate security domains. Never reuse local-development exceptions as the production design.

## Verified implementation status at 2026-10-31
- React/Vite/TypeScript browser app and Node API server are present.
- Local M3U parsing and remote M3U import are present.
- Xtream live import, VOD catalogue browsing, series/episode catalogue browsing, and protected movie/episode media routes are present in source.
- HLS.js playback, native HLS fallback, persistent app-level player elements, and HLS.js audio-track selection are present.
- Provider entry hosts are user-supplied and validated; they do not require a hardcoded deployment allowlist by default.
- Provider sessions and catalogues are in-memory in this prototype.
- Production activation/licensing, durable customer accounts, secure credential vault, cloud sync, native packaging, platform certification, Stalker/Ministra, and normal-playback FFmpeg transcoding are not implemented.
- Browser playback against the user's providers and all target-device compatibility remain unverified.

## Engineering workflow
1. Inspect the current source and relevant tests before editing.
2. Identify the exact failing stage; do not infer a redirect failure from a generic UI category.
3. Add a regression test for every behavior change where practical.
4. Run focused tests, full tests, TypeScript checks, and production build when the environment supports them.
5. Record environment limitations and test failures honestly; never label an unrun or blocked test as passed.
6. Never modify hosted databases or apply migrations without explicit user approval.
