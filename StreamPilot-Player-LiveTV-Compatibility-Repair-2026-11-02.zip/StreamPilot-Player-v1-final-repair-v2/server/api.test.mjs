import './test-env.mjs';
import assert from 'node:assert/strict';
import test from 'node:test';
import { PassThrough } from 'node:stream';
import { createApiHandler, MovieGrantStore } from './api.mjs';
import { PlaybackSessions } from './playback.mjs';

function request(body, contentType = 'application/json', path = '/api/playlist/xtream') { const req = new PassThrough(); req.method = 'POST'; req.url = path; req.headers = { 'content-type': contentType }; req.socket = { remoteAddress: `198.51.100.${Math.floor(Math.random() * 200) + 1}` }; req.end(body); return req; }
function response() { const res = new PassThrough(); res.status = 0; res.headers = {}; res.writeHead = (status, headers) => { res.status = status; res.headers = headers; return res; }; return res; }
async function payloadFor(handler, req) { const res = response(); const output = []; res.on('data', (chunk) => output.push(chunk)); await handler(req, res); return { res, payload: JSON.parse(Buffer.concat(output).toString()) }; }

test('API import throttling does not exhaust normal playback grants for the same local client', async () => {
  const handler = createApiHandler({
    lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    fetchImpl: async () => new Response('#EXTM3U\n#EXTINF:-1,Channel\nhttps://cdn.example/live.m3u8\n'),
  });
  const clientIp = '203.0.113.77';
  const importedRequest = request(JSON.stringify({ playlistUrl: 'https://provider.example/list.m3u' }), 'application/json', '/api/playlist/remote');
  importedRequest.socket.remoteAddress = clientIp;
  const imported = await payloadFor(handler, importedRequest);
  assert.equal(imported.res.status, 200);
  const cookie = imported.res.headers['set-cookie'];

  for (let index = 0; index < 12; index += 1) {
    const grantRequest = request(JSON.stringify({ itemId: 'provider-0' }), 'application/json', '/api/playback/grants');
    grantRequest.headers.cookie = cookie;
    grantRequest.socket.remoteAddress = clientIp;
    const grant = await payloadFor(handler, grantRequest);
    assert.equal(grant.res.status, 200, `grant request ${index + 1} should not share the playlist-import rate-limit bucket`);
  }
});


test('API renews an expired live playback grant without requiring playlist re-import', async () => {
  let now = 0;
  const sessions = new PlaybackSessions({ now: () => now });
  const handler = createApiHandler({
    sessions,
    lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    fetchImpl: async () => new Response('#EXTM3U\n#EXTINF:-1,News\nhttps://cdn.example/live.m3u8\n'),
  });
  const imported = await payloadFor(handler, request(JSON.stringify({ playlistUrl: 'https://provider.example/list.m3u' }), 'application/json', '/api/playlist/remote'));
  const cookie = imported.res.headers['set-cookie'];
  const sessionId = cookie.match(/sp_playback_session=([^;]+)/)?.[1];
  assert.ok(sessionId);
  const grantReq = request(JSON.stringify({ itemId: 'provider-0' }), 'application/json', '/api/playback/grants'); grantReq.headers.cookie = cookie;
  const grant = await payloadFor(handler, grantReq);
  const grantId = grant.payload.manifestPath.match(/^\/api\/playback\/([^/]+)\//)?.[1];
  assert.ok(grantId);
  now = 5 * 60_000 + 1;
  const renewReq = request(JSON.stringify({ grantId }), 'application/json', '/api/playback/grants/renew'); renewReq.headers.cookie = cookie;
  const renewed = await payloadFor(handler, renewReq);
  assert.equal(renewed.res.status, 200);
  assert.match(renewed.payload.manifestPath, /^\/api\/playback\/[A-Za-z0-9_-]+\/manifest\.m3u8$/);
  assert.notEqual(renewed.payload.manifestPath, grant.payload.manifestPath);
  assert.match(renewed.res.headers['set-cookie'], /HttpOnly/);
});

test('movie grants retain only safe local playback diagnostics for the session-bound diagnostic route', () => {
  const store = new MovieGrantStore();
  const sessionId = 'session-test';
  const grantId = store.issue(sessionId, 'movie-42');
  store.setFailure(sessionId, grantId, 'host_not_allowed', {
    playbackStage: 'redirect', requestPhase: 'media', redirectCount: 1,
    rejectedHostname: 'cdn.example.test', rejectedScheme: 'http',
    destinationRejection: 'hostname_not_allowlisted',
    upstreamUrl: 'http://cdn.example.test/movie/user/private-password/42.mp4?token=secret',
    raw: 'credential-bearing response',
  });
  assert.equal(store.getFailure(sessionId, grantId), 'host_not_allowed');
  assert.deepEqual(store.getDiagnostic(sessionId, grantId), {
    stage: 'redirect', requestPhase: 'asset', redirectCount: 1,
    rejectedHostname: 'cdn.example.test', rejectedScheme: 'http',
    destinationRejection: 'hostname_not_allowlisted',
  });
  assert.equal(JSON.stringify(store.getDiagnostic(sessionId, grantId)).includes('secret'), false);
  assert.equal(JSON.stringify(store.getDiagnostic(sessionId, grantId)).includes('private-password'), false);
});

test('API emits a JSON error contract for malformed JSON', async () => {
  const handler = createApiHandler({ lookup: async () => [{ address: '93.184.216.34', family: 4 }] });
  const req = request('{bad json'); const res = response(); const output = []; res.on('data', (chunk) => output.push(chunk));
  await handler(req, res);
  const payload = JSON.parse(Buffer.concat(output).toString());
  assert.equal(res.status, 400); assert.equal(res.headers['content-type'], 'application/json; charset=utf-8'); assert.deepEqual(payload, { ok: false, error: { code: 'invalid_request' } });
});

test('API Xtream connection imports player API metadata and enables server-held VOD and series catalogues', async () => {
  const actions = [];
  const handler = createApiHandler({
    allowHttp: true, hostAllowlist: ['provider.example'],
    lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    fetchImpl: async (url) => {
      const parsed = new URL(url); const action = parsed.searchParams.get('action'); actions.push(action);
      if (action === 'get_live_categories') return new Response(JSON.stringify([{ category_id: '1', category_name: 'News' }]), { headers: { 'content-type': 'application/json' } });
      if (action === 'get_live_streams') return new Response(JSON.stringify([{ stream_id: 1, name: 'Example News', category_id: '1' }]), { headers: { 'content-type': 'application/json' } });
      throw new Error('unexpected action');
    },
  });
  const req = request(JSON.stringify({ serverUrl: 'http://provider.example:2086', username: 'test-user', password: 'test-password' }));
  const res = response(); const output = []; res.on('data', (chunk) => output.push(chunk));
  await handler(req, res);
  const payload = JSON.parse(Buffer.concat(output).toString());
  assert.deepEqual(actions, ['get_live_categories', 'get_live_streams']);
  assert.equal(res.status, 200);
  assert.equal(payload.ok, true);
  assert.deepEqual(payload.items, [{ id: 'provider-0', name: 'Example News', group: 'News', kind: 'live', playbackBlocked: true }]);
  assert.equal(payload.vodAvailable, true);
  assert.equal(payload.seriesAvailable, true);
  assert.equal(JSON.stringify(payload).includes('test-password'), false);
  assert.match(res.headers['set-cookie'], /HttpOnly/);
});

test('API imports a remote playlist through the connector without returning its URL or stream URLs', async () => {
  const handler = createApiHandler({
    lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    fetchImpl: async () => new Response('#EXTM3U\n#EXTINF:-1 group-title="News",Remote News\nhttps://media.example/live.m3u8?token=secret\n'),
  });
  const req = request(JSON.stringify({ playlistUrl: 'https://provider.example/list.m3u?token=source-secret' }), 'application/json', '/api/playlist/remote');
  const res = response(); const output = []; res.on('data', (chunk) => output.push(chunk));
  await handler(req, res);
  const payload = JSON.parse(Buffer.concat(output).toString());
  assert.equal(res.status, 200);
  assert.equal(payload.ok, true);
  assert.deepEqual(payload.items, [{ id: 'provider-0', name: 'Remote News', group: 'News', kind: 'live', playbackBlocked: true }]);
  assert.equal(JSON.stringify(payload).includes('secret'), false);
  assert.equal(JSON.stringify(payload).includes('provider.example'), false);
  assert.equal(JSON.stringify(payload).includes('media.example'), false);
});

test('API imports Xtream live metadata without returning query credentials and redacts failed requests', async () => {
  const handler = createApiHandler({
    allowHttp: true,
    hostAllowlist: ['provider.example'],
    lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    fetchImpl: async (url) => new URL(url).searchParams.get('action') === 'get_live_categories'
      ? new Response(JSON.stringify([{ category_id: '1', category_name: 'News' }]), { headers: { 'content-type': 'application/json' } })
      : new Response(JSON.stringify([{ stream_id: 1, name: 'News', category_id: '1' }]), { headers: { 'content-type': 'application/json' } }),
  });
  const req = request(JSON.stringify({ playlistUrl: 'http://provider.example/get.php?username=test-user&password=test-password' }), 'application/json', '/api/playlist/remote');
  const res = response(); const output = []; res.on('data', (chunk) => output.push(chunk));
  await handler(req, res);
  const payload = JSON.parse(Buffer.concat(output).toString());
  assert.equal(res.status, 200);
  assert.equal(JSON.stringify(payload).includes('test-user'), false);
  assert.equal(JSON.stringify(payload).includes('test-password'), false);

  const failed = createApiHandler({ allowHttp: true, hostAllowlist: ['provider.example'], lookup: async () => [{ address: '93.184.216.34', family: 4 }], fetchImpl: async () => new Response('', { status: 500 }) });
  const failedReq = request(JSON.stringify({ playlistUrl: 'http://provider.example/get.php?username=test-user&password=test-password' }), 'application/json', '/api/playlist/remote');
  const failedRes = response(); const failedOutput = []; failedRes.on('data', (chunk) => failedOutput.push(chunk));
  const previousWarn = console.warn; const warnings = [];
  console.warn = (value) => warnings.push(String(value));
  try { await failed(failedReq, failedRes); } finally { console.warn = previousWarn; }
  assert.equal(JSON.stringify(JSON.parse(Buffer.concat(failedOutput).toString())).includes('test-password'), false);
  assert.equal(warnings.join('\n').includes('test-user'), false);
  assert.equal(warnings.join('\n').includes('test-password'), false);
});

test('API exposes only lazy, session-bound Xtream VOD metadata with bounded paging', async () => {
  let requestedMoviePath;
  const handler = createApiHandler({
    allowHttp: true, hostAllowlist: ['provider.example'], lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    playbackHostAllowlist: ['provider.example'], playbackLookup: async () => [{ address: '93.184.216.34', family: 4 }],
    playbackFetchImpl: async (url) => { requestedMoviePath = new URL(url).pathname; return new Response('movie', { headers: { 'content-type': 'video/x-matroska' } }); },
    fetchImpl: async (url) => {
      const action = new URL(url).searchParams.get('action');
      if (action === 'get_live_categories') return new Response(JSON.stringify([{ category_id: '1', category_name: 'News' }]), { headers: { 'content-type': 'application/json' } });
      if (action === 'get_live_streams') return new Response(JSON.stringify([{ stream_id: 1, name: 'News', category_id: '1' }]), { headers: { 'content-type': 'application/json' } });
      if (action === 'get_vod_categories') return new Response(JSON.stringify([{ category_id: 'movies', category_name: 'Movies' }]), { headers: { 'content-type': 'application/json' } });
      if (action === 'get_vod_streams') return new Response(JSON.stringify(Array.from({ length: 501 }, (_, index) => ({ stream_id: index + 1, name: `Movie ${index + 1}`, year: 2024, rating: '7.0', container_extension: index === 499 ? 'mkv' : 'php' }))), { headers: { 'content-type': 'application/json' } });
      throw new Error('unexpected action');
    },
  });
  const imported = await payloadFor(handler, request(JSON.stringify({ playlistUrl: 'http://provider.example/get.php?username=test-user&password=test-password' }), 'application/json', '/api/playlist/remote'));
  assert.equal(imported.res.status, 200);
  assert.equal(imported.payload.vodAvailable, true);
  assert.equal(JSON.stringify(imported.payload).includes('test-user'), false);
  assert.equal(JSON.stringify(imported.payload).includes('test-password'), false);
  const cookie = imported.res.headers['set-cookie'];

  const categoryRequest = request('{}', 'application/json', '/api/catalog/xtream/vod/categories'); categoryRequest.headers.cookie = cookie;
  const categories = await payloadFor(handler, categoryRequest);
  assert.deepEqual(categories.payload, { ok: true, categories: [{ id: 'movies', name: 'Movies' }] });

  const firstPageRequest = request(JSON.stringify({ categoryId: 'movies', offset: 0, limit: 500 }), 'application/json', '/api/catalog/xtream/vod/items'); firstPageRequest.headers.cookie = cookie;
  const firstPage = await payloadFor(handler, firstPageRequest);
  assert.equal(firstPage.payload.items.length, 500);
  assert.equal(firstPage.payload.hasMore, true);

  const itemRequest = request(JSON.stringify({ categoryId: 'movies', offset: 499, limit: 500 }), 'application/json', '/api/catalog/xtream/vod/items'); itemRequest.headers.cookie = cookie;
  const page = await payloadFor(handler, itemRequest);
  assert.equal(page.res.status, 200);
  assert.equal(page.payload.items.length, 2);
  assert.equal(page.payload.items[0].id, '500');
  assert.equal(page.payload.hasMore, false);
  assert.equal(JSON.stringify(page.payload).includes('container_extension'), false);
  assert.equal(JSON.stringify(page.payload).includes('test-user'), false);
  assert.equal(JSON.stringify(page.payload).includes('test-password'), false);

  const mediaGrantRequest = request(JSON.stringify({ movieId: page.payload.items[0].id, containerExtension: 'php' }), 'application/json', '/api/media/grants'); mediaGrantRequest.headers.cookie = cookie;
  const mediaGrant = await payloadFor(handler, mediaGrantRequest);
  assert.equal(mediaGrant.res.status, 200);
  assert.match(mediaGrant.payload.mediaPath, /^\/media\/[A-Za-z0-9_-]+$/);
  assert.equal(JSON.stringify(mediaGrant.payload).includes('test-user'), false);
  assert.equal(JSON.stringify(mediaGrant.payload).includes('test-password'), false);

  const mediaRequest = request('', 'application/json', mediaGrant.payload.mediaPath); mediaRequest.method = 'GET'; mediaRequest.headers = { cookie };
  const mediaResponse = response(); const mediaOutput = []; mediaResponse.on('data', (chunk) => mediaOutput.push(chunk));
  await handler(mediaRequest, mediaResponse);
  assert.equal(mediaResponse.status, 200);
  assert.equal(requestedMoviePath?.endsWith('.mkv'), true);

  const unloadedMovieRequest = request(JSON.stringify({ movieId: 'never-loaded' }), 'application/json', '/api/media/grants'); unloadedMovieRequest.headers.cookie = cookie;
  const unloadedMovie = await payloadFor(handler, unloadedMovieRequest);
  assert.equal(unloadedMovie.res.status, 404);
  assert.equal(unloadedMovie.payload.error.code, 'playback_item_not_found');

  const unknownRequest = request(JSON.stringify({ categoryId: 'other', offset: 0, limit: 1 }), 'application/json', '/api/catalog/xtream/vod/items'); unknownRequest.headers.cookie = cookie;
  const unknown = await payloadFor(handler, unknownRequest);
  assert.equal(unknown.res.status, 403);
  assert.equal(unknown.payload.error.code, 'vod_catalog_unavailable');
});

test('API exposes lazy Xtream series categories, episode metadata, and protected episode playback', async () => {
  let requestedEpisodePath;
  const handler = createApiHandler({
    allowHttp: true, hostAllowlist: ['provider.example'], lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    playbackHostAllowlist: ['provider.example'], playbackLookup: async () => [{ address: '93.184.216.34', family: 4 }],
    playbackFetchImpl: async (url) => { requestedEpisodePath = new URL(url).pathname; return new Response('episode', { headers: { 'content-type': 'video/mp4' } }); },
    fetchImpl: async (url) => {
      const action = new URL(url).searchParams.get('action');
      if (action === 'get_live_categories') return new Response(JSON.stringify([{ category_id: 'live', category_name: 'Live' }]), { headers: { 'content-type': 'application/json' } });
      if (action === 'get_live_streams') return new Response(JSON.stringify([{ stream_id: 1, name: 'Live', category_id: 'live' }]), { headers: { 'content-type': 'application/json' } });
      if (action === 'get_series_categories') return new Response(JSON.stringify([{ category_id: 'drama', category_name: 'Drama' }]), { headers: { 'content-type': 'application/json' } });
      if (action === 'get_series') return new Response(JSON.stringify([{ series_id: 44, name: 'Example Series', cover: 'https://provider.example/cover.jpg' }]), { headers: { 'content-type': 'application/json' } });
      if (action === 'get_series_info') return new Response(JSON.stringify({ seasons: [{ season_number: 1, name: 'Season 1' }], episodes: { '1': [{ id: 9001, episode_num: 1, title: 'Pilot', container_extension: 'mkv' }] } }), { headers: { 'content-type': 'application/json' } });
      throw new Error(`unexpected action ${action}`);
    },
  });
  const imported = await payloadFor(handler, request(JSON.stringify({ playlistUrl: 'http://provider.example/get.php?username=series-user&password=series-pass' }), 'application/json', '/api/playlist/remote'));
  assert.equal(imported.res.status, 200);
  assert.equal(imported.payload.seriesAvailable, true);
  const cookie = imported.res.headers['set-cookie'];
  const categoriesReq = request('{}', 'application/json', '/api/catalog/xtream/series/categories'); categoriesReq.headers.cookie = cookie;
  const categories = await payloadFor(handler, categoriesReq);
  assert.deepEqual(categories.payload.categories, [{ id: 'drama', name: 'Drama' }]);
  const itemsReq = request(JSON.stringify({ categoryId: 'drama', offset: 0, limit: 100 }), 'application/json', '/api/catalog/xtream/series/items'); itemsReq.headers.cookie = cookie;
  const items = await payloadFor(handler, itemsReq);
  assert.equal(items.payload.items[0].id, '44');
  assert.equal(JSON.stringify(items.payload).includes('series-user'), false);
  const episodesReq = request(JSON.stringify({ seriesId: '44' }), 'application/json', '/api/catalog/xtream/series/episodes'); episodesReq.headers.cookie = cookie;
  const episodes = await payloadFor(handler, episodesReq);
  assert.equal(episodes.payload.episodes[0].title, 'Pilot');
  const grantReq = request(JSON.stringify({ episodeId: '9001' }), 'application/json', '/api/media/grants'); grantReq.headers.cookie = cookie;
  const grant = await payloadFor(handler, grantReq);
  assert.equal(grant.res.status, 200);
  const mediaReq = request('', 'application/json', grant.payload.mediaPath); mediaReq.method = 'GET'; mediaReq.headers = { cookie };
  const mediaRes = response(); await handler(mediaReq, mediaRes);
  assert.equal(mediaRes.status, 200);
  assert.equal(requestedEpisodePath, '/series/series-user/series-pass/9001.mkv');
});
