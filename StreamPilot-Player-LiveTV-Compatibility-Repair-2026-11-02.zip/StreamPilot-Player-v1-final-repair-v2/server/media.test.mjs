import './test-env.mjs';
import assert from 'node:assert/strict';
import test from 'node:test';
import { EventEmitter } from 'node:events';
import { ConnectorError } from './connector.mjs';
import { MovieGrantStore } from './api.mjs';
import { PlaybackSessions, handleMovieMediaRequest, sessionCookie } from './playback.mjs';

const publicLookup = async () => [{ address: '93.184.216.34', family: 4 }];

function request(path, sessionId, { method = 'GET', range } = {}) {
  const req = new EventEmitter();
  req.method = method; req.url = path; req.headers = { cookie: `sp_playback_session=${sessionId}`, ...(range ? { range } : {}) };
  return req;
}

function response() {
  const res = new EventEmitter();
  res.status = 0; res.headers = {}; res.body = ''; res.writableEnded = false;
  res.writeHead = (status, headers) => { res.status = status; res.headers = headers; return res; };
  res.write = (chunk) => { res.body += Buffer.from(chunk).toString('utf8'); return true; };
  res.end = (chunk = '') => { res.body += Buffer.from(chunk).toString('utf8'); res.writableEnded = true; };
  return res;
}

function mediaOptions(resolveAuthorizedMovie, fetchImpl, overrides = {}) {
  return { resolveAuthorizedMovie, fetchImpl, lookup: publicLookup, allowHttp: true, hostAllowlist: ['media.example'], ...overrides };
}

test('movie grants are opaque, session-bound, revocable, and expire', () => {
  let now = 0;
  const grants = new MovieGrantStore({ now: () => now, ttlMs: 100 });
  const grant = grants.issue('session-a', 'movie-1');
  assert.equal(grants.resolve('session-a', grant).movieId, 'movie-1');
  assert.throws(() => grants.resolve('session-b', grant), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
  assert.equal(grants.revoke(grant), true);
  assert.throws(() => grants.resolve('session-a', grant), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
  const expiring = grants.issue('session-a', 'movie-2'); now = 101;
  assert.throws(() => grants.resolve('session-a', expiring), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
});

test('movie media refreshes only its own grant and session within a six-hour absolute cap', async () => {
  let now = 0;
  const sessions = new PlaybackSessions({ now: () => now, sessionTtlMs: 1_000, sessionAbsoluteTtlMs: 6_000 });
  const sessionId = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://media.example/live' }]);
  const liveGrant = sessions.createGrant(sessionId, 'live-1');
  const grants = new MovieGrantStore({ now: () => now, ttlMs: 500, absoluteTtlMs: 6_000 });
  const movieGrant = grants.issue(sessionId, 'movie-1');
  const initialSessionExpiry = sessions.getSession(sessionId).expiresAt;
  const initialLiveGrantExpiry = sessions.getGrant(sessionId, liveGrant).grant.expiresAt;
  now = 400;
  sessions.getGrant(sessionId, liveGrant);
  assert.equal(sessions.getSession(sessionId).expiresAt, initialSessionExpiry);
  const res = response();
  await handleMovieMediaRequest(request(`/media/${movieGrant}`, sessionId), res, mediaOptions(
    async (receivedSessionId, receivedGrantId) => ({
      upstreamUrl: 'https://media.example/movie',
      refresh: () => {
        grants.assertCanTouch(receivedSessionId, receivedGrantId);
        sessions.assertCanTouchForMovie(receivedSessionId);
        grants.touch(receivedSessionId, receivedGrantId);
        const refreshed = sessions.touchForMovie(receivedSessionId);
        return { sessionCookie: sessionCookie(receivedSessionId, { secure: false, maxAgeSeconds: refreshed.maxAgeSeconds }) };
      },
    }),
    async () => new Response('movie', { headers: { 'content-type': 'video/mp4' } }),
  ));
  assert.equal(grants.resolve(sessionId, movieGrant).expiresAt, 900);
  assert.equal(sessions.getSession(sessionId).expiresAt, 1_400);
  assert.equal(sessions.getGrant(sessionId, liveGrant).grant.expiresAt, initialLiveGrantExpiry);
  assert.notEqual(sessions.getSession(sessionId).expiresAt, initialSessionExpiry);
  assert.match(res.headers['set-cookie'], /Path=\/; HttpOnly; SameSite=Strict/);

  for (now = 800; now < 6_000; now += 400) {
    grants.touch(sessionId, movieGrant);
    sessions.touchForMovie(sessionId);
  }
  now = 5_999;
  assert.equal(grants.resolve(sessionId, movieGrant).expiresAt, 6_000);
  assert.equal(sessions.getSession(sessionId).expiresAt, 6_000);
  now = 6_000;
  assert.throws(() => grants.touch(sessionId, movieGrant), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
  assert.throws(() => sessions.touchForMovie(sessionId), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
});

test('movie failures and unauthorized requests do not refresh grants or sessions, and cookie security attributes are fixed', async () => {
  let now = 0;
  const sessions = new PlaybackSessions({ now: () => now, sessionTtlMs: 1_000, sessionAbsoluteTtlMs: 6_000 });
  const sessionId = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://media.example/live' }]);
  const grants = new MovieGrantStore({ now: () => now, ttlMs: 500, absoluteTtlMs: 6_000 });
  const movieGrant = grants.issue(sessionId, 'movie-1');
  const grantExpiry = grants.resolve(sessionId, movieGrant).expiresAt;
  const sessionExpiry = sessions.getSession(sessionId).expiresAt;
  let refreshes = 0;
  await assert.rejects(
    () => handleMovieMediaRequest(request(`/media/${movieGrant}`, sessionId), response(), mediaOptions(
      async () => ({ upstreamUrl: 'https://media.example/movie', refresh: () => { refreshes += 1; } }),
      async () => { throw new ConnectorError('The playback source could not be reached.', 502, 'provider_unreachable'); },
    )),
    (error) => error instanceof ConnectorError && error.code === 'provider_unreachable',
  );
  assert.equal(refreshes, 0);
  assert.equal(grants.resolve(sessionId, movieGrant).expiresAt, grantExpiry);
  assert.equal(sessions.getSession(sessionId).expiresAt, sessionExpiry);
  assert.throws(() => grants.resolve('other-session', movieGrant), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
  assert.equal(grants.resolve(sessionId, movieGrant).expiresAt, grantExpiry);
  assert.match(sessionCookie('opaque', { secure: false }), /Path=\/; HttpOnly; SameSite=Strict$/);
  assert.doesNotMatch(sessionCookie('opaque', { secure: false }), /; Secure/);
  assert.match(sessionCookie('opaque', { secure: true }), /; Secure$/);
});

test('movie media forwards one valid Range and streams the upstream partial response incrementally', async () => {
  const req = request('/media/grant-a', 'session-a', { range: 'bytes=10-19' }); const res = response(); let requestOptions;
  const handled = await handleMovieMediaRequest(req, res, mediaOptions(
    async (sessionId, grantId) => { assert.equal(sessionId, 'session-a'); assert.equal(grantId, 'grant-a'); return { upstreamUrl: 'https://media.example/movie' }; },
    async (_url, options) => { requestOptions = options; return new Response('partial-data', { status: 206, headers: { 'content-type': 'video/mp4', 'content-range': 'bytes 10-19/100', 'accept-ranges': 'bytes', 'content-length': '12' } }); },
  ));
  assert.equal(handled, true); assert.equal(requestOptions.method, 'GET'); assert.equal(requestOptions.headers.Range, 'bytes=10-19');
  assert.equal(res.status, 206); assert.equal(res.headers['content-range'], 'bytes 10-19/100'); assert.equal(res.headers['accept-ranges'], 'bytes'); assert.equal(res.body, 'partial-data');
});

test('movie media supports HEAD, rejects invalid or ignored ranges, and passes upstream 416 safely', async () => {
  const resolve = async () => ({ upstreamUrl: 'https://media.example/movie' });
  let calls = 0;
  await assert.rejects(() => handleMovieMediaRequest(request('/media/grant-a', 'session-a', { range: 'bytes=9-2' }), response(), mediaOptions(resolve, async () => { calls += 1; return new Response(); })), (error) => error instanceof ConnectorError && error.code === 'invalid_range');
  assert.equal(calls, 0);

  const head = response();
  await handleMovieMediaRequest(request('/media/grant-a', 'session-a', { method: 'HEAD' }), head, mediaOptions(resolve, async (_url, options) => {
    assert.equal(options.method, 'HEAD'); return new Response(null, { status: 200, headers: { 'content-type': 'video/mp4', 'content-length': '100', 'accept-ranges': 'bytes' } });
  }));
  assert.equal(head.status, 200); assert.equal(head.headers['content-length'], '100'); assert.equal(head.body, '');

  const unsatisfiable = response();
  await handleMovieMediaRequest(request('/media/grant-a', 'session-a', { range: 'bytes=999-' }), unsatisfiable, mediaOptions(resolve, async () => new Response(null, { status: 416, headers: { 'content-range': 'bytes */100' } })));
  assert.equal(unsatisfiable.status, 416); assert.equal(unsatisfiable.headers['content-range'], 'bytes */100');

  await assert.rejects(() => handleMovieMediaRequest(request('/media/grant-a', 'session-a', { range: 'bytes=0-9' }), response(), mediaOptions(resolve, async () => new Response('full file', { status: 200 }))), (error) => error instanceof ConnectorError && error.code === 'invalid_range');
});

test('movie media accepts validated public CDN redirects and still blocks private destinations', async () => {
  const resolve = async () => ({ upstreamUrl: 'https://media.example/movie' });
  let calls = 0;
  const publicResult = response();
  await handleMovieMediaRequest(request('/media/grant-a', 'session-a'), publicResult, mediaOptions(resolve, async (url, options) => {
    calls += 1;
    if (calls === 1) return new Response('', { status: 302, headers: { location: 'https://other.example/movie' } });
    assert.equal(new URL(url).hostname, 'other.example');
    assert.ok(options.dispatcher, 'public CDN hostname must use its validated pinned dispatcher');
    return new Response('movie-bytes', { headers: { 'content-type': 'video/mp4', 'content-length': '11' } });
  }));
  assert.equal(publicResult.status, 200);
  assert.equal(calls, 2);

  await assert.rejects(() => handleMovieMediaRequest(request('/media/grant-a', 'session-a'), response(), mediaOptions(resolve, async () => { throw new Error('must not fetch private address'); }, { lookup: async () => [{ address: '127.0.0.1', family: 4 }] })), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
});

test('movie and episode media honor the exact local HTTP IP redirect binding instead of overriding it', async () => {
  const previousBinding = process.env.PLAYBACK_HTTP_IP_REDIRECT_BINDING;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = 'test';
  process.env.PLAYBACK_HTTP_IP_REDIRECT_BINDING = 'media.example=93.184.216.34';
  let calls = 0;
  let pinned = 0;
  const result = response();
  try {
    await handleMovieMediaRequest(request('/media/grant-a', 'session-a'), result, mediaOptions(
      async () => ({ upstreamUrl: 'http://media.example:2086/movie' }),
      async (_url, options) => {
        calls += 1;
        if (calls === 1) return new Response(null, { status: 302, headers: { location: 'http://93.184.216.34:2086/movie' } });
        assert.ok(options.dispatcher, 'the exact IP redirect must use a pinned dispatcher');
        return new Response('movie', { headers: { 'content-type': 'video/mp4', 'content-length': '5' } });
      },
      { boundIpRedirectDispatcherFactory: ({ destinationIp }) => {
        assert.equal(destinationIp, '93.184.216.34');
        pinned += 1;
        return { close: async () => {} };
      } },
    ));
    assert.equal(result.status, 200);
    assert.equal(calls, 2);
    assert.equal(pinned, 1);
  } finally {
    if (previousBinding === undefined) delete process.env.PLAYBACK_HTTP_IP_REDIRECT_BINDING;
    else process.env.PLAYBACK_HTTP_IP_REDIRECT_BINDING = previousBinding;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('movie and episode media honor the local same-port HTTP IP redirect trust setting', async () => {
  const previousTrust = process.env.PLAYBACK_HTTP_IP_REDIRECT_TRUST;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = 'test';
  process.env.PLAYBACK_HTTP_IP_REDIRECT_TRUST = 'media.example';
  let calls = 0;
  let pinned = 0;
  const result = response();
  try {
    await handleMovieMediaRequest(request('/media/grant-a', 'session-a'), result, mediaOptions(
      async () => ({ upstreamUrl: 'http://media.example:2086/movie' }),
      async (_url, options) => {
        calls += 1;
        if (calls === 1) return new Response(null, { status: 302, headers: { location: 'http://93.184.216.34:2086/movie' } });
        assert.ok(options.dispatcher);
        return new Response('movie', { headers: { 'content-type': 'video/mp4', 'content-length': '5' } });
      },
      { boundIpRedirectDispatcherFactory: () => { pinned += 1; return { close: async () => {} }; } },
    ));
    assert.equal(result.status, 200);
    assert.equal(calls, 2);
    assert.equal(pinned, 1);
  } finally {
    if (previousTrust === undefined) delete process.env.PLAYBACK_HTTP_IP_REDIRECT_TRUST;
    else process.env.PLAYBACK_HTTP_IP_REDIRECT_TRUST = previousTrust;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('movie-only trust permits one public HTTP literal redirect on port 80 or the source port and revalidates each Range request', async () => {
  for (const targetPort of [80, 2086]) {
    const sourceUrl = 'http://media.example:2086/movie'; const target = `http://93.184.216.34${targetPort === 80 ? '' : `:${targetPort}`}/movie`;
    let calls = 0; let pinned = 0; let closed = 0;
    const result = response();
    await handleMovieMediaRequest(request('/media/grant-a', 'session-a', { range: 'bytes=0-9' }), result, mediaOptions(
      async () => ({ upstreamUrl: sourceUrl }),
      async (url, options) => {
        calls += 1;
        if (calls === 1) return new Response(null, { status: 302, headers: { location: target } });
        assert.equal(new URL(url).hostname, '93.184.216.34'); assert.ok(options.dispatcher);
        return new Response('movie', { status: 206, headers: { 'content-type': 'video/mp4', 'content-range': 'bytes 0-9/100' } });
      },
      { mediaIpRedirectTrust: 'media.example', boundIpRedirectDispatcherFactory: () => { pinned += 1; return { close: async () => { closed += 1; } }; } },
    ));
    assert.equal(result.status, 206); assert.equal(pinned, 1); assert.equal(closed, 1);
  }

  let sourceRequests = 0; let pins = 0;
  const requestOptions = { mediaIpRedirectTrust: 'media.example', boundIpRedirectDispatcherFactory: () => { pins += 1; return { close: async () => {} }; } };
  const fetchImpl = async (_url, options) => {
    sourceRequests += 1;
    return sourceRequests % 2 ? new Response(null, { status: 302, headers: { location: 'http://93.184.216.34/movie' } }) : new Response('movie', { status: 206, headers: { 'content-type': 'video/mp4', 'content-range': 'bytes 0-9/100' } });
  };
  await handleMovieMediaRequest(request('/media/grant-a', 'session-a', { range: 'bytes=0-9' }), response(), mediaOptions(async () => ({ upstreamUrl: 'http://media.example/movie' }), fetchImpl, requestOptions));
  await handleMovieMediaRequest(request('/media/grant-a', 'session-a', { range: 'bytes=10-19' }), response(), mediaOptions(async () => ({ upstreamUrl: 'http://media.example/movie' }), fetchImpl, requestOptions));
  assert.equal(sourceRequests, 4); assert.equal(pins, 2);
});

test('movie media accepts public IP redirects on provider-selected ports and blocks unsafe targets', async () => {
  const previousEnv = process.env.NODE_ENV; const previousDiagnostics = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1';
  const unsafe = [
    ['private', 'http://10.0.0.1/movie'],
    ['loopback', 'http://127.0.0.1/movie'],
    ['reserved', 'http://192.0.2.1/movie'],
    ['userinfo', 'http://user@93.184.216.34/movie'],
  ];
  try {
    for (const [name, location] of unsafe) {
      await assert.rejects(
        () => handleMovieMediaRequest(request('/media/grant-a', 'session-a'), response(), mediaOptions(
          async () => ({ upstreamUrl: 'http://media.example:2086/movie' }),
          async () => new Response(null, { status: 302, headers: { location } }),
        )),
        (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed',
        name,
      );
    }
    let calls = 0; let pins = 0;
    await assert.doesNotReject(() => handleMovieMediaRequest(request('/media/grant-a', 'session-a'), response(), mediaOptions(
      async () => ({ upstreamUrl: 'http://media.example:2086/movie' }),
      async (_url, options) => {
        calls += 1;
        if (calls === 1) return new Response(null, { status: 302, headers: { location: 'http://93.184.216.34:2087/movie' } });
        assert.ok(options.dispatcher);
        return new Response('movie-bytes', { status: 200, headers: { 'content-type': 'video/mp4', 'content-length': '11' } });
      },
      { boundIpRedirectDispatcherFactory: () => { pins += 1; return { close: async () => {} }; } },
    )));
    assert.equal(calls, 2); assert.equal(pins, 1);

    process.env.NODE_ENV = 'production';
    calls = 0;
    await assert.doesNotReject(() => handleMovieMediaRequest(request('/media/grant-a', 'session-a'), response(), mediaOptions(
      async () => ({ upstreamUrl: 'http://media.example/movie' }),
      async (_url, options) => {
        calls += 1;
        if (calls === 1) return new Response(null, { status: 302, headers: { location: 'http://93.184.216.34/movie' } });
        assert.ok(options.dispatcher);
        return new Response('movie-bytes', { status: 200, headers: { 'content-type': 'video/mp4', 'content-length': '11' } });
      },
      { boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }) },
    )));
    assert.equal(calls, 2);
  } finally {
    if (previousEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = previousEnv;
    if (previousDiagnostics === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS; else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previousDiagnostics;
  }
});

test('movie media reports upstream HTTP failures without treating them as successful media', async () => {
  await assert.rejects(
    () => handleMovieMediaRequest(
      request('/media/grant-a', 'session-a'),
      response(),
      mediaOptions(async () => ({ upstreamUrl: 'https://media.example/movie' }), async () => new Response(null, { status: 403 })),
    ),
    (error) => error instanceof ConnectorError && error.code === 'provider_http_error' && error.status === 502,
  );
});

test('movie media accepts only video or octet-stream content types', async () => {
  await assert.rejects(
    () => handleMovieMediaRequest(
      request('/media/grant-a', 'session-a'),
      response(),
      mediaOptions(async () => ({ upstreamUrl: 'https://media.example/movie' }), async () => new Response('<html>', { headers: { 'content-type': 'text/html' } })),
    ),
    (error) => error instanceof ConnectorError && error.code === 'unsupported_response',
  );
});

test('movie media cancels its upstream reader when the client disconnects and does not buffer the response', async () => {
  const req = request('/media/grant-a', 'session-a'); const res = response(); let cancelled = false;
  const body = new ReadableStream({
    start(controller) { controller.enqueue(new TextEncoder().encode('first-chunk')); },
    cancel() { cancelled = true; },
  });
  const pending = handleMovieMediaRequest(req, res, mediaOptions(async () => ({ upstreamUrl: 'https://media.example/movie' }), async () => new Response(body, { headers: { 'content-type': 'video/mp4' } })));
  await new Promise((resolve) => setImmediate(resolve));
  res.emit('close');
  await pending;
  assert.equal(cancelled, true);
  assert.equal(res.body, 'first-chunk');
  assert.equal(res.writableEnded, false);
});

test('movie and episode media follow provider-scoped domain redirects with DNS pinning', async () => {
  const calls = [];
  const closed = [];
  const fetchImpl = async (url, options) => {
    calls.push({ url: String(url), dispatcher: options.dispatcher });
    if (calls.length === 1) return new Response(null, { status: 302, headers: { location: 'http://cdn.example.test/movie.mp4' } });
    return new Response('movie bytes', { headers: { 'content-type': 'video/mp4' } });
  };
  const boundDomainRedirectDispatcherFactory = (config) => {
    assert.equal(config.destinationHostname, 'cdn.example.test');
    assert.deepEqual(config.destinationRecords, [{ address: '93.184.216.34', family: 4 }]);
    const dispatcher = { close: async () => { closed.push(true); } };
    return dispatcher;
  };
  const res = response();
  await handleMovieMediaRequest(request('/media/grant-a', 'session-a'), res, mediaOptions(
    async () => ({ upstreamUrl: 'http://media.example/movie.mp4' }), fetchImpl,
    {
      providerDomainTrust: { sourceHostname: 'media.example', suffixes: ['.example.test'] },
      boundDomainRedirectDispatcherFactory,
    },
  ));
  assert.equal(calls.length, 2);
  assert.equal(calls[0].url, 'http://media.example/movie.mp4');
  assert.equal(calls[1].url, 'http://cdn.example.test/movie.mp4');
  assert.ok(calls[1].dispatcher);
  assert.equal(res.status, 200);
  assert.equal(res.body, 'movie bytes');
  assert.deepEqual(closed, [true]);
});
