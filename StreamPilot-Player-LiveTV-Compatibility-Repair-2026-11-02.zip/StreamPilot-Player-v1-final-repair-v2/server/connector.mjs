import dns from 'node:dns/promises';
import { isIP } from 'node:net';
import { createProviderAdapterRegistry } from './providers/registry.mjs';

// The playlist is parsed as it arrives. These independent bounds prevent a large
// provider response from being buffered in memory or producing an unbounded UI list.
const MAX_PLAYLIST_TRANSPORT_BYTES = 40 * 1024 * 1024;
const MAX_PLAYLIST_ENTRIES = 20_000;
const MAX_PLAYLIST_LINE_BYTES = 64 * 1024;
const MAX_XTREAM_API_BYTES = 10 * 1024 * 1024;
const MAX_XTREAM_LIVE_ENTRIES = 20_000;
// Xtream-style live endpoints commonly use m3u8. This is an assumed provider
// path format and must not be treated as verified provider compatibility.
const XTREAM_LIVE_EXTENSION = 'm3u8';
const MAX_XTREAM_VOD_PAGE_SIZE = 500;
const XTREAM_MOVIE_EXTENSION = 'mp4';
const XTREAM_MOVIE_EXTENSIONS = new Set(['mp4', 'mkv', 'm4v', 'webm']);
const xtreamVodPageExtensions = new WeakMap();
const xtreamSeriesPageExtensions = new WeakMap();
const XTREAM_SERIES_EXTENSIONS = new Set(['mp4', 'mkv', 'm4v', 'avi', 'mov', 'ts', 'webm']);
const DEFAULT_REQUEST_TIMEOUT_MS = 20_000;
const MIN_REQUEST_TIMEOUT_MS = 5_000;
const MAX_REQUEST_TIMEOUT_MS = 60_000;

export function providerRequestTimeoutMs(value = process.env.PROVIDER_REQUEST_TIMEOUT_MS) {
  if (value === undefined || value === '') return DEFAULT_REQUEST_TIMEOUT_MS;
  const timeoutMs = Number(value);
  return Number.isInteger(timeoutMs) && timeoutMs >= MIN_REQUEST_TIMEOUT_MS && timeoutMs <= MAX_REQUEST_TIMEOUT_MS
    ? timeoutMs
    : DEFAULT_REQUEST_TIMEOUT_MS;
}

export class ConnectorError extends Error {
  constructor(message, status = 400, code = 'invalid_request', diagnostic = {}, localDiagnostic = {}) {
    super(message); this.status = status; this.code = code; this.diagnostic = diagnostic; this.localDiagnostic = localDiagnostic;
  }
}

export function redactSecrets(value) {
  return String(value)
    .replace(/(password|username|token|authorization)=([^&\s]+)/gi, '$1=[redacted]')
    .replace(/\/\/([^/:\s]+):([^@\s]+)@/g, '//$1:[redacted]@');
}

export function isForbiddenAddress(address) {
  if (typeof address !== 'string') return true;
  const ip = address.toLowerCase().replace(/%.+$/, '').replace(/^::ffff:/, '');
  if (/^\d+\.\d+\.\d+\.\d+$/.test(ip)) {
    const [a, b] = ip.split('.').map(Number);
    if ([a, b].some((value) => !Number.isInteger(value) || value < 0 || value > 255)) return true;
    // RFC 1918, loopback, link-local, CGNAT, benchmarking, documentation,
    // multicast, and other special-use IPv4 space. Fail closed for anything
    // that is not globally routable enough for untrusted provider egress.
    return a === 0 || a === 10 || a === 127 || a >= 224
      || (a === 100 && b >= 64 && b <= 127)
      || (a === 169 && b === 254)
      || (a === 172 && b >= 16 && b <= 31)
      || (a === 192 && (b === 0 || b === 2 || b === 31 || b === 52 || b === 88 || b === 168 || b === 175))
      || (a === 198 && (b === 18 || b === 19 || b === 51))
      || (a === 203 && b === 0);
  }
  const words = ipv6Words(ip);
  if (!words) return true;
  const first = words[0];
  // IPv4-mapped IPv6 must inherit the IPv4 policy rather than becoming a
  // bypass for loopback/private IPv4 destinations.
  if (words.slice(0, 5).every((word) => word === 0) && words[5] === 0xffff) {
    return isForbiddenAddress(`${words[6] >> 8}.${words[6] & 0xff}.${words[7] >> 8}.${words[7] & 0xff}`);
  }
  return first === 0 // includes unspecified and IPv4-compatible forms
    || (first & 0xfe00) === 0xfc00 // fc00::/7 ULA
    || (first & 0xffc0) === 0xfe80 // fe80::/10 link-local
    || (first & 0xff00) === 0xff00 // ff00::/8 multicast
    || (first === 0x0064 && words[1] === 0xff9b && words[2] === 0) // 64:ff9b::/96 well-known NAT64
    || (first === 0x0064 && words[1] === 0xff9b && words[2] === 1) // 64:ff9b:1::/48
    || (first === 0x0100 && words[1] === 0 && words[2] === 0 && words[3] === 0) // 100::/64
    || (first === 0x2001 && (words[1] < 0x0200 || words[1] === 0x0db8)) // IETF protocol assignments / docs
    || first === 0x2002 // 6to4 is not suitable for untrusted egress
    || (first === 0x3fff && (words[1] & 0xf000) === 0); // documentation 3fff::/20
}

function ipv6Words(value) {
  if (!value || value.includes('%')) return null;
  const parts = value.split('::');
  if (parts.length > 2) return null;
  const decode = (part) => {
    if (!part) return [];
    const chunks = part.split(':');
    const words = [];
    for (let index = 0; index < chunks.length; index += 1) {
      const chunk = chunks[index];
      if (chunk.includes('.')) {
        if (index !== chunks.length - 1 || !/^\d+\.\d+\.\d+\.\d+$/.test(chunk)) return null;
        const octets = chunk.split('.').map(Number);
        if (octets.some((octet) => octet < 0 || octet > 255)) return null;
        words.push((octets[0] << 8) | octets[1], (octets[2] << 8) | octets[3]);
      } else {
        if (!/^[0-9a-f]{1,4}$/i.test(chunk)) return null;
        words.push(Number.parseInt(chunk, 16));
      }
    }
    return words;
  };
  const left = decode(parts[0]); const right = decode(parts[1] ?? '');
  if (!left || !right) return null;
  if (parts.length === 1) return left.length === 8 ? left : null;
  const zeros = 8 - left.length - right.length;
  return zeros >= 1 ? [...left, ...Array(zeros).fill(0), ...right] : null;
}

export async function validateDestination(rawUrl, { lookup = dns.lookup, allowHttp = true, hostAllowlist = [] } = {}) {
  const { url } = await resolveDestination(rawUrl, { lookup, allowHttp, hostAllowlist });
  return url;
}

// Exposes the exact DNS answers used for a security decision so a transport can
// pin its socket to one validated address instead of letting a later network
// lookup choose a different answer. Callers must still connect by address.
export async function resolveDestination(rawUrl, { lookup = dns.lookup, allowHttp = true, hostAllowlist = [] } = {}) {
  let url;
  try { url = new URL(rawUrl); } catch { throw new ConnectorError('The provider server URL is invalid.', 400, 'invalid_request'); }
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.hash) throw new ConnectorError('Use a plain HTTP(S) provider server URL without embedded credentials.', 400, 'invalid_request');
  if (url.protocol === 'http:' && !allowHttp) throw new ConnectorError('This connector requires HTTPS because an HTTP-only provider cannot protect credentials in transit. Ask the provider for HTTPS support.', 400, 'http_not_allowed');
  const hostname = url.hostname.toLowerCase();
  const literalAddress = hostname.replace(/^\[|\]$/g, '');
  const literalFamily = isIP(literalAddress);
  if (literalFamily && isForbiddenAddress(literalAddress)) {
    throw new ConnectorError('The provider server address is not permitted.', 403, 'destination_not_allowed', {}, { destinationRejection: 'resolved_address_not_allowed' });
  }
  // Provider entry points are user-supplied. Do not require operators to add each
  // hostname manually; DNS/IP safety checks and pinned transport remain mandatory.
  // hostAllowlist is retained only for narrowly scoped, operator-approved redirect exceptions.
  let records;
  if (literalFamily) records = [{ address: literalAddress, family: literalFamily }];
  else try { records = await lookup(url.hostname, { all: true, verbatim: true }); }
  catch { throw new ConnectorError('The provider server address could not be resolved safely.', 403, 'destination_not_allowed', {}, { destinationRejection: 'dns_resolution_failed' }); }
  if (!records.length) throw new ConnectorError('The provider server address could not be resolved safely.', 403, 'destination_not_allowed', {}, { destinationRejection: 'dns_resolution_failed' });
  if (records.some(({ address }) => isForbiddenAddress(address))) throw new ConnectorError('The provider server address is not permitted.', 403, 'destination_not_allowed', {}, { destinationRejection: 'resolved_address_not_allowed' });
  return { url, records };
}

function responseCategory(value) {
  const start = value.trimStart();
  if (!start) return 'empty';
  if (/^<(?:!doctype|html|head|body|div|p|title)\b/i.test(start)) return 'html';
  if (/^[{[]/.test(start)) return 'json';
  if (/^#EXTM3U\b/im.test(start) || /^#EXTINF:/im.test(start)) return 'm3u';
  return 'unknown';
}

function throwForResponseCategory(category) {
  const diagnostic = { responseCategory: category };
  if (category === 'html') throw new ConnectorError('The provider returned an HTML page instead of a playlist.', 502, 'provider_response_html', diagnostic);
  if (category === 'json') throw new ConnectorError('The provider returned JSON instead of a playlist.', 502, 'provider_response_json', diagnostic);
  if (category !== 'm3u') throw new ConnectorError('The provider response was not a readable M3U playlist.', 502, 'provider_response_unknown', diagnostic);
}

function playlistKind(group, name) {
  return /movie|movies|film|cinema|vod/i.test(`${group} ${name}`) ? 'movie' : /series|tv show|season|episode|\bs\d{1,2}\s*e\d{1,3}\b|\b\d{1,2}x\d{1,3}\b/i.test(`${group} ${name}`) ? 'series' : 'live';
}

async function streamMetadataFromM3U(response, { maxBytes = MAX_PLAYLIST_TRANSPORT_BYTES, maxEntries = MAX_PLAYLIST_ENTRIES, onItem, signal } = {}) {
  const declared = Number(response.headers.get('content-length') || 0);
  if (declared > maxBytes) throw new ConnectorError('The provider playlist is too large to import safely.', 413, 'playlist_too_large');
  const reader = response.body?.getReader();
  if (!reader) throw new ConnectorError('The provider returned an unreadable playlist response.', 502, 'unsupported_response');
  const decoder = new TextDecoder();
  const entries = []; let pending; let pendingGroup; let firstContent = ''; let carry = ''; let bytes = 0; let entryLimitReached = false;
  const processLine = (rawLine) => {
    const line = rawLine.replace(/^\uFEFF/, '').trim();
    if (!line) return;
    if (!firstContent) firstContent = line;
    if (/^#EXTINF\s*:/i.test(line)) {
      const comma = line.indexOf(',');
      const readAttr = (names) => {
        for (const name of names) {
          const match = line.match(new RegExp(`(?:^|\\s)${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s,]+))`, 'i'));
          const value = (match?.[1] ?? match?.[2] ?? match?.[3])?.trim();
          if (value) return value;
        }
        return undefined;
      };
      const group = readAttr(['group-title', 'group_title']) || pendingGroup || 'Uncategorized';
      const name = (comma >= 0 ? line.slice(comma + 1).trim() : '') || readAttr(['tvg-name', 'tvg_name']) || 'Untitled channel';
      const logo = readAttr(['tvg-logo', 'tvg_logo']);
      const tvgId = readAttr(['tvg-id', 'tvg_id']);
      const attributes = {};
      for (const match of line.matchAll(/([a-z0-9_-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,]+))/gi)) {
        const key = match[1].toLowerCase();
        const value = (match[2] ?? match[3] ?? match[4] ?? '').trim();
        if (!['group-title', 'group_title', 'tvg-name', 'tvg_name', 'tvg-logo', 'tvg_logo', 'tvg-id', 'tvg_id'].includes(key)
          && !/(?:pass|token|auth|secret|credential|license|url|username|(?:^|[._-])key(?:$|[._-]))/i.test(key)
          && value.length <= 1_024
          && !/^https?:\/\//i.test(value)) {
          attributes[`extinf.${key}`] = value;
        }
      }
      pending = { name, group, ...(logo ? { logo } : {}), ...(tvgId ? { tvgId } : {}), ...(Object.keys(attributes).length ? { metadata: attributes } : {}) };
      pendingGroup = undefined;
      return;
    }
    if (/^#EXTGRP\s*:/i.test(line)) {
      const group = line.slice(line.indexOf(':') + 1).trim();
      if (pending) pending.group = group || pending.group; else pendingGroup = group || undefined;
      return;
    }
    if (/^#EXTVLCOPT:/i.test(line) || /^#KODIPROP:/i.test(line)) {
      if (pending) {
        const prefix = /^#EXTVLCOPT:/i.test(line) ? 'vlc' : 'kodi';
        const directive = line.slice(line.indexOf(':') + 1).trim();
        const separator = directive.indexOf('=');
        if (separator > 0) {
          const key = directive.slice(0, separator).trim().toLowerCase();
          const value = directive.slice(separator + 1).trim();
          if (key && value && key.length <= 100 && value.length <= 2_048
            && !/(?:pass|token|auth|secret|credential|license|url|username|(?:^|[._-])key(?:$|[._-]))/i.test(key)
            && !/^https?:\/\//i.test(value)) {
            pending.metadata = { ...(pending.metadata ?? {}), [`${prefix}.${key}`]: value };
          }
        }
      }
      return;
    }
    if (line.startsWith('#') || !pending) return;
    if (/^https?:\/\//i.test(line)) {
      const item = { id: `provider-${entries.length}`, ...pending, kind: playlistKind(pending.group, pending.name), playbackBlocked: true };
      entries.push(item);
      onItem?.({ id: item.id, kind: item.kind, upstreamUrl: line });
      pending = undefined;
    }
  };
  try {
    while (entries.length < maxEntries) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > maxBytes) throw new ConnectorError('The provider playlist is too large to import safely.', 413, 'playlist_too_large');
      carry += decoder.decode(value, { stream: true });
      let lineEnd;
      while (entries.length < maxEntries && (lineEnd = carry.indexOf('\n')) >= 0) {
        processLine(carry.slice(0, lineEnd));
        carry = carry.slice(lineEnd + 1);
      }
      if (Buffer.byteLength(carry, 'utf8') > MAX_PLAYLIST_LINE_BYTES) throw new ConnectorError('The provider playlist contains an unsafe line length.', 502, 'unsupported_response');
    }
    if (entries.length === maxEntries) { entryLimitReached = true; await reader.cancel(); }
    else processLine(carry + decoder.decode());
  } catch (error) {
    if (error instanceof ConnectorError) throw error;
    if (signal?.aborted || error?.name === 'TimeoutError' || error?.name === 'AbortError') throw new ConnectorError('The provider request timed out while streaming the playlist.', 504, 'provider_timeout', { importStage: 'playlist_stream' });
    throw new ConnectorError('The provider playlist could not be read safely.', 502, 'unsupported_response', { importStage: 'playlist_stream' });
  } finally {
    if (!entryLimitReached) await reader.cancel().catch(() => {});
  }
  const category = responseCategory(firstContent);
  throwForResponseCategory(category);
  // Xtream providers frequently label valid M3U as a generic or missing MIME type.
  // The bounded, parsed M3U body is therefore the acceptance criterion; HTML, JSON,
  // and unknown bodies remain rejected above.
  return { items: entries, entryLimitReached };
}

async function fetchValidatedDestination(url, { fetchImpl, lookup, allowHttp, hostAllowlist, timeoutMs, headers }) {
  const { records } = await resolveDestination(url.toString(), { lookup, allowHttp, hostAllowlist });
  const signal = AbortSignal.timeout(timeoutMs);
  // Tests may inject a transport, but destination validation still runs. The
  // production path additionally pins the actual socket to these exact answers.
  if (fetchImpl) return { response: await fetchImpl(url, { method: 'GET', redirect: 'manual', signal, headers }), close: async () => {}, signal };
  const { createPinnedDispatcher } = await import('./pinned-transport.mjs');
  const { fetch: undiciFetch } = await import('undici');
  const pinnedLookup = async () => records;
  const { dispatcher } = createPinnedDispatcher({
    lookup: pinnedLookup, allowHttp, hostAllowlist, connections: 1, pipelining: 0,
    connectTimeout: timeoutMs, headersTimeout: timeoutMs, bodyTimeout: 0,
  });
  try {
    const response = await undiciFetch(url, {
      method: 'GET', redirect: 'manual', signal, headers, dispatcher,
    });
    return { response, close: () => dispatcher.close(), signal };
  } catch (error) {
    await dispatcher.close().catch(() => {});
    throw error;
  }
}

async function importValidatedPlaylist(initialUrl, { fetchImpl, lookup, allowHttp, hostAllowlist, timeoutMs, maxBytes, maxEntries, onItem }) {
  let current = initialUrl;
  for (let redirectCount = 0; redirectCount <= 3; redirectCount += 1) {
    let transport;
    try { transport = await fetchValidatedDestination(current, { fetchImpl, lookup, allowHttp, hostAllowlist, timeoutMs, headers: { Accept: 'application/x-mpegURL, application/vnd.apple.mpegurl, text/plain' } }); }
    catch (error) { if (error?.name === 'TimeoutError' || error?.name === 'AbortError') throw new ConnectorError('The provider request timed out.', 504, 'provider_timeout', { importStage: 'network' }); if (error instanceof ConnectorError) throw error; throw new ConnectorError('The provider could not be reached.', 502, 'provider_unreachable', { importStage: 'network' }); }
    const { response, signal } = transport;
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get('location');
      await response.body?.cancel().catch(() => {});
      await transport.close().catch(() => {});
      if (!location || redirectCount === 3) throw new ConnectorError('The provider redirect could not be followed safely.', 502, 'unsupported_response');
      try { current = new URL(location, current); } catch { throw new ConnectorError('The provider redirect could not be followed safely.', 502, 'unsupported_response'); }
      continue;
    }
    if (!response.ok) { await response.body?.cancel().catch(() => {}); await transport.close().catch(() => {}); throw new ConnectorError('The provider rejected the playlist request or returned an error.', 502, 'provider_http_error', { providerStatus: response.status }); }
    let parsed;
    try {
      const { items, entryLimitReached } = await streamMetadataFromM3U(response, { maxBytes, maxEntries, onItem, signal });
      if (!items.length) throw new ConnectorError('The provider returned no readable playlist entries.', 422, 'playlist_invalid');
      parsed = { items, entryLimitReached };
    } finally { await transport.close().catch(() => {}); }
    const { items, entryLimitReached } = parsed;
    return {
      items,
      entryLimitReached,
      playbackNotice: entryLimitReached
        ? `The ${maxEntries}-entry import cap was reached. Further provider entries were not read; narrow the provider playlist to access additional entries.`
        : 'Provider metadata was imported. Select a live item to request secure, session-bound playback through the same-origin proxy.',
    };
  }
  throw new ConnectorError('The provider redirect could not be followed safely.', 502, 'unsupported_response');
}

function isXtreamPlaylistUrl(url) {
  return url.pathname.toLowerCase().endsWith('/get.php')
    && url.searchParams.has('username')
    && url.searchParams.has('password');
}

async function readLimitedJson(response, { maxBytes, signal, importAction }) {
  const declared = Number(response.headers.get('content-length') || 0);
  if (declared > maxBytes) throw new ConnectorError('The provider live-channel response is too large to import safely.', 413, 'playlist_too_large');
  if (!/^application\/json(?:;|$)/i.test(response.headers.get('content-type') || '')) throw new ConnectorError('The provider live-channel response was not JSON.', 502, 'unsupported_response', { responseCategory: 'non_json' });
  const reader = response.body?.getReader();
  if (!reader) throw new ConnectorError('The provider live-channel response could not be read safely.', 502, 'unsupported_response', { responseCategory: 'unreadable' });
  const chunks = []; let bytes = 0;
  try {
    while (true) {
      if (signal.aborted) throw new DOMException('Timed out', 'TimeoutError');
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > maxBytes) throw new ConnectorError('The provider live-channel response is too large to import safely.', 413, 'playlist_too_large');
      chunks.push(value);
    }
  } catch (error) {
    if (error instanceof ConnectorError) throw error;
    if (signal.aborted || error?.name === 'TimeoutError' || error?.name === 'AbortError') throw new ConnectorError('The provider request timed out while reading live channels.', 504, 'provider_timeout', { importStage: 'live_json', importAction });
    throw new ConnectorError('The provider live-channel response could not be read safely.', 502, 'unsupported_response', { responseCategory: 'unreadable' });
  } finally {
    await reader.cancel().catch(() => {});
  }
  try { return JSON.parse(new TextDecoder().decode(Buffer.concat(chunks))); }
  catch { throw new ConnectorError('The provider live-channel response was not valid JSON.', 502, 'unsupported_response', { responseCategory: 'invalid_json' }); }
}

async function fetchValidatedXtreamJson(initialUrl, { fetchImpl, lookup, allowHttp, hostAllowlist, timeoutMs, expectArray = true, importAction = 'catalogue' }) {
  let current = initialUrl;
  for (let redirectCount = 0; redirectCount <= 3; redirectCount += 1) {
    let transport;
    try { transport = await fetchValidatedDestination(current, { fetchImpl, lookup, allowHttp, hostAllowlist, timeoutMs, headers: { Accept: 'application/json' } }); }
    catch (error) { if (error?.name === 'TimeoutError' || error?.name === 'AbortError') throw new ConnectorError('The provider request timed out.', 504, 'provider_timeout', { importStage: 'live_json', importAction }); if (error instanceof ConnectorError) throw error; throw new ConnectorError('The provider could not be reached.', 502, 'provider_unreachable', { importStage: 'live_json' }); }
    const { response, signal } = transport;
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get('location');
      await response.body?.cancel().catch(() => {}); await transport.close().catch(() => {});
      if (!location || redirectCount === 3) throw new ConnectorError('The provider redirect could not be followed safely.', 502, 'unsupported_response');
      try { current = new URL(location, current); } catch { throw new ConnectorError('The provider redirect could not be followed safely.', 502, 'unsupported_response'); }
      continue;
    }
    if (!response.ok) { await response.body?.cancel().catch(() => {}); await transport.close().catch(() => {}); throw new ConnectorError('The provider rejected the live-channel request or returned an error.', 502, 'provider_http_error', { providerStatus: response.status }); }
    try {
      const body = await readLimitedJson(response, { maxBytes: MAX_XTREAM_API_BYTES, signal, importAction });
      if (expectArray ? !Array.isArray(body) : (!body || typeof body !== 'object' || Array.isArray(body))) throw new ConnectorError('The provider returned an unexpected JSON structure.', 502, 'unsupported_response', { responseCategory: 'unexpected_json_shape' });
      return body;
    } finally { await transport.close().catch(() => {}); }
  }
  throw new ConnectorError('The provider redirect could not be followed safely.', 502, 'unsupported_response');
}

function xtreamLiveUrl(origin, username, password, streamId) {
  return `${origin}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${encodeURIComponent(streamId)}.${XTREAM_LIVE_EXTENSION}`;
}

async function importXtreamLiveChannels(playlistUrl, settings, onItem) {
  const username = playlistUrl.searchParams.get('username');
  const password = playlistUrl.searchParams.get('password');
  if (!username || !password) throw new ConnectorError('The Xtream playlist URL must contain non-empty credentials.', 400, 'invalid_request');
  const apiUrl = new URL('/player_api.php', playlistUrl.origin);
  const apiRequest = async (action) => {
    apiUrl.search = new URLSearchParams({ username, password, action }).toString();
    return fetchValidatedXtreamJson(new URL(apiUrl), { ...settings, importAction: action });
  };
  const categories = await apiRequest('get_live_categories');
  const categoryNames = new Map(categories.map((category) => [String(category?.category_id ?? ''), typeof category?.category_name === 'string' && category.category_name.trim() ? category.category_name.trim() : 'Uncategorized']));
  const streams = await apiRequest('get_live_streams');
  if (streams.length > MAX_XTREAM_LIVE_ENTRIES) throw new ConnectorError('The provider returned too many live channels to import safely.', 413, 'playlist_too_large');
  const items = [];
  for (const stream of streams) {
    const streamId = typeof stream?.stream_id === 'string' || typeof stream?.stream_id === 'number' ? String(stream.stream_id).trim() : '';
    const name = typeof stream?.name === 'string' ? stream.name.trim() : '';
    if (!streamId || !name) continue;
    const group = categoryNames.get(String(stream.category_id ?? '')) ?? 'Uncategorized';
    const item = { id: `provider-${items.length}`, name, group, ...(typeof stream.stream_icon === 'string' && stream.stream_icon ? { logo: stream.stream_icon } : {}), kind: 'live', playbackBlocked: true };
    items.push(item);
    onItem?.({ id: item.id, kind: item.kind, upstreamUrl: xtreamLiveUrl(playlistUrl.origin, username, password, streamId) });
  }
  if (!items.length) throw new ConnectorError('The provider returned no readable live channels.', 422, 'playlist_invalid');
  const result = { items, entryLimitReached: false, playbackNotice: 'Live channel metadata was imported. Select a live item to request secure, session-bound playback through the same-origin proxy.' };
  xtreamCatalogDescriptors.set(result, { origin: playlistUrl.origin, username, password });
  return result;
}

const xtreamCatalogDescriptors = new WeakMap();

export function getXtreamCatalogDescriptor(result) {
  return result && typeof result === 'object' ? xtreamCatalogDescriptors.get(result) : undefined;
}

function xtreamValue(value, maxLength = 256) {
  if (typeof value !== 'string' && typeof value !== 'number') return undefined;
  const normalized = String(value).trim();
  return normalized && normalized.length <= maxLength ? normalized : undefined;
}

function xtreamVodCategory(category) {
  const id = xtreamValue(category?.category_id);
  const name = xtreamValue(category?.category_name);
  return id && name ? { id, name } : undefined;
}

function xtreamSeriesItem(series) {
  const id = xtreamValue(series?.series_id);
  const name = xtreamValue(series?.name);
  if (!id || !name) return undefined;
  const icon = xtreamVodIcon(series?.cover);
  const year = xtreamValue(series?.releaseDate ?? series?.year, 32);
  const rating = xtreamValue(series?.rating ?? series?.rating_5based, 32);
  return { id, name, ...(icon ? { icon } : {}), ...(year ? { year } : {}), ...(rating ? { rating } : {}) };
}

function xtreamVodIcon(value) {
  const raw = xtreamValue(value, 2_048);
  if (!raw) return undefined;
  let url;
  try { url = new URL(raw); } catch { return undefined; }
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.hash) return undefined;
  if ([...url.searchParams.keys()].some((key) => /(?:password|username|token|authorization|secret|api[_-]?key)/i.test(key))) return undefined;
  return url.toString();
}

function xtreamVodItem(stream) {
  const id = xtreamValue(stream?.stream_id);
  const name = xtreamValue(stream?.name);
  if (!id || !name) return undefined;
  const item = { id, name };
  const icon = xtreamVodIcon(stream?.stream_icon);
  const year = xtreamValue(stream?.year, 32);
  const rating = xtreamValue(stream?.rating ?? stream?.rating_5based, 32);
  // This value is intentionally retained only in the server-side page metadata
  // map. It is never included in the VOD JSON returned to the browser.
  const containerExtension = xtreamValue(stream?.container_extension, 32);
  return { item: { ...item, ...(icon ? { icon } : {}), ...(year ? { year } : {}), ...(rating ? { rating } : {}) }, containerExtension };
}

function xtreamCatalogRequestUrl(catalog, action, categoryId) {
  if (!catalog || typeof catalog.origin !== 'string' || typeof catalog.username !== 'string' || typeof catalog.password !== 'string') {
    throw new ConnectorError('The VOD catalogue is not available for this session.', 403, 'vod_catalog_unavailable');
  }
  const apiUrl = new URL('/player_api.php', catalog.origin);
  apiUrl.search = new URLSearchParams({ username: catalog.username, password: catalog.password, action, ...(categoryId ? (action === 'get_series_info' ? { series_id: categoryId } : { category_id: categoryId }) : {}) }).toString();
  return apiUrl;
}

function xtreamMovieExtension(value) {
  const extension = xtreamValue(value, 32)?.toLowerCase();
  return extension && XTREAM_MOVIE_EXTENSIONS.has(extension) ? extension : XTREAM_MOVIE_EXTENSION;
}

function xtreamMovieUrl(catalog, movieId, containerExtension) {
  const safeMovieId = xtreamValue(movieId);
  if (!safeMovieId || !catalog || typeof catalog.origin !== 'string' || typeof catalog.username !== 'string' || typeof catalog.password !== 'string') {
    throw new ConnectorError('The movie is not available for this session.', 403, 'vod_catalog_unavailable');
  }
  // Xtream-style movie endpoints commonly use MP4. This is an assumed provider
  // path format and is only constructed after the server authorizes the movie ID.
  return `${catalog.origin}/movie/${encodeURIComponent(catalog.username)}/${encodeURIComponent(catalog.password)}/${encodeURIComponent(safeMovieId)}.${xtreamMovieExtension(containerExtension)}`;
}

export function getXtreamVodItemExtensions(page) {
  return xtreamVodPageExtensions.get(page) ?? new Map();
}

export function getXtreamSeriesItemExtensions(page) {
  return xtreamSeriesPageExtensions.get(page) ?? new Map();
}

export function createXtreamVodCatalog(options = {}) {
  const settings = connectorOptions(options);
  return {
    async categories(catalog) {
      const body = await fetchValidatedXtreamJson(xtreamCatalogRequestUrl(catalog, 'get_vod_categories'), settings);
      const categories = body.map(xtreamVodCategory).filter(Boolean);
      if (!categories.length) throw new ConnectorError('The provider returned no readable movie categories.', 422, 'playlist_invalid');
      return categories;
    },
    async items(catalog, { categoryId, offset = 0, limit = MAX_XTREAM_VOD_PAGE_SIZE } = {}) {
      const safeCategoryId = xtreamValue(categoryId);
      if (!safeCategoryId || !Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(limit) || limit < 1 || limit > MAX_XTREAM_VOD_PAGE_SIZE) {
        throw new ConnectorError('The movie catalogue request is invalid.', 400, 'invalid_request');
      }
      const body = await fetchValidatedXtreamJson(xtreamCatalogRequestUrl(catalog, 'get_vod_streams', safeCategoryId), settings);
      const mapped = body.map(xtreamVodItem).filter(Boolean);
      const entries = mapped.slice(offset, offset + limit);
      const page = { items: entries.map((entry) => entry.item), offset, limit, hasMore: mapped.length > offset + limit };
      xtreamVodPageExtensions.set(page, new Map(entries.map((entry) => [entry.item.id, entry.containerExtension])));
      return page;
    },
    movieUrl(catalog, movieId, containerExtension) {
      return xtreamMovieUrl(catalog, movieId, containerExtension);
    },
  };
}

export function createXtreamSeriesCatalog(options = {}) {
  const settings = connectorOptions(options);
  return {
    async categories(catalog) {
      const body = await fetchValidatedXtreamJson(xtreamCatalogRequestUrl(catalog, 'get_series_categories'), settings);
      const categories = body.map(xtreamVodCategory).filter(Boolean);
      return categories;
    },
    async items(catalog, { categoryId, offset = 0, limit = MAX_XTREAM_VOD_PAGE_SIZE } = {}) {
      const safeCategoryId = xtreamValue(categoryId);
      if (!safeCategoryId || !Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(limit) || limit < 1 || limit > MAX_XTREAM_VOD_PAGE_SIZE) {
        throw new ConnectorError('The series catalogue request is invalid.', 400, 'invalid_request');
      }
      const body = await fetchValidatedXtreamJson(xtreamCatalogRequestUrl(catalog, 'get_series', safeCategoryId), settings);
      const mapped = body.map(xtreamSeriesItem).filter(Boolean);
      const entries = mapped.slice(offset, offset + limit);
      return { items: entries, offset, limit, hasMore: mapped.length > offset + limit };
    },
    async episodes(catalog, seriesId) {
      const safeSeriesId = xtreamValue(seriesId);
      if (!safeSeriesId) throw new ConnectorError('The series selection is invalid.', 400, 'invalid_request');
      const body = await fetchValidatedXtreamJson(xtreamCatalogRequestUrl(catalog, 'get_series_info', safeSeriesId), { ...settings, expectArray: false });
      const seasons = Array.isArray(body?.seasons) ? body.seasons : [];
      const rawEpisodes = body?.episodes && typeof body.episodes === 'object' ? body.episodes : {};
      const seasonNames = new Map(seasons.map((season) => [String(season?.season_number ?? season?.id ?? ''), xtreamValue(season?.name, 128)]));
      const episodeMap = new Map();
      const result = [];
      for (const [seasonKey, list] of Object.entries(rawEpisodes)) {
        if (!Array.isArray(list)) continue;
        for (const episode of list) {
          const id = xtreamValue(episode?.id);
          const title = xtreamValue(episode?.title ?? episode?.name);
          if (!id || !title) continue;
          const extension = xtreamValue(episode?.container_extension, 16)?.toLowerCase();
          const safeExtension = extension && XTREAM_SERIES_EXTENSIONS.has(extension) ? extension : 'mp4';
          const season = xtreamValue(episode?.season ?? seasonKey, 32) ?? seasonKey;
          const episodeNumber = xtreamValue(episode?.episode_num, 32);
          const info = episode?.info && typeof episode.info === 'object' ? episode.info : {};
          const cover = xtreamVodIcon(info.movie_image ?? info.cover_big);
          const item = { id, title, season, ...(seasonNames.get(season) ? { seasonName: seasonNames.get(season) } : {}), ...(episodeNumber ? { episodeNumber } : {}), ...(cover ? { icon: cover } : {}), ...(xtreamValue(info.plot, 1000) ? { plot: xtreamValue(info.plot, 1000) } : {}) };
          result.push(item);
          episodeMap.set(id, safeExtension);
        }
      }
      xtreamSeriesPageExtensions.set(result, episodeMap);
      return { episodes: result };
    },
    episodeUrl(catalog, episodeId, extension) {
      const safeId = xtreamValue(episodeId);
      const safeExtension = xtreamValue(extension, 16)?.toLowerCase();
      if (!safeId || !safeExtension || !XTREAM_SERIES_EXTENSIONS.has(safeExtension) || !catalog || typeof catalog.origin !== 'string' || typeof catalog.username !== 'string' || typeof catalog.password !== 'string') {
        throw new ConnectorError('The episode is not available for playback.', 403, 'series_episode_unavailable');
      }
      return `${catalog.origin}/series/${encodeURIComponent(catalog.username)}/${encodeURIComponent(catalog.password)}/${encodeURIComponent(safeId)}.${safeExtension}`;
    },
  };
}

function connectorOptions(options = {}) {
  return {
    fetchImpl: options.fetchImpl,
    lookup: options.lookup,
    allowHttp: options.allowHttp ?? true,
    hostAllowlist: options.hostAllowlist ?? (process.env.PROVIDER_HOST_ALLOWLIST || '').split(',').map((host) => host.trim().toLowerCase()).filter(Boolean),
    timeoutMs: options.timeoutMs ?? providerRequestTimeoutMs(),
    maxBytes: options.maxBytes ?? MAX_PLAYLIST_TRANSPORT_BYTES,
    maxEntries: options.maxEntries ?? MAX_PLAYLIST_ENTRIES,
  };
}

export function createRemotePlaylistImporter(options = {}) {
  const settings = connectorOptions(options);
  return async ({ playlistUrl }, { onItem } = {}) => {
    if (typeof playlistUrl !== 'string' || !playlistUrl.trim() || playlistUrl.length > 8_192) throw new ConnectorError('Provide a full playlist URL.', 400, 'invalid_request');
    const initialUrl = await validateDestination(playlistUrl.trim(), settings);
    const registry = createProviderAdapterRegistry([
      {
        id: 'xtream-playlist',
        detect: (url) => isXtreamPlaylistUrl(url),
        import: (url, context) => importXtreamLiveChannels(url, settings, context.onItem),
      },
      {
        id: 'm3u',
        detect: () => true,
        import: (url, context) => importValidatedPlaylist(url, { ...settings, onItem: context.onItem }),
      },
    ]);
    const adapter = registry.resolve(initialUrl);
    return adapter.import(initialUrl, { onItem });
  };
}

export function createConnector(options = {}) {
  const settings = connectorOptions(options);
  return async ({ serverUrl, username, password }, { onItem } = {}) => {
    if (typeof serverUrl !== 'string' || typeof username !== 'string' || typeof password !== 'string' || !username || !password || username.length > 256 || password.length > 512) throw new ConnectorError('Provide a provider server URL, username, and password.', 400, 'invalid_request');
    const origin = await validateDestination(serverUrl, settings);
    const playlistUrl = new URL('/get.php', origin);
    playlistUrl.search = new URLSearchParams({ username, password, type: 'm3u_plus', output: 'm3u8' }).toString();
    return importValidatedPlaylist(playlistUrl, { ...settings, onItem });
  };
}

// Xtream Codes connections use the player API, not the get.php M3U export.
// This creates the server-side catalogue descriptor required for lazy VOD and
// series catalogue requests while keeping credentials out of client responses.
export function createXtreamConnector(options = {}) {
  const settings = connectorOptions(options);
  return async ({ serverUrl, username, password }, { onItem } = {}) => {
    if (typeof serverUrl !== 'string' || typeof username !== 'string' || typeof password !== 'string' || !username.trim() || !password || username.length > 256 || password.length > 512) {
      throw new ConnectorError('Provide a provider server URL, username, and password.', 400, 'invalid_request');
    }
    const origin = await validateDestination(serverUrl.trim(), settings);
    const playlistUrl = new URL('/get.php', origin);
    playlistUrl.search = new URLSearchParams({ username: username.trim(), password, type: 'm3u_plus', output: 'm3u8' }).toString();
    return importXtreamLiveChannels(playlistUrl, settings, onItem);
  };
}
