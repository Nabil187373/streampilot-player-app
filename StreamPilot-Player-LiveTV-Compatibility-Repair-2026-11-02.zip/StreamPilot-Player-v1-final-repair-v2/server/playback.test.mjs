import './test-env.mjs';
import assert from 'node:assert/strict';
import test from 'node:test';
import { ConnectorError } from './connector.mjs';
import { PlaybackSessions, handleMovieMediaRequest, handlePlaybackRequest, playbackFailureCategory, playbackHostAllowlist, playbackHttpIpRedirectBinding, playbackHttpIpRedirectTrust, playbackProviderDomainTrust, playbackUpstreamCause, playbackUpstreamStage, sessionCookie } from './playback.mjs';

function response() {
  return {
    status: 0, headers: {}, body: '',
    writeHead(status, headers) { this.status = status; this.headers = headers; return this; },
    write(chunk) { this.body += Buffer.from(chunk).toString('utf8'); return true; },
    end(chunk = '') { this.body += Buffer.from(chunk).toString('utf8'); },
    once() {}, destroy() { this.destroyed = true; },
  };
}
function request(path, sessionId) { return { method: 'GET', url: path, headers: { cookie: `sp_playback_session=${sessionId}` } }; }
function newSession(now = () => Date.now()) {
  const sessions = new PlaybackSessions({ now });
  const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://cdn.example/live/master.m3u8?token=private' }]);
  return { sessions, id };
}
function newTrustedHttpSourceSession() {
  const sessions = new PlaybackSessions();
  const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'http://cdn.example:2086/live/master.m3u8' }]);
  return { sessions, id };
}
const publicLookup = async () => [{ address: '93.184.216.34', family: 4 }];



test('movie media binds a one-hop public IP redirect to its own allowlisted provider origin in development', async () => {
  const previousNodeEnv = process.env.NODE_ENV;
  const previousTrust = process.env.PLAYBACK_MEDIA_IP_REDIRECT_TRUST;
  process.env.NODE_ENV = 'development';
  delete process.env.PLAYBACK_MEDIA_IP_REDIRECT_TRUST;
  const req = {
    method: 'GET', url: '/media/grant123', headers: { cookie: 'sp_playback_session=session123' },
    once() {}, removeListener() {},
  };
  const res = response();
  const dials = []; let calls = 0; let dispatcherClosed = 0;
  try {
    await handleMovieMediaRequest(req, res, {
      allowHttp: true,
      hostAllowlist: ['ts.linkmac.uk'],
      lookup: async (hostname) => {
        assert.equal(hostname, 'ts.linkmac.uk');
        return publicLookup();
      },
      resolveAuthorizedMovie: async () => ({ upstreamUrl: 'http://ts.linkmac.uk:2086/movie/authorized.mp4' }),
      boundIpRedirectDispatcherFactory: ({ destinationIp }) => {
        dials.push(destinationIp);
        return { close: async () => { dispatcherClosed += 1; } };
      },
      fetchImpl: async (url, options) => {
        calls += 1;
        if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://117.55.202.180:2086/movie/authorized.mp4' } });
        assert.equal(new URL(url).hostname, '117.55.202.180');
        assert.ok(options.dispatcher);
        return new Response(Buffer.from('movie-bytes'), { headers: { 'content-type': 'video/mp4', 'content-length': '11', 'accept-ranges': 'bytes' } });
      },
    });
    assert.equal(res.status, 200);
    assert.equal(res.body, 'movie-bytes');
    assert.equal(calls, 2);
    assert.deepEqual(dials, ['117.55.202.180']);
    assert.equal(dispatcherClosed, 1);
  } finally {
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = previousNodeEnv;
    if (previousTrust === undefined) delete process.env.PLAYBACK_MEDIA_IP_REDIRECT_TRUST; else process.env.PLAYBACK_MEDIA_IP_REDIRECT_TRUST = previousTrust;
  }
});

test('production permits a one-hop public movie IP redirect with a pinned dispatcher and no compatibility setting', async () => {
  const previousNodeEnv = process.env.NODE_ENV;
  const previousTrust = process.env.PLAYBACK_MEDIA_IP_REDIRECT_TRUST;
  process.env.NODE_ENV = 'production';
  delete process.env.PLAYBACK_MEDIA_IP_REDIRECT_TRUST;
  const req = {
    method: 'GET', url: '/media/grant123', headers: { cookie: 'sp_playback_session=session123' },
    once() {}, removeListener() {},
  };
  const res = response();
  let calls = 0; let pinned = 0; let closed = 0;
  try {
    await handleMovieMediaRequest(req, res, {
      allowHttp: true,
      hostAllowlist: ['ts.linkmac.uk'],
      lookup: publicLookup,
      resolveAuthorizedMovie: async () => ({ upstreamUrl: 'http://ts.linkmac.uk:2086/movie/authorized.mp4' }),
      boundIpRedirectDispatcherFactory: ({ destinationIp }) => {
        assert.equal(destinationIp, '117.55.202.180');
        pinned += 1;
        return { close: async () => { closed += 1; } };
      },
      fetchImpl: async (url, options) => {
        calls += 1;
        if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://117.55.202.180:2086/movie/authorized.mp4' } });
        assert.ok(options.dispatcher);
        return new Response(Buffer.from('movie-bytes'), { headers: { 'content-type': 'video/mp4', 'content-length': '11' } });
      },
    });
    assert.equal(res.status, 200);
    assert.equal(res.body, 'movie-bytes');
    assert.equal(calls, 2);
    assert.equal(pinned, 1);
    assert.equal(closed, 1);
  } finally {
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = previousNodeEnv;
    if (previousTrust === undefined) delete process.env.PLAYBACK_MEDIA_IP_REDIRECT_TRUST; else process.env.PLAYBACK_MEDIA_IP_REDIRECT_TRUST = previousTrust;
  }
});

test('sessions isolate playback grants, reject unknown items, and expire grants with their session', () => {
  let now = 0;
  const { sessions, id } = newSession(() => now);
  const other = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://cdn.example/live/other.m3u8' }]);
  const grant = sessions.createGrant(id, 'live-1');
  assert.throws(() => sessions.getGrant(other, grant), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
  assert.throws(() => sessions.createGrant(id, 'movie-1'), (error) => error instanceof ConnectorError && error.code === 'playback_item_not_found');
  now = 16 * 60_000;
  assert.throws(() => sessions.getGrant(id, grant), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
  assert.equal(sessions.createSession([{ id: 'movie-1', kind: 'movie', upstreamUrl: 'https://cdn.example/movie.mp4' }]), undefined);
});


test('live playback grant renewal recovers an expired short grant while the session remains valid', () => {
  let now = 0;
  const sessions = new PlaybackSessions({ now: () => now, sessionTtlMs: 15 * 60_000, sessionAbsoluteTtlMs: 60 * 60_000, grantTtlMs: 5 * 60_000 });
  const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://cdn.example/live.m3u8' }]);
  const original = sessions.createGrant(id, 'live-1');
  now = 5 * 60_000 + 1;
  assert.throws(() => sessions.getGrant(id, original), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
  const renewed = sessions.renewGrant(id, original);
  assert.notEqual(renewed.grantId, original);
  assert.equal(sessions.getGrant(id, renewed.grantId).item.id, 'live-1');
  assert.ok(renewed.maxAgeSeconds > 0);
});

test('live playback requests slide the session and grant expiry and refresh the HttpOnly cookie', async () => {
  let now = 0;
  const sessions = new PlaybackSessions({ now: () => now, sessionTtlMs: 15 * 60_000, sessionAbsoluteTtlMs: 60 * 60_000, grantTtlMs: 5 * 60_000 });
  const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://cdn.example/live/master.m3u8' }]);
  const grant = sessions.createGrant(id, 'live-1');
  now = 4 * 60_000;
  const res = response();
  await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), res, {
    sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'],
    fetchImpl: async () => new Response('#EXTM3U\n#EXTINF:6,\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }),
  });
  assert.match(res.headers['set-cookie'], /HttpOnly/);
  assert.ok(sessions.getGrant(id, grant).grant.expiresAt > now);
});

test('HLS manifest rewriting hides upstream URLs and rewrites segment and key references', async () => {
  const { sessions, id } = newSession();
  const grant = sessions.createGrant(id, 'live-1');
  const res = response();
  let upstreamRequests = 0;
  const manifest = '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="keys/key.bin"\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nvariant.m3u8\n#EXTINF:6,\nsegments/one.ts\n';
  const handled = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), res, {
    sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'],
    fetchImpl: async () => { upstreamRequests += 1; return new Response(manifest, { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }); },
  });
  assert.equal(handled, true);
  assert.equal(upstreamRequests, 1);
  assert.equal(res.status, 200);
  assert.equal(res.headers['cache-control'], 'no-store');
  assert.match(res.body, /\/api\/playback\/[A-Za-z0-9_-]+\/asset\/[A-Za-z0-9_-]+/);
  assert.equal(res.body.includes('cdn.example'), false);
  assert.equal(res.body.includes('private'), false);
  assert.equal(res.body.includes('keys/key.bin'), false);
  assert.equal(res.body.includes('segments/one.ts'), false);
  const stages = [...sessions.getGrant(id, grant).grant.assets.values()].map((asset) => asset.playbackStage).sort();
  assert.deepEqual(stages, ['key', 'nested_playlist', 'segment']);
});


test('rewrites URI attributes for session keys/data, low-latency parts, preload hints, and rendition reports', async () => {
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); const res = response();
  const manifest = [
    '#EXTM3U',
    '#EXT-X-SESSION-KEY:METHOD=AES-128,URI="session.key"',
    '#EXT-X-SESSION-DATA:DATA-ID="com.example.meta",URI="session.json"',
    '#EXT-X-PART:DURATION=0.5,URI="part0.m4s"',
    '#EXT-X-PRELOAD-HINT:TYPE=PART,URI="part1.m4s"',
    '#EXT-X-RENDITION-REPORT:URI="../audio/playlist.m3u8",LAST-MSN=1',
  ].join('\n');
  await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), res, {
    sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'],
    fetchImpl: async () => new Response(manifest, { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }),
  });
  assert.equal((res.body.match(/URI="\/api\/playback\//g) || []).length, 5);
  const stages = [...sessions.getGrant(id, grant).grant.assets.values()].map((asset) => asset.playbackStage);
  assert.deepEqual(stages.sort(), ['key', 'nested_playlist', 'segment', 'segment', 'segment']);
});


test('live playback passes a DNS-pinned dispatcher to the outbound transport', async () => {
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); const res = response();
  let dispatcherSeen;
  await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), res, {
    sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'],
    fetchImpl: async (_url, options) => {
      dispatcherSeen = options.dispatcher;
      return new Response('#EXTM3U\n#EXTINF:6,\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  assert.ok(dispatcherSeen, 'a validated hostname must never fall back to global fetch without a pinned dispatcher');
});

test('rejects a private playback destination before it is fetched', async () => {
  const previousDiagnostics = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  process.env.NODE_ENV = 'test';
  try {
    const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); let fetched = false;
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, lookup: async () => [{ address: '127.0.0.1', family: 4 }], hostAllowlist: ['cdn.example'],
      fetchImpl: async () => { fetched = true; return new Response(); },
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    assert.equal(fetched, false);
    const diagnostic = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'host_not_allowed', stage: 'initial_live_stream' });
  } finally {
    if (previousDiagnostics === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previousDiagnostics;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('local host diagnostics expose only a rejected DNS hostname and fixed playback stage', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1';
  process.env.NODE_ENV = 'development';
  try {
    const sessions = new PlaybackSessions();
    const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://blocked.example/live/master.m3u8?secret=value' }]);
    const grant = sessions.createGrant(id, 'live-1');
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, lookup: async () => [{ address: '10.0.0.8', family: 4 }], hostAllowlist: ['approved.example'], fetchImpl: async () => new Response('#EXTM3U\n#EXTINF:-1,Fixture\nsegment.ts'),
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    const diagnostic = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'host_not_allowed', stage: 'initial_live_stream', requestPhase: 'manifest', redirectCount: 0, rejectedHostname: 'blocked.example', rejectedScheme: 'https', destinationRejection: 'resolved_address_not_allowed' });
    assert.equal(diagnostic.body.includes('secret'), false);
    assert.equal(diagnostic.body.includes('https:'), false);
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('maps only fixed playback diagnostics and leaves unexpected errors generic', () => {
  assert.equal(playbackFailureCategory(new ConnectorError('safe', 401, 'playback_unauthorized')), 'session_expired');
  assert.equal(playbackFailureCategory(new ConnectorError('safe', 502, 'playback_redirect_rejected')), 'redirect_rejected');
  assert.equal(playbackFailureCategory(new ConnectorError('safe', 502, 'unsupported_response'), { phase: 'asset' }), 'asset_rejected');
  assert.equal(playbackFailureCategory(new Error('untrusted upstream text')), undefined);
});

test('maps only allowlisted network codes and explicit request stages to safe upstream causes', () => {
  const cases = [
    ['ENOTFOUND', 'dns_failed'], ['ECONNREFUSED', 'connect_refused'], ['ETIMEDOUT', 'connect_timeout'],
    ['UND_ERR_CONNECT_TIMEOUT', 'connect_timeout'], ['UND_ERR_HEADERS_TIMEOUT', 'response_timeout'],
    ['ECONNRESET', 'connection_reset'], ['UND_ERR_SOCKET', 'connection_reset'],
    ['ERR_TLS_CERT_ALTNAME_INVALID', 'tls_error'], ['PINNED_LOOKUP_ERROR', 'pinned_lookup_error'],
  ];
  for (const [code, cause] of cases) {
    const error = new Error('private transport text'); error.code = code;
    assert.equal(playbackUpstreamCause(error), cause, code);
  }
  assert.equal(playbackUpstreamCause({ cause: { code: 'ECONNREFUSED' } }), 'connect_refused');
  assert.equal(playbackUpstreamCause(new Error('private transport text')), 'unknown');
  assert.equal(playbackUpstreamStage('initial_live_stream', 'manifest'), 'manifest');
  assert.equal(playbackUpstreamStage('redirect', 'manifest'), 'redirect');
  assert.equal(playbackUpstreamStage('segment', 'asset'), 'asset');
});

test('returns only fixed upstream cause diagnostics for simulated failures at manifest, redirect, and asset stages', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1'; process.env.NODE_ENV = 'development';
  const cases = [
    ['ENOTFOUND', 'dns_failed'], ['ECONNREFUSED', 'connect_refused'], ['ETIMEDOUT', 'connect_timeout'],
    ['UND_ERR_HEADERS_TIMEOUT', 'response_timeout'], ['ECONNRESET', 'connection_reset'],
    ['ERR_TLS_CERT_ALTNAME_INVALID', 'tls_error'], ['PINNED_LOOKUP_ERROR', 'pinned_lookup_error'],
  ];
  const safeError = (code) => { const error = new Error('credential-bearing fixture text'); error.code = code; return error; };
  const expectedDiagnostic = (upstreamStage, cause, redirects = 0, playbackStage = upstreamStage === 'manifest' ? 'initial_live_stream' : upstreamStage) => ({ ok: true, category: 'upstream_unreachable', stage: playbackStage, requestPhase: upstreamStage === 'asset' ? 'asset' : 'manifest', redirectCount: redirects, upstreamStage, upstreamCause: cause });
  try {
    for (const [code, cause] of cases) {
      // Initial manifest failure.
      {
        const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1');
        await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
          sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'], fetchImpl: async () => { throw safeError(code); },
        }), (error) => error instanceof ConnectorError && playbackFailureCategory(error) === 'upstream_unreachable');
        const diagnostic = response(); await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
        assert.deepEqual(JSON.parse(diagnostic.body), expectedDiagnostic('manifest', cause));
      }

      // Redirect target failure, after the only permitted source-to-IP binding.
      {
        const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1');
        await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
          sessions, lookup: publicLookup, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectBinding: { sourceHostname: 'cdn.example', destinationIp: '93.184.216.34' },
          fetchImpl: async (url) => String(url).includes('93.184.216.34')
            ? Promise.reject(safeError(code))
            : new Response('', { status: 302, headers: { location: 'http://93.184.216.34:2086/fixture.m3u8?token=private' } }),
          boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
        }), (error) => error instanceof ConnectorError && playbackFailureCategory(error) === 'upstream_unreachable');
        const diagnostic = response(); await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
        assert.deepEqual(JSON.parse(diagnostic.body), expectedDiagnostic('redirect', cause, 1));
      }

      // An HLS asset failure after the manifest is accepted and rewritten.
      {
        const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); const manifest = response();
        await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), manifest, {
          sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'],
          fetchImpl: async () => new Response(`#EXTM3U
#EXTINF:1,Fixture
segment.ts
`, { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }),
        });
        const assetPath = manifest.body.match(/\/api\/playback\/[A-Za-z0-9_-]+\/asset\/[A-Za-z0-9_-]+/)?.[0];
        assert.ok(assetPath);
        await assert.rejects(() => handlePlaybackRequest(request(assetPath, id), response(), {
          sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'], fetchImpl: async () => { throw safeError(code); },
        }), (error) => error instanceof ConnectorError && playbackFailureCategory(error, { phase: 'asset' }) === 'upstream_unreachable');
        const diagnostic = response(); await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
        assert.deepEqual(JSON.parse(diagnostic.body), expectedDiagnostic('asset', cause, 0, 'segment'));
        assert.equal(diagnostic.body.includes('credential-bearing'), false);
        assert.equal(diagnostic.body.includes('cdn.example'), false);
        assert.equal(diagnostic.body.includes('private'), false);
      }
    }
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS; else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('keeps provider HTTP status failures distinct from unreachable transport failures', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1'; process.env.NODE_ENV = 'development';
  try {
    for (const status of [403, 404, 500]) {
      const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1');
      await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
        sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'], fetchImpl: async () => new Response('', { status }),
      }), (error) => error instanceof ConnectorError && error.code === 'provider_http_error');
      const diagnostic = response();
      await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
      assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'upstream_unreachable', stage: 'initial_live_stream', requestPhase: 'manifest', redirectCount: 0, upstreamStage: 'manifest', upstreamCause: 'upstream_http_status', upstreamHttpStatus: status });
    }
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS; else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('uses a response deadline only until headers and an idle deadline between playback body chunks', async () => {
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1');
  const steadyBody = new ReadableStream({
    start(controller) {
      setTimeout(() => controller.enqueue(new TextEncoder().encode('#EXTM3U\n')), 3);
      setTimeout(() => controller.enqueue(new TextEncoder().encode('#EXTINF:1,Channel\n')), 7);
      setTimeout(() => controller.enqueue(new TextEncoder().encode('segment.ts\n')), 11);
      setTimeout(() => controller.close(), 15);
    },
  });
  const output = response();
  await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), output, {
    sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'], timeoutMs: 8,
    fetchImpl: async () => new Response(steadyBody, { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }),
  });
  assert.equal(output.status, 200);
  assert.match(output.body, /^#EXTM3U/);

  const stalledSessions = new PlaybackSessions();
  const stalledId = stalledSessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://cdn.example/live/master.m3u8' }]);
  const stalledGrant = stalledSessions.createGrant(stalledId, 'live-1'); let cancelled = false;
  // Keep the first read pending. A closed empty stream would exercise manifest
  // validation rather than the idle timer.
  const stalledBody = new ReadableStream({
    pull() { return new Promise(() => {}); },
    cancel() { cancelled = true; },
  });
  await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${stalledGrant}/manifest.m3u8`, stalledId), response(), {
    sessions: stalledSessions, lookup: publicLookup, hostAllowlist: ['cdn.example'], timeoutMs: 8,
    fetchImpl: async () => new Response(stalledBody, { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }),
  }), (error) => error instanceof ConnectorError && error.code === 'provider_timeout');
  assert.equal(cancelled, true);
});

test('follows a validated public CDN hostname redirect without a deployment allowlist entry', async () => {
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1');
  const requested = [];
  const result = response();
  const handled = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), result, {
    sessions, lookup: publicLookup, hostAllowlist: ['only-the-origin.example'],
    fetchImpl: async (url, options) => {
      requested.push({ hostname: new URL(url).hostname, dispatcher: options.dispatcher });
      if (requested.length === 1) return new Response('', { status: 302, headers: { location: 'https://customer-cdn.example/live/master.m3u8' } });
      return new Response('#EXTM3U\n#EXTINF:6,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  assert.equal(handled, true);
  assert.equal(result.status, 200);
  assert.deepEqual(requested.map((entry) => entry.hostname), ['cdn.example', 'customer-cdn.example']);
  assert.ok(requested[1].dispatcher, 'the CDN hostname must use a dispatcher pinned to its validated DNS answer');
});

test('still rejects a CDN redirect whose DNS resolves to a private address', async () => {
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1');
  let calls = 0;
  await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
    sessions,
    lookup: async (hostname) => hostname === 'cdn.example'
      ? [{ address: '93.184.216.34', family: 4 }]
      : [{ address: '192.168.1.25', family: 4 }],
    hostAllowlist: ['origin-only.example'],
    fetchImpl: async () => { calls += 1; return new Response('', { status: 302, headers: { location: 'https://private-cdn.example/live/master.m3u8' } }); },
  }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
  assert.equal(calls, 1, 'the private CDN destination must never be fetched');
});

test('public IP redirect diagnostics never expose query strings or paths', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1'; process.env.NODE_ENV = 'development';
  try {
    const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1');
    let calls = 0;
    const result = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, lookup: publicLookup, allowHttp: true, hostAllowlist: [],
      boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
      fetchImpl: async () => {
        calls += 1;
        return calls === 1
          ? new Response('', { status: 302, headers: { location: 'http://93.184.216.34:8080/live/master.m3u8?token=secret' } })
          : new Response('#EXTM3U\n#EXTINF:6,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
      },
    });
    assert.equal(result, true); assert.equal(calls, 2);
    const diagnostic = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    assert.equal(diagnostic.body.includes('secret'), false);
    assert.equal(diagnostic.body.includes('/live/master.m3u8'), false);
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS; else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('local diagnostics classify a failed exact bound-IP redirect connection without upstream details', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1';
  process.env.NODE_ENV = 'development';
  try {
    const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1');
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectBinding: { sourceHostname: 'cdn.example', destinationIp: '93.184.216.34' }, lookup: publicLookup,
      fetchImpl: async (url) => {
        if (!String(url).includes('93.184.216.34')) return new Response('', { status: 302, headers: { location: 'http://93.184.216.34:8080/live/master.m3u8?token=secret' } });
        const error = new Error('private transport failure'); error.code = 'ETIMEDOUT'; throw error;
      },
      boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
    }), (error) => error instanceof ConnectorError && error.code === 'provider_timeout');
    const diagnostic = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'upstream_unreachable', stage: 'redirect', requestPhase: 'manifest', redirectCount: 1, upstreamStage: 'redirect', upstreamCause: 'connect_timeout' });
    assert.equal(diagnostic.body.includes('secret'), false);
    assert.equal(diagnostic.body.includes('private transport failure'), false);
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('local redirect diagnostics expose only fixed unknown-error tokens and stay disabled otherwise', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  const run = async ({ diagnostics, nodeEnv, literalRedirect }) => {
    if (diagnostics) process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1'; else delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    process.env.NODE_ENV = nodeEnv;
    const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); let calls = 0;
    const raw = new Error('credential-bearing transport detail');
    raw.name = 'SocketError'; raw.code = 'UNMAPPED_SOCKET'; raw.cause = { code: 'CAUSE_ONE', cause: { code: 'CAUSE_TWO' } };
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, allowHttp: true, hostAllowlist: literalRedirect ? ['cdn.example'] : ['cdn.example', 'redirect.example'],
      httpIpRedirectBinding: literalRedirect ? { sourceHostname: 'cdn.example', destinationIp: '93.184.216.34' } : undefined,
      lookup: publicLookup, boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
      fetchImpl: async (_url, options) => {
        calls += 1;
        if (calls === 1) return new Response('', { status: 302, headers: { location: literalRedirect ? 'http://93.184.216.34:2086/fixture.m3u8?secret=value' : 'http://redirect.example:2086/fixture.m3u8?secret=value' } });
        if (literalRedirect) assert.ok(options.dispatcher);
        throw raw;
      },
    }), (error) => error instanceof ConnectorError && error.code === 'provider_unreachable');
    const diagnostic = response(); await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    return diagnostic.body;
  };
  try {
    const enabled = JSON.parse(await run({ diagnostics: true, nodeEnv: 'development', literalRedirect: true }));
    assert.deepEqual(enabled, {
      ok: true, category: 'upstream_unreachable', stage: 'redirect', requestPhase: 'manifest', redirectCount: 1,
      upstreamStage: 'redirect', upstreamCause: 'unknown', upstreamRequestTarget: 'pinned_redirect_destination',
      upstreamErrorName: 'SocketError', upstreamErrorCode: 'UNMAPPED_SOCKET', upstreamErrorCauseCode: 'CAUSE_ONE', upstreamErrorCauseCauseCode: 'CAUSE_TWO',
      redirectDestinationIp: '93.184.216.34', redirectDestinationPort: 2086,
    });
    assert.equal(JSON.stringify(enabled).includes('credential-bearing'), false);
    assert.equal(JSON.stringify(enabled).includes('secret'), false);

    for (const settings of [{ diagnostics: false, nodeEnv: 'development' }, { diagnostics: true, nodeEnv: 'production' }]) {
      const disabled = JSON.parse(await run({ ...settings, literalRedirect: false }));
      assert.deepEqual(disabled, { ok: true, category: 'upstream_unreachable', stage: 'redirect' });
    }
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS; else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('legacy deployment host allowlists do not block customer-authorized public live provider hosts', async () => {
  const configuredHosts = playbackHostAllowlist('provider.example-provider.test, global.example-provider.test');
  assert.deepEqual(configuredHosts, ['provider.example-provider.test', 'global.example-provider.test']);
  const sessions = new PlaybackSessions();
  const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'http://global.example-provider.test:2086/live/master.m3u8' }]);
  const grant = sessions.createGrant(id, 'live-1');
  const result = response(); let calls = 0;
  const handled = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), result, {
    sessions,
    lookup: publicLookup,
    allowHttp: true,
    hostAllowlist: ['provider.example-provider.test'],
    fetchImpl: async () => { calls += 1; return new Response('#EXTM3U\n#EXTINF:6,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }); },
  });
  assert.equal(handled, true);
  assert.equal(result.status, 200);
  assert.equal(calls, 1);
});

test('permits an initial provider stream hostname when the explicit allowlist is empty', async () => {
  const sessions = new PlaybackSessions();
  const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'http://global.example-provider.test:2086/live/master.m3u8' }]);
  const grant = sessions.createGrant(id, 'live-1');
  const playbackResponse = response();
  let calls = 0;
  const handled = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), playbackResponse, {
    sessions,
    lookup: publicLookup,
    allowHttp: true,
    hostAllowlist: [],
    fetchImpl: async () => {
      calls += 1;
      return new Response('#EXTM3U\n#EXTINF:1,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  assert.equal(handled, true);
  assert.equal(playbackResponse.status, 200);
  assert.equal(calls, 1);
});

test('follows an explicitly approved HTTP redirect only when HTTP compatibility is enabled', async () => {
  const { sessions, id } = newSession();
  const grant = sessions.createGrant(id, 'live-1');
  let calls = 0;
  const result = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
    sessions,
    lookup: publicLookup,
    allowHttp: true,
    hostAllowlist: ['cdn.example', 'media.example'],
    fetchImpl: async (url) => {
      calls += 1;
      if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://media.example/live/master.m3u8' } });
      assert.equal(new URL(url).hostname, 'media.example');
      return new Response('#EXTM3U\n#EXTINF:1,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  assert.equal(result, true);
  assert.equal(calls, 2);
});

test('permits an exact server-bound public HTTP IP redirect with an empty global allowlist', async () => {
  const { sessions, id } = newSession();
  const grant = sessions.createGrant(id, 'live-1');
  let calls = 0;
  let closed = 0;
  const result = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
    sessions,
    allowHttp: true,
    hostAllowlist: [],
    httpIpRedirectBinding: { sourceHostname: 'cdn.example', destinationIp: '93.184.216.34' },
    lookup: publicLookup,
    boundIpRedirectDispatcherFactory: () => ({ close: async () => { closed += 1; } }),
    fetchImpl: async (_url, options) => {
      calls += 1;
      if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://93.184.216.34/live/master.m3u8' } });
      assert.ok(options.dispatcher);
      return new Response('#EXTM3U\n#EXTINF:1,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  assert.equal(result, true);
  assert.equal(calls, 2);
  assert.equal(closed, 1);
});

test('automatically supports public IPv4 and IPv6 provider redirects without deployment bindings', async () => {
  const cases = [
    { label: 'IPv4', location: 'http://103.176.91.129:80/live/master.m3u8', destinationIp: '103.176.91.129' },
    { label: 'IPv6', location: 'http://[2606:4700:4700::1111]:8080/live/master.m3u8', destinationIp: '2606:4700:4700::1111' },
  ];
  for (const scenario of cases) {
    const sessions = new PlaybackSessions();
    const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://provider.example.test:8443/live/channel.m3u8' }]);
    const grant = sessions.createGrant(id, 'live-1');
    const lookupHosts = []; const pinned = []; let closed = 0; let calls = 0;
    const result = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, allowHttp: true, hostAllowlist: [],
      lookup: async (hostname) => { lookupHosts.push(hostname); return publicLookup(); },
      boundIpRedirectDispatcherFactory: ({ destinationIp }) => {
        pinned.push(destinationIp);
        return { close: async () => { closed += 1; } };
      },
      fetchImpl: async (url, options) => {
        calls += 1;
        if (calls === 1) {
          assert.equal(new URL(url).hostname, 'provider.example.test');
          return new Response('', { status: 302, headers: { location: scenario.location } });
        }
        assert.equal(new URL(url).hostname.replace(/^\[|\]$/g, ''), scenario.destinationIp);
        assert.ok(options.dispatcher);
        return new Response('#EXTM3U\n#EXTINF:1,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
      },
    });
    assert.equal(result, true, scenario.label);
    assert.equal(calls, 2, scenario.label);
    assert.deepEqual(lookupHosts, ['provider.example.test'], scenario.label);
    assert.deepEqual(pinned, [scenario.destinationIp], scenario.label);
    assert.equal(closed, 1, scenario.label);
  }
});

test('permits only an exact server-bound public HTTP IP redirect and closes its dispatcher', async () => {
  const { sessions, id } = newSession();
  const grant = sessions.createGrant(id, 'live-1');
  const lookupHosts = []; const dispatcherAddresses = []; let closed = 0; let calls = 0;
  const result = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
    sessions,
    allowHttp: true,
    hostAllowlist: ['cdn.example'],
    httpIpRedirectBinding: { sourceHostname: 'cdn.example', destinationIp: '93.184.216.34' },
    lookup: async (hostname) => { lookupHosts.push(hostname); return publicLookup(); },
    boundIpRedirectDispatcherFactory: ({ destinationIp }) => {
      dispatcherAddresses.push(destinationIp);
      return { close: async () => { closed += 1; } };
    },
    fetchImpl: async (url, options) => {
      calls += 1;
      if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://93.184.216.34/live/master.m3u8' } });
      assert.equal(new URL(url).hostname, '93.184.216.34');
      assert.ok(options.dispatcher);
      return new Response('#EXTM3U\n#EXTINF:1,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  assert.equal(result, true);
  assert.deepEqual(lookupHosts, ['cdn.example']);
  assert.deepEqual(dispatcherAddresses, ['93.184.216.34']);
  assert.equal(closed, 1);
});

test('permits one same-port public HTTP literal redirect from the explicitly trusted allowlisted source', async () => {
  const { sessions, id } = newTrustedHttpSourceSession(); const grant = sessions.createGrant(id, 'live-1');
  const lookupHosts = []; const dispatcherAddresses = []; let closed = 0; let calls = 0;
  const result = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
    sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectTrust: 'cdn.example',
    lookup: async (hostname) => { lookupHosts.push(hostname); return publicLookup(); },
    boundIpRedirectDispatcherFactory: ({ destinationIp }) => {
      dispatcherAddresses.push(destinationIp);
      return { close: async () => { closed += 1; } };
    },
    fetchImpl: async (_url, options) => {
      calls += 1;
      if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://93.184.216.34:2086/fixture.m3u8?private=value' } });
      assert.ok(options.dispatcher);
      return new Response('#EXTM3U\n#EXTINF:1,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  assert.equal(result, true);
  assert.deepEqual(lookupHosts, ['cdn.example']);
  assert.deepEqual(dispatcherAddresses, ['93.184.216.34']);
  assert.equal(closed, 1);
});

test('scopes trusted literal manifest assets and nested playlists to the same grant endpoint', async () => {
  const sessions = new PlaybackSessions();
  const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'http://cdn.example:2086/master.m3u8' }]);
  const grant = sessions.createGrant(id, 'live-1'); let calls = 0; let pins = 0; let closes = 0; const lookupHosts = [];
  const manifest = response();
  await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), manifest, {
    sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectTrust: 'cdn.example',
    lookup: async (hostname) => { lookupHosts.push(hostname); return publicLookup(); },
    boundIpRedirectDispatcherFactory: () => { pins += 1; return { close: async () => { closes += 1; } }; },
    fetchImpl: async (_url, options) => {
      calls += 1;
      if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://93.184.216.34:2086/master.m3u8' } });
      assert.ok(options.dispatcher);
      return new Response('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1\nnested.m3u8\n#EXTINF:1,Fixture\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  const assetPaths = [...manifest.body.matchAll(/\/api\/playback\/[A-Za-z0-9_-]+\/asset\/[A-Za-z0-9_-]+/g)].map(([path]) => path);
  assert.equal(assetPaths.length, 2);
  const nested = response();
  await handlePlaybackRequest(request(assetPaths[0], id), nested, {
    sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectTrust: 'cdn.example', lookup: async () => { throw new Error('asset literal must not resolve DNS'); },
    boundIpRedirectDispatcherFactory: () => { pins += 1; return { close: async () => { closes += 1; } }; },
    fetchImpl: async (_url, options) => { assert.ok(options.dispatcher); return new Response('#EXTM3U\n#EXTINF:1,Fixture\nchild.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }); },
  });
  assert.equal(nested.status, 200);
  const segment = response();
  await handlePlaybackRequest(request(assetPaths[1], id), segment, {
    sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectTrust: 'cdn.example', lookup: async () => { throw new Error('asset literal must not resolve DNS'); },
    boundIpRedirectDispatcherFactory: () => { pins += 1; return { close: async () => { closes += 1; } }; },
    fetchImpl: async (_url, options) => { assert.ok(options.dispatcher); return new Response('fixture-bytes', { headers: { 'content-type': 'video/mp2t' } }); },
  });
  assert.equal(segment.status, 200);
  assert.equal(segment.body, 'fixture-bytes');
  assert.deepEqual(lookupHosts, ['cdn.example']);
  assert.equal(pins, 3);
  assert.equal(closes, 3);
});

test('rejects trusted literal assets outside the stored grant endpoint or session', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1'; process.env.NODE_ENV = 'development';
  const setup = async () => {
    const sessions = new PlaybackSessions();
    const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'http://cdn.example:2086/master.m3u8' }]);
    const grant = sessions.createGrant(id, 'live-1');
    await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectTrust: 'cdn.example', lookup: publicLookup,
      boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
      fetchImpl: async (url) => String(url).includes('93.184.216.34')
        ? new Response('#EXTM3U\n#EXTINF:1,Fixture\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } })
        : new Response('', { status: 302, headers: { location: 'http://93.184.216.34:2086/master.m3u8' } }),
    });
    return { sessions, id, grant, grantState: sessions.getGrant(id, grant).grant };
  };
  try {
    for (const [name, upstreamUrl, mismatch] of [
      ['different IP', 'http://93.184.216.35:2086/segment.ts', 'source_ip_mismatch'],
      ['different port', 'http://93.184.216.34:2087/segment.ts', 'port_mismatch'],
      ['private', 'http://10.0.0.8:2086/segment.ts', undefined],
      ['loopback', 'http://127.0.0.1:2086/segment.ts', undefined],
      ['reserved', 'http://203.0.113.42:2086/segment.ts', undefined],
      ['https literal', 'https://93.184.216.34:2086/segment.ts', undefined],
      ['userinfo', 'http://operator:secret@93.184.216.34:2086/segment.ts', undefined],
    ]) {
      const { sessions, id, grant, grantState } = await setup();
      const asset = sessions.addAsset(grantState, upstreamUrl, 'segment');
      await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/asset/${asset}`, id), response(), {
        sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectTrust: 'cdn.example', lookup: publicLookup,
      }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed', name);
      const diagnostic = response(); await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
      const payload = JSON.parse(diagnostic.body);
      assert.equal(payload.assetIpMismatch, mismatch, name);
    }

    const { sessions, id, grant, grantState } = await setup();
    const asset = sessions.addAsset(grantState, 'http://93.184.216.34:2086/segment.ts', 'segment');
    const otherId = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'http://cdn.example:2086/master.m3u8' }]);
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/asset/${asset}`, otherId), response(), {
      sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectTrust: 'cdn.example', lookup: publicLookup,
    }), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');

    const chained = await setup();
    const chainedAsset = chained.sessions.addAsset(chained.grantState, 'http://93.184.216.34:2086/segment.ts', 'segment');
    let chainedCalls = 0;
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${chained.grant}/asset/${chainedAsset}`, chained.id), response(), {
      sessions: chained.sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectTrust: 'cdn.example', lookup: async () => { throw new Error('literal asset must not resolve DNS'); },
      boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
      fetchImpl: async () => { chainedCalls += 1; return new Response('', { status: 302, headers: { location: 'http://93.184.216.35:2086/next.ts' } }); },
    }), (error) => error instanceof ConnectorError && error.code === 'playback_redirect_rejected');
    assert.equal(chainedCalls, 1);

    const production = await setup();
    const productionAsset = production.sessions.addAsset(production.grantState, 'http://93.184.216.34:2086/segment.ts', 'segment');
    process.env.NODE_ENV = 'production';
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${production.grant}/asset/${productionAsset}`, production.id), response(), {
      sessions: production.sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectTrust: 'cdn.example', lookup: publicLookup,
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS; else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('rejects unsafe public IP redirect targets but accepts any public port', async () => {
  const unsafe = [
    'http://10.0.0.8:2086/fixture.m3u8',
    'http://127.0.0.1:2086/fixture.m3u8',
    'http://169.254.169.254:2086/fixture.m3u8',
    'http://203.0.113.42:2086/fixture.m3u8',
    'http://operator:secret@93.184.216.34:2086/fixture.m3u8',
  ];
  for (const location of unsafe) {
    const { sessions, id } = newTrustedHttpSourceSession(); const grant = sessions.createGrant(id, 'live-1'); let calls = 0;
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, allowHttp: true, hostAllowlist: [], lookup: publicLookup,
      fetchImpl: async () => { calls += 1; return new Response('', { status: 302, headers: { location } }); },
    }), (error) => error instanceof ConnectorError && ['destination_not_allowed', 'invalid_request'].includes(error.code));
    assert.equal(calls, 1);
  }
  const { sessions, id } = newTrustedHttpSourceSession(); const grant = sessions.createGrant(id, 'live-1'); let calls = 0;
  await assert.doesNotReject(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
    sessions, allowHttp: true, hostAllowlist: [], lookup: publicLookup,
    boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
    fetchImpl: async () => {
      calls += 1;
      return calls === 1
        ? new Response('', { status: 302, headers: { location: 'http://93.184.216.34:2087/fixture.m3u8' } })
        : new Response('#EXTM3U\n#EXTINF:6,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  }));
  assert.equal(calls, 2);
});

test('public IP redirect no longer requires a deployment-specific source-to-IP binding', async () => {
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); let calls = 0;
  const result = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
    sessions, allowHttp: true, hostAllowlist: [], lookup: publicLookup,
    // A deliberately mismatched legacy binding must not block a validated public redirect.
    httpIpRedirectBinding: { sourceHostname: 'other.example', destinationIp: '93.184.216.35' },
    boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
    fetchImpl: async () => {
      calls += 1;
      return calls === 1
        ? new Response('', { status: 302, headers: { location: 'http://93.184.216.34:80/master.m3u8?token=secret' } })
        : new Response('#EXTM3U\n#EXTINF:6,Channel\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  assert.equal(result, true); assert.equal(calls, 2);
});

test('rejects private and reserved IP redirects and still blocks redirect chains', async () => {
  for (const location of ['http://10.0.0.8/live.m3u8', 'http://127.0.0.1/live.m3u8', 'http://169.254.169.254/live.m3u8', 'http://203.0.113.42/live.m3u8']) {
    const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); let calls = 0;
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, allowHttp: true, hostAllowlist: [], lookup: publicLookup,
      fetchImpl: async () => { calls += 1; return new Response('', { status: 302, headers: { location } }); },
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    assert.equal(calls, 1);
  }
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); let calls = 0;
  await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
    sessions, allowHttp: true, hostAllowlist: [], lookup: publicLookup,
    boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
    fetchImpl: async () => {
      calls += 1;
      return new Response('', { status: 302, headers: { location: calls === 1 ? 'http://93.184.216.34/first.m3u8' : 'http://93.184.216.35/second.m3u8' } });
    },
  }), (error) => error instanceof ConnectorError && error.code === 'playback_redirect_rejected');
  assert.equal(calls, 2);
});

test('allows an explicitly bound public HTTP IP redirect without a redundant global host allowlist', async () => {
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); let calls = 0;
  const result = response();
  await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), result, {
    sessions, allowHttp: true, hostAllowlist: [],
    httpIpRedirectBinding: { sourceHostname: 'cdn.example', destinationIp: '93.184.216.34' },
    lookup: publicLookup,
    boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
    fetchImpl: async (url, options) => {
      calls += 1;
      if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://93.184.216.34/master.m3u8' } });
      assert.match(String(url), /^http:\/\/93\.184\.216\.34\/master\.m3u8$/);
      assert.ok(options.dispatcher, 'the exact IP redirect must use a pinned dispatcher');
      return new Response('#EXTM3U\n#EXTINF:5,Fixture\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  assert.equal(calls, 2);
  assert.match(result.body, /\/api\/playback\/.+\/asset\//);
});

test('allows an exact production IP redirect binding without a redundant global host allowlist', async () => {
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = 'production';
  try {
    const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); let calls = 0;
    const result = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), result, {
      sessions, allowHttp: true, hostAllowlist: [],
      httpIpRedirectBinding: { sourceHostname: 'cdn.example', destinationIp: '93.184.216.34' },
      lookup: publicLookup,
      boundIpRedirectDispatcherFactory: () => ({ close: async () => {} }),
      fetchImpl: async (url, options) => {
        calls += 1;
        if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://93.184.216.34/master.m3u8' } });
        assert.match(String(url), /^http:\/\/93\.184\.216\.34\/master\.m3u8$/);
        assert.ok(options.dispatcher, 'the exact IP redirect must use a pinned dispatcher');
        return new Response('#EXTM3U\n#EXTINF:5,Fixture\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
      },
    });
    assert.equal(calls, 2);
    assert.match(result.body, /\/api\/playback\/.+\/asset\//);
  } finally {
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('closes the exact-bound dispatcher when its HTTP request times out or is cancelled', async () => {
  for (const errorName of ['TimeoutError', 'AbortError']) {
    const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); let closed = 0; let calls = 0;
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, allowHttp: true, hostAllowlist: ['cdn.example'], httpIpRedirectBinding: { sourceHostname: 'cdn.example', destinationIp: '93.184.216.34' }, lookup: publicLookup,
      boundIpRedirectDispatcherFactory: () => ({ close: async () => { closed += 1; } }),
      fetchImpl: async () => {
        calls += 1;
        if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://93.184.216.34/master.m3u8' } });
        const error = new Error('safe test failure'); error.name = errorName; throw error;
      },
    }), (error) => error instanceof ConnectorError && error.code === 'provider_timeout');
    assert.equal(closed, 1, errorName);
  }
});

test('parses only one public exact HTTP redirect binding', () => {
  assert.deepEqual(playbackHttpIpRedirectBinding('cdn.example=93.184.216.34'), { sourceHostname: 'cdn.example', destinationIp: '93.184.216.34' });
  assert.equal(playbackHttpIpRedirectBinding('cdn.example=10.0.0.8'), undefined);
  assert.equal(playbackHttpIpRedirectBinding('cdn.example=93.184.216.34,other.example=93.184.216.35'), undefined);
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = 'production';
  try { assert.deepEqual(playbackHttpIpRedirectBinding('cdn.example=93.184.216.34'), { sourceHostname: 'cdn.example', destinationIp: '93.184.216.34' }); }
  finally {
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('production automatically permits a validated public IP redirect and pins its connection even with legacy binding configuration', async () => {
  const previousNodeEnv = process.env.NODE_ENV;
  const previousBinding = process.env.PLAYBACK_HTTP_IP_REDIRECT_BINDING;
  process.env.NODE_ENV = 'production';
  process.env.PLAYBACK_HTTP_IP_REDIRECT_BINDING = 'cdn.example=93.184.216.34';
  try {
    const { sessions, id } = newSession();
    const grant = sessions.createGrant(id, 'live-1');
    let calls = 0;
    let pinned = 0;
    const res = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), res, {
      sessions,
      allowHttp: true,
      hostAllowlist: ['cdn.example'],
      lookup: publicLookup,
      boundIpRedirectDispatcherFactory: ({ destinationIp }) => {
        assert.equal(destinationIp, '93.184.216.34');
        pinned += 1;
        return { close: async () => {} };
      },
      fetchImpl: async (_url, options) => {
        calls += 1;
        if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://93.184.216.34:2086/live.m3u8' } });
        assert.ok(options.dispatcher, 'production literal redirect must use a pinned dispatcher');
        return new Response('#EXTM3U\n#EXTINF:-1,Channel\nsegment.ts', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
      },
    });
    assert.equal(calls, 2);
    assert.equal(pinned, 1);
    assert.equal(res.status, 200);
    assert.match(res.body, /\/asset\//);

  } finally {
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = previousNodeEnv;
    if (previousBinding === undefined) delete process.env.PLAYBACK_HTTP_IP_REDIRECT_BINDING; else process.env.PLAYBACK_HTTP_IP_REDIRECT_BINDING = previousBinding;
  }
});

test('an explicit deployment policy can still reject HTTP redirects', async () => {
  const { sessions, id } = newSession();
  const grant = sessions.createGrant(id, 'live-1');
  let calls = 0;
  await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
    sessions,
    lookup: publicLookup,
    allowHttp: false,
    hostAllowlist: ['cdn.example', 'media.example'],
    fetchImpl: async () => {
      calls += 1;
      return new Response('', { status: 302, headers: { location: 'http://media.example/live/master.m3u8' } });
    },
  }), (error) => error instanceof ConnectorError && error.code === 'http_not_allowed');
  assert.equal(calls, 1);
});

test('never exposes an IP-literal redirect target in a local diagnostic', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1';
  process.env.NODE_ENV = 'development';
  try {
    const { sessions, id } = newSession();
    const grant = sessions.createGrant(id, 'live-1');
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions,
      lookup: publicLookup,
      allowHttp: true,
      hostAllowlist: ['cdn.example'],
      fetchImpl: async () => new Response('', { status: 302, headers: { location: 'http://203.0.113.42/private.m3u8?token=secret' } }),
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    const diagnostic = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'host_not_allowed', stage: 'redirect', requestPhase: 'manifest', redirectCount: 1, ipRedirectBindingStatus: 'missing_or_invalid', rejectedScheme: 'http', destinationRejection: 'resolved_address_not_allowed' });
    assert.equal(diagnostic.body.includes('203.0.113.42'), false);
    assert.equal(diagnostic.body.includes('secret'), false);
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('classifies an HLS asset redirect separately from the initial manifest without exposing its target', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1';
  process.env.NODE_ENV = 'development';
  try {
    const { sessions, id } = newSession();
    const grant = sessions.createGrant(id, 'live-1');
    const manifestResponse = response();
    let requests = 0;
    await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), manifestResponse, {
      sessions,
      lookup: publicLookup,
      allowHttp: true,
      hostAllowlist: ['cdn.example'],
      fetchImpl: async () => {
        requests += 1;
        return new Response('#EXTM3U\n#EXTINF:6,\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
      },
    });
    const assetPath = manifestResponse.body.match(/(\/api\/playback\/[A-Za-z0-9_-]+\/asset\/[A-Za-z0-9_-]+)/)?.[1];
    assert.ok(assetPath);
    await assert.rejects(() => handlePlaybackRequest(request(assetPath, id), response(), {
      sessions,
      lookup: publicLookup,
      allowHttp: true,
      hostAllowlist: ['cdn.example'],
      fetchImpl: async () => {
        requests += 1;
        return new Response('', { status: 302, headers: { location: 'http://203.0.113.42/segment.ts?token=secret' } });
      },
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    assert.equal(requests, 2);
    const diagnostic = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'host_not_allowed', stage: 'redirect', requestPhase: 'asset', redirectCount: 1, ipRedirectBindingStatus: 'missing_or_invalid', rejectedScheme: 'http', destinationRejection: 'resolved_address_not_allowed' });
    assert.equal(diagnostic.body.includes('203.0.113.42'), false);
    assert.equal(diagnostic.body.includes('secret'), false);
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('rejects a redirect that resolves to a private address before it is fetched', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1';
  process.env.NODE_ENV = 'development';
  try {
    const { sessions, id } = newSession();
    const grant = sessions.createGrant(id, 'live-1');
    let calls = 0;
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions,
      allowHttp: true,
      hostAllowlist: ['cdn.example', 'approved.example'],
      lookup: async (host) => [{ address: host === 'approved.example' ? '10.0.0.9' : '93.184.216.34', family: 4 }],
      fetchImpl: async () => {
        calls += 1;
        return new Response('', { status: 302, headers: { location: 'http://approved.example/private.m3u8' } });
      },
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    assert.equal(calls, 1);
    const diagnostic = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'host_not_allowed', stage: 'redirect', requestPhase: 'manifest', redirectCount: 1, rejectedHostname: 'approved.example', rejectedScheme: 'http', destinationRejection: 'resolved_address_not_allowed' });
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('surfaces a redirect DNS failure as a fixed local diagnostic without upstream details', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1';
  process.env.NODE_ENV = 'development';
  try {
    const { sessions, id } = newSession();
    const grant = sessions.createGrant(id, 'live-1');
    let calls = 0;
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions,
      allowHttp: true,
      hostAllowlist: ['cdn.example', 'dns-failure.example'],
      lookup: async (host) => {
        if (host === 'dns-failure.example') throw new Error('resolver detail must not escape');
        return [{ address: '93.184.216.34', family: 4 }];
      },
      fetchImpl: async () => {
        calls += 1;
        return new Response('', { status: 302, headers: { location: 'http://dns-failure.example/master.m3u8' } });
      },
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    assert.equal(calls, 1);
    const diagnostic = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'host_not_allowed', stage: 'redirect', requestPhase: 'manifest', redirectCount: 1, rejectedHostname: 'dns-failure.example', rejectedScheme: 'http', destinationRejection: 'dns_resolution_failed' });
    assert.equal(diagnostic.body.includes('resolver detail'), false);
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('allows user-supplied public provider hosts without a deployment allowlist and emits a strict HttpOnly session cookie', async () => {
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1');
  const res = response();
  await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), res, {
    sessions,
    lookup: publicLookup,
    hostAllowlist: [],
    fetchImpl: async () => new Response(`#EXTM3U
#EXTINF:1,Fixture
segment.ts
`, { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }),
  });
  assert.equal(res.status, 200);
  assert.match(res.body, /\/api\/playback\//);
  const cookie = sessionCookie('opaque-session', { secure: true });
  assert.match(cookie, /HttpOnly/); assert.match(cookie, /SameSite=Strict/); assert.match(cookie, /Secure/); assert.equal(cookie.includes('https://'), false);
});

test('parses only explicit development-only provider-domain trust suffixes', () => {
  assert.deepEqual(playbackProviderDomainTrust('source.example.test=.example-a.test|.example-b.test'), {
    sourceHostname: 'source.example.test', suffixes: ['.example-a.test', '.example-b.test'],
  });
  for (const value of [
    'source.example.test=example-a.test',
    'source.example.test=.local',
    'source.example.test=.example-a.test|.example-a.test',
    'source.example.test=.example-a.test=unexpected',
  ]) assert.equal(playbackProviderDomainTrust(value), undefined, value);
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = 'production';
  try { assert.equal(playbackProviderDomainTrust('source.example.test=.example-a.test'), undefined); }
  finally {
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('permits a configured provider-domain redirect and only its grant-scoped nested assets', async () => {
  const sessions = new PlaybackSessions();
  const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'http://source.example.test:88/master.m3u8' }]);
  const grant = sessions.createGrant(id, 'live-1');
  const domainTrust = { sourceHostname: 'source.example.test', suffixes: ['.example-a.test'] };
  const lookupHosts = []; const pinnedHosts = []; let calls = 0; let closes = 0;
  const manifest = response();
  await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), manifest, {
    sessions, allowHttp: true, hostAllowlist: ['source.example.test'], providerDomainTrust: domainTrust,
    lookup: async (hostname) => { lookupHosts.push(hostname); return publicLookup(); },
    boundDomainRedirectDispatcherFactory: ({ destinationHostname, destinationRecords, allowHttp }) => {
      pinnedHosts.push({ destinationHostname, records: destinationRecords.length, allowHttp });
      return { close: async () => { closes += 1; } };
    },
    fetchImpl: async (_url, options) => {
      calls += 1;
      if (calls === 1) return new Response('', { status: 302, headers: { location: 'http://iss-001.example-a.test:80/master.m3u8' } });
      assert.ok(options.dispatcher);
      return new Response('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1\nnested.m3u8\n#EXTINF:1,Fixture\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
    },
  });
  const assets = [...manifest.body.matchAll(/\/api\/playback\/[A-Za-z0-9_-]+\/asset\/[A-Za-z0-9_-]+/g)].map(([path]) => path);
  assert.equal(assets.length, 2);
  for (const [index, assetPath] of assets.entries()) {
    const assetResponse = response();
    await handlePlaybackRequest(request(assetPath, id), assetResponse, {
      sessions, allowHttp: true, hostAllowlist: ['source.example.test'], providerDomainTrust: domainTrust,
      lookup: async () => { throw new Error('trusted domain asset must reuse the validated records'); },
      boundDomainRedirectDispatcherFactory: ({ destinationHostname, destinationRecords }) => {
        pinnedHosts.push({ destinationHostname, records: destinationRecords.length, allowHttp: true });
        return { close: async () => { closes += 1; } };
      },
      fetchImpl: async (_url, options) => {
        assert.ok(options.dispatcher);
        return index === 0
          ? new Response('#EXTM3U\n#EXTINF:1,Child\nchild.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } })
          : new Response('fixture-bytes', { headers: { 'content-type': 'video/mp2t' } });
      },
    });
    assert.equal(assetResponse.status, 200);
  }
  assert.deepEqual(lookupHosts, ['source.example.test', 'iss-001.example-a.test']);
  assert.deepEqual(pinnedHosts.map(({ destinationHostname, records }) => [destinationHostname, records]), [
    ['iss-001.example-a.test', 1], ['iss-001.example-a.test', 1], ['iss-001.example-a.test', 1],
  ]);
  assert.equal(closes, 3);

  const grantState = sessions.getGrant(id, grant).grant;
  const foreignAsset = sessions.addAsset(grantState, 'http://other.example.test/segment.ts', 'segment');
  await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/asset/${foreignAsset}`, id), response(), {
    sessions, allowHttp: true, hostAllowlist: ['source.example.test'], providerDomainTrust: domainTrust, lookup: publicLookup,
  }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
});

test('rejects unsafe provider-domain redirect variants and records only the fixed mismatch category', async () => {
  const previousDiagnostics = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1'; process.env.NODE_ENV = 'development';
  const trusted = { sourceHostname: 'source.example.test', suffixes: ['.example-a.test'] };
  const cases = [
    ['non-matching domain', 'http://other.example.test/master.m3u8', trusted, 'source.example.test', true, publicLookup],
    ['bare suffix', 'http://example-a.test/master.m3u8', trusted, 'source.example.test', true, publicLookup],
    ['lookalike', 'http://evil-1700.info.example/master.m3u8', { sourceHostname: 'source.example.test', suffixes: ['.1700.info.example'] }, 'source.example.test', true, publicLookup],
    ['non-source host with private target', 'http://iss-001.example-a.test/master.m3u8', trusted, 'other.example.test', true, async (hostname) => [{ address: hostname === 'iss-001.example-a.test' ? '10.0.0.8' : '93.184.216.34', family: 4 }]],
    ['HTTP disabled', 'http://iss-001.example-a.test/master.m3u8', trusted, 'source.example.test', false, publicLookup],
    ['private DNS result', 'http://iss-001.example-a.test/master.m3u8', trusted, 'source.example.test', true, async (hostname) => [{ address: hostname === 'iss-001.example-a.test' ? '10.0.0.8' : '93.184.216.34', family: 4 }]],
  ];
  try {
    for (const [name, location, domainTrust, sourceHostname, allowHttp, lookup] of cases) {
      const sessions = new PlaybackSessions();
      const sourceProtocol = allowHttp ? 'http' : 'https';
      const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: `${sourceProtocol}://${sourceHostname}/master.m3u8` }]);
      const grant = sessions.createGrant(id, 'live-1'); let calls = 0;
      await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
        sessions, allowHttp, hostAllowlist: [sourceHostname], providerDomainTrust: domainTrust, lookup,
        fetchImpl: async () => { calls += 1; return new Response('', { status: 302, headers: { location } }); },
      }), (error) => error instanceof ConnectorError && ['destination_not_allowed', 'http_not_allowed'].includes(error.code), name);
      assert.equal(calls, 1, name);
      if (name === 'non-matching domain') {
        const diagnostic = response(); await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
        const payload = JSON.parse(diagnostic.body);
        assert.equal(payload.domainTrustMismatch, 'domain_trust_mismatch');
        assert.equal(diagnostic.body.includes('other.example.test'), false);
      }
    }

    const sessions = new PlaybackSessions();
    const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'http://source.example.test/master.m3u8' }]);
    const grant = sessions.createGrant(id, 'live-1');
    process.env.NODE_ENV = 'production';
    const productionResponse = response(); let productionCalls = 0;
    await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), productionResponse, {
      sessions, allowHttp: true, hostAllowlist: ['source.example.test'], providerDomainTrust: trusted, lookup: publicLookup,
      fetchImpl: async () => {
        productionCalls += 1;
        return productionCalls === 1
          ? new Response('', { status: 302, headers: { location: 'http://iss-001.example-a.test/master.m3u8' } })
          : new Response('#EXTM3U\n#EXTINF:1,Production\nsegment.ts\n', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } });
      },
    });
    assert.equal(productionResponse.status, 200, 'development-only suffix trust must not become a production requirement');
    process.env.NODE_ENV = 'development';

    const chainedSessions = new PlaybackSessions();
    const chainedId = chainedSessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'http://source.example.test/master.m3u8' }]);
    const chainedGrant = chainedSessions.createGrant(chainedId, 'live-1'); let chainedCalls = 0;
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${chainedGrant}/manifest.m3u8`, chainedId), response(), {
      sessions: chainedSessions, allowHttp: true, hostAllowlist: ['source.example.test'], providerDomainTrust: trusted, lookup: publicLookup,
      boundDomainRedirectDispatcherFactory: () => ({ close: async () => {} }),
      fetchImpl: async () => {
        chainedCalls += 1;
        return chainedCalls === 1
          ? new Response('', { status: 302, headers: { location: 'http://iss-001.example-a.test/master.m3u8' } })
          : new Response('', { status: 302, headers: { location: 'http://iss-002.example-a.test/next.m3u8' } });
      },
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    assert.equal(chainedCalls, 2);
  } finally {
    if (previousDiagnostics === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previousDiagnostics;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});
