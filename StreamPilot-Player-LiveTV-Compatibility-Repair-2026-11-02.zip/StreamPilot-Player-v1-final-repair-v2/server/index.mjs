import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer as createViteServer } from 'vite';
import { createApiHandler } from './api.mjs';
import { providerRequestTimeoutMs } from './connector.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const port = Number(process.env.PORT || 5173);
const api = createApiHandler();

async function startDevelopment() {
  const vite = await createViteServer({ root, server: { middlewareMode: true, host: '127.0.0.1' }, appType: 'spa' });
  const server = http.createServer(async (req, res) => { if (await api(req, res)) return; vite.middlewares(req, res); });
  server.listen(port, '127.0.0.1', () => console.log(`StreamPilot Player dev server: http://127.0.0.1:${port} (provider request timeout: ${providerRequestTimeoutMs()} ms)`));
}

const types = { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
async function startProduction() {
  const dist = path.join(root, 'dist');
  const server = http.createServer(async (req, res) => {
    if (await api(req, res)) return;
    const requested = new URL(req.url || '/', 'http://localhost').pathname;
    const file = requested === '/' ? path.join(dist, 'index.html') : path.resolve(dist, `.${requested}`);
    if (!file.startsWith(dist)) { res.writeHead(403).end(); return; }
    try { const content = await fs.readFile(file); res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream', 'x-content-type-options': 'nosniff' }); res.end(content); }
    catch { const html = await fs.readFile(path.join(dist, 'index.html')); res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'x-content-type-options': 'nosniff' }); res.end(html); }
  });
  server.listen(port, '127.0.0.1', () => console.log(`StreamPilot Player server: http://127.0.0.1:${port}`));
}

if (process.argv.includes('--dev')) startDevelopment(); else startProduction();
