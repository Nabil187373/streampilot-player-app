
import { ProxyAgent, fetch as undiciFetch } from 'undici';

let cachedProxyKey;
let cachedProxyAgent;

function getProxyAgent() {
  const proxyUrl = process.env.STREAM_PILOT_HTTP_PROXY;
  const username = process.env.STREAM_PILOT_PROXY_USERNAME;
  const password = process.env.STREAM_PILOT_PROXY_PASSWORD;

  if (!proxyUrl || !username || !password) {
    throw new Error('Authenticated local HTTP proxy is not fully configured.');
  }

  const parsed = new URL(proxyUrl);

  if (
    parsed.protocol !== 'http:' ||
    !parsed.hostname ||
    !parsed.port ||
    parsed.pathname !== '/' ||
    parsed.search ||
    parsed.hash ||
    parsed.username ||
    parsed.password
  ) {
    throw new Error('Invalid local HTTP proxy configuration.');
  }

  const cacheKey = `${proxyUrl}|${username}|${password}`;

  if (cacheKey !== cachedProxyKey) {
    cachedProxyAgent?.close().catch(() => {});

    cachedProxyAgent = new ProxyAgent({
      uri: proxyUrl,
      token: `Basic ${Buffer.from(
        `${username}:${password}`,
        'utf8'
      ).toString('base64')}`,
    });

    cachedProxyKey = cacheKey;
  }

  return cachedProxyAgent;
}

export async function proxyFetch(input, options = {}) {
  return undiciFetch(input, {
    ...options,
    dispatcher: getProxyAgent(),
    redirect: 'manual',
  });
}
