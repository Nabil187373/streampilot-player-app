import assert from 'node:assert/strict';
import test from 'node:test';
import { createProviderAdapterRegistry } from './registry.mjs';

test('resolves the first matching provider adapter and keeps adapter identifiers unique', async () => {
  const calls = [];
  const registry = createProviderAdapterRegistry([
    { id: 'xtream', detect: (input) => input.kind === 'xtream', import: async () => { calls.push('xtream'); return 'xtream-result'; } },
    { id: 'm3u', detect: () => true, import: async () => { calls.push('m3u'); return 'm3u-result'; } },
  ]);
  assert.deepEqual(registry.list(), ['xtream', 'm3u']);
  assert.equal(await registry.resolve({ kind: 'xtream' }).import({}, {}), 'xtream-result');
  assert.equal(await registry.resolve({ kind: 'other' }).import({}, {}), 'm3u-result');
  assert.deepEqual(calls, ['xtream', 'm3u']);
  assert.throws(() => createProviderAdapterRegistry([
    { id: 'same', detect: () => true, import: () => {} },
    { id: 'same', detect: () => false, import: () => {} },
  ]), /Duplicate provider adapter/);
});
