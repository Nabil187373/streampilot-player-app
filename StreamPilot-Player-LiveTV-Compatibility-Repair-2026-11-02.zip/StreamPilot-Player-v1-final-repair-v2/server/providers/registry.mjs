/**
 * Small provider-adapter registry.
 *
 * Adapters own provider-specific import/authentication and return the shared
 * catalogue contract consumed by the API. The registry deliberately does not
 * make network-trust decisions; each adapter must use the validated, pinned
 * transport supplied by the connector layer.
 */
export function createProviderAdapterRegistry(adapters) {
  if (!Array.isArray(adapters) || adapters.length === 0) {
    throw new TypeError('At least one provider adapter is required.');
  }
  const ids = new Set();
  const entries = adapters.map((adapter) => {
    if (!adapter || typeof adapter.id !== 'string' || !adapter.id.trim()
      || typeof adapter.detect !== 'function' || typeof adapter.import !== 'function') {
      throw new TypeError('Provider adapters require an id, detect function, and import function.');
    }
    if (ids.has(adapter.id)) throw new TypeError(`Duplicate provider adapter: ${adapter.id}`);
    ids.add(adapter.id);
    return Object.freeze({ ...adapter });
  });
  return Object.freeze({
    list: () => entries.map(({ id }) => id),
    resolve(input) {
      const adapter = entries.find((candidate) => candidate.detect(input));
      if (!adapter) throw new Error('No compatible provider adapter was found.');
      return adapter;
    },
  });
}
