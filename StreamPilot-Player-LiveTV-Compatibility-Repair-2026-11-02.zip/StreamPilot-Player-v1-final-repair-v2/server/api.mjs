import crypto from 'node:crypto';
import { ConnectorError, createXtreamConnector, createRemotePlaylistImporter, createXtreamVodCatalog, createXtreamSeriesCatalog, getXtreamCatalogDescriptor, getXtreamVodItemExtensions, getXtreamSeriesItemExtensions, redactSecrets } from './connector.mjs';
import { PlaybackSessions, handleMovieMediaRequest, handlePlaybackRequest, playbackFailureCategory, readCookie, sessionCookie } from './playback.mjs';

const attempts = new Map();
const WINDOW_MS = 60_000; const MAX_IMPORT_ATTEMPTS = 10; const MAX_BODY_BYTES = 16 * 1024;
const IMPORT_ENDPOINTS = new Set(['/api/playlist/xtream', '/api/playlist/remote']);
const MOVIE_GRANT_TTL_MS = 5 * 60_000;
const MOVIE_GRANT_ABSOLUTE_TTL_MS = 6 * 60 * 60_000;

export class MovieGrantStore {
  constructor({ now = () => Date.now(), ttlMs = MOVIE_GRANT_TTL_MS, absoluteTtlMs = MOVIE_GRANT_ABSOLUTE_TTL_MS } = {}) { this.now = now; this.ttlMs = ttlMs; this.absoluteTtlMs = absoluteTtlMs; this.grants = new Map(); }
  issue(sessionId, movieId, mediaKind = 'movie') {
    if (typeof sessionId !== 'string' || !sessionId || typeof movieId !== 'string' || !movieId || !['movie', 'episode'].includes(mediaKind)) throw new ConnectorError('That movie is not available for playback.', 404, 'playback_item_not_found');
    const id = crypto.randomBytes(32).toString('base64url');
    const createdAt = this.now(); const absoluteExpiresAt = createdAt + this.absoluteTtlMs;
    this.grants.set(id, { sessionId, movieId, mediaKind, createdAt, absoluteExpiresAt, expiresAt: Math.min(absoluteExpiresAt, createdAt + this.ttlMs), revoked: false });
    return id;
  }
  resolve(sessionId, grantId) {
    const grant = this.grants.get(grantId);
    if (!grant || grant.revoked || grant.expiresAt <= this.now() || grant.sessionId !== sessionId) throw new ConnectorError('Movie playback authorization expired. Request movie playback again.', 401, 'playback_unauthorized');
    return grant;
  }
  assertCanTouch(sessionId, grantId) {
    const grant = this.resolve(sessionId, grantId);
    const now = this.now();
    if (now >= grant.absoluteExpiresAt) throw new ConnectorError('Movie playback authorization expired. Request movie playback again.', 401, 'playback_unauthorized');
    return { grant, now };
  }
  touch(sessionId, grantId) {
    const { grant, now } = this.assertCanTouch(sessionId, grantId);
    grant.expiresAt = Math.min(grant.absoluteExpiresAt, now + this.ttlMs);
    return grant;
  }
  setFailure(sessionId, grantId, category, diagnostic) {
    const grant = this.resolve(sessionId, grantId);
    if (typeof category === 'string') grant.lastFailure = category;
    // Retain only a small allowlist of local, non-secret playback diagnostics.
    // Never retain upstream URLs, paths, query strings, or provider credentials.
    if (diagnostic && typeof diagnostic === 'object') {
      const safe = {};
      const stage = diagnostic.playbackStage;
      if (['initial_live_stream', 'nested_playlist', 'segment', 'key', 'map', 'redirect', 'asset'].includes(stage)) safe.stage = stage;
      if (diagnostic.requestPhase === 'manifest') safe.requestPhase = 'manifest';
      else if (diagnostic.requestPhase === 'asset' || diagnostic.requestPhase === 'media') safe.requestPhase = 'asset';
      if (Number.isInteger(diagnostic.redirectCount) && diagnostic.redirectCount >= 0 && diagnostic.redirectCount <= 3) safe.redirectCount = diagnostic.redirectCount;
      if (['missing_or_invalid', 'source_not_allowlisted', 'source_mismatch', 'destination_mismatch', 'disabled_in_production'].includes(diagnostic.ipRedirectBindingStatus)) safe.ipRedirectBindingStatus = diagnostic.ipRedirectBindingStatus;
      if (typeof diagnostic.rejectedHostname === 'string' && /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i.test(diagnostic.rejectedHostname)) safe.rejectedHostname = diagnostic.rejectedHostname.toLowerCase();
      if (diagnostic.rejectedScheme === 'http' || diagnostic.rejectedScheme === 'https') safe.rejectedScheme = diagnostic.rejectedScheme;
      if (['hostname_not_allowlisted', 'dns_resolution_failed', 'resolved_address_not_allowed', 'ip_literal_not_allowed'].includes(diagnostic.destinationRejection)) safe.destinationRejection = diagnostic.destinationRejection;
      if (typeof diagnostic.redirectDestinationIp === 'string' && /^(?:\d{1,3}(?:\.\d{1,3}){3}|[a-f0-9:]+)$/i.test(diagnostic.redirectDestinationIp) && Number.isInteger(diagnostic.redirectDestinationPort) && diagnostic.redirectDestinationPort >= 1 && diagnostic.redirectDestinationPort <= 65535) {
        safe.redirectDestinationIp = diagnostic.redirectDestinationIp;
        safe.redirectDestinationPort = diagnostic.redirectDestinationPort;
      }
      grant.lastDiagnostic = safe;
    }
  }
  getFailure(sessionId, grantId) { return this.resolve(sessionId, grantId).lastFailure; }
  getDiagnostic(sessionId, grantId) { return { ...(this.resolve(sessionId, grantId).lastDiagnostic ?? {}) }; }
  clearFailure(sessionId, grantId) { const grant = this.resolve(sessionId, grantId); grant.lastFailure = undefined; grant.lastDiagnostic = undefined; }
  revoke(grantId) { const grant = this.grants.get(grantId); if (!grant) return false; grant.revoked = true; return true; }
  prune() { const now = this.now(); for (const [id, grant] of this.grants) if (grant.revoked || grant.expiresAt <= now) this.grants.delete(id); }
}

function rateLimit(req) {
  // Only provider imports use the coarse per-IP limiter. Catalogue browsing,
  // playback-grant creation, and session operations are independently limited
  // by the authenticated playback session; sharing one 10/min bucket across
  // every POST made ordinary channel browsing unusable.
  const pathname = new URL(req.url || '/', 'http://localhost').pathname;
  if (!IMPORT_ENDPOINTS.has(pathname)) return;
  const key = `${req.socket.remoteAddress || 'unknown'}:${pathname}`;
  const now = Date.now();
  const recent = (attempts.get(key) || []).filter((time) => now - time < WINDOW_MS);
  if (recent.length >= MAX_IMPORT_ATTEMPTS) throw new ConnectorError('Too many provider imports. Try again shortly.', 429, 'rate_limited');
  recent.push(now);
  attempts.set(key, recent);
  if (attempts.size > 10_000) {
    for (const [entry, values] of attempts) {
      const active = values.filter((time) => now - time < WINDOW_MS);
      if (active.length) attempts.set(entry, active);
      else attempts.delete(entry);
    }
  }
}
async function jsonBody(req) {
  let size = 0; const chunks = [];
  for await (const chunk of req) { size += chunk.length; if (size > MAX_BODY_BYTES) throw new ConnectorError('Request is too large.', 413, 'invalid_request'); chunks.push(chunk); }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new ConnectorError('Request body must be valid JSON.', 400, 'invalid_request'); }
}
function sendJson(res, status, value, extraHeaders = {}) { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...extraHeaders }); res.end(JSON.stringify(value)); }
function requireSameOrigin(req) {
  const origin = req.headers.origin;
  const host = req.headers.host;
  if (origin && host && origin !== `http://${host}` && origin !== `https://${host}`) throw new ConnectorError('This request must come from the local StreamPilot app.', 403, 'invalid_request');
}

function safeRouteLabel(req) {
  const pathname = new URL(req.url || '/', 'http://localhost').pathname;
  return pathname
    .replace(/\/api\/playback\/[A-Za-z0-9_-]+\/asset\/[A-Za-z0-9_-]+$/, '/api/playback/:grant/asset/:asset')
    .replace(/\/api\/playback\/[A-Za-z0-9_-]+\/(?:manifest\.m3u8|diagnostic)$/, (value) => value.endsWith('/diagnostic') ? '/api/playback/:grant/diagnostic' : '/api/playback/:grant/manifest.m3u8')
    .replace(/\/media\/[A-Za-z0-9_-]+(?:\/diagnostic)?$/, (value) => value.endsWith('/diagnostic') ? '/media/:grant/diagnostic' : '/media/:grant');
}

function safeErrorDetails(error, known) {
  const details = [];
  if (known && typeof error.code === 'string' && /^[a-z0-9_]{1,48}$/.test(error.code)) details.push(`code=${error.code}`);
  const rejection = error?.localDiagnostic?.destinationRejection ?? error?.diagnostic?.destinationRejection;
  if (['dns_resolution_failed', 'resolved_address_not_allowed', 'ip_literal_not_allowed', 'hostname_not_allowlisted'].includes(rejection)) details.push(`destination=${rejection}`);
  const status = error?.diagnostic?.upstreamHttpStatus ?? error?.diagnostic?.providerStatus;
  if (Number.isInteger(status) && status >= 100 && status <= 599) details.push(`upstream_status=${status}`);
  return details.length ? `; ${details.join('; ')}` : '';
}

export function createApiHandler(options) {
  const connect = createXtreamConnector(options);
  const importRemotePlaylist = createRemotePlaylistImporter(options);
  const vodCatalog = createXtreamVodCatalog(options);
  const seriesCatalog = createXtreamSeriesCatalog(options);
  const sessions = options?.sessions || new PlaybackSessions(options?.playbackSessionOptions);
  const movieGrants = options?.movieGrants || new MovieGrantStore(options?.movieGrantOptions);
  const vodCatalogs = new Map();
  const seriesCatalogs = new Map();
  const pruneVodCatalogs = () => {
    const now = Date.now();
    for (const [sessionId, catalog] of vodCatalogs) if (catalog.expiresAt <= now || !sessions.getSession(sessionId)) vodCatalogs.delete(sessionId);
    for (const [sessionId, catalog] of seriesCatalogs) if (catalog.expiresAt <= now || !sessions.getSession(sessionId)) seriesCatalogs.delete(sessionId);
  };
  return async (req, res) => {
    try {
      const movieDiagnostic = req.method === 'GET' && new URL(req.url || '/', 'http://localhost').pathname.match(/^\/media\/([A-Za-z0-9_-]+)\/diagnostic$/);
      if (movieDiagnostic) {
        const sessionId = readCookie(req.headers.cookie, 'sp_playback_session');
        const category = movieGrants.getFailure(sessionId, movieDiagnostic[1]);
        const diagnostic = movieGrants.getDiagnostic(sessionId, movieDiagnostic[1]);
        sendJson(res, 200, { ok: true, category: category ?? null, ...diagnostic });
        return true;
      }
      const movieRequest = new URL(req.url || '/', 'http://localhost').pathname.match(/^\/media\/([A-Za-z0-9_-]+)$/);
      try {
        if (await handleMovieMediaRequest(req, res, {
          fetchImpl: options?.playbackFetchImpl, lookup: options?.playbackLookup, allowHttp: options?.allowHttp, mediaIpRedirectTrust: options?.playbackMediaIpRedirectTrust, providerDomainTrust: options?.playbackProviderDomainTrust, boundDomainRedirectDispatcherFactory: options?.boundDomainRedirectDispatcherFactory, hostAllowlist: options?.playbackHostAllowlist,
          resolveAuthorizedMovie: async (sessionId, grantId) => {
            const session = sessions.getSession(sessionId);
            const grant = movieGrants.resolve(sessionId, grantId);
            const catalog = sessionId && session ? vodCatalogs.get(sessionId) : undefined;
            if (grant.mediaKind === 'movie' ? !catalog?.movieExtensions?.has(grant.movieId) : !seriesCatalogs.get(sessionId)?.episodeExtensions?.has(grant.movieId)) throw new ConnectorError('That movie or episode is not available for playback.', 404, 'playback_item_not_found');
            sessions.rateLimit(session);
            return {
              upstreamUrl: grant.mediaKind === 'movie'
                ? vodCatalog.movieUrl(catalog.descriptor, grant.movieId, catalog.movieExtensions.get(grant.movieId))
                : seriesCatalog.episodeUrl(seriesCatalogs.get(sessionId).descriptor, grant.movieId, seriesCatalogs.get(sessionId).episodeExtensions.get(grant.movieId)),
              refresh: () => {
                // Validate both records before either expiry is changed. This is
                // invoked only after the upstream response passes authorization,
                // range, and media-type checks in the /media handler.
                movieGrants.assertCanTouch(sessionId, grantId);
                sessions.assertCanTouchForMovie(sessionId);
                movieGrants.clearFailure(sessionId, grantId);
                movieGrants.touch(sessionId, grantId);
                const refreshedSession = sessions.touchForMovie(sessionId);
                return { sessionCookie: sessionCookie(sessionId, { secure: options?.cookieSecure, maxAgeSeconds: refreshedSession.maxAgeSeconds }) };
              },
            };
          },
        })) return true;
      } catch (error) {
        if (movieRequest) {
          const category = playbackFailureCategory(error, { phase: 'media' });
          if (category) { try { movieGrants.setFailure(readCookie(req.headers.cookie, 'sp_playback_session'), movieRequest[1], category, error?.diagnostic); } catch {} }
        }
        throw error;
      }
      if (await handlePlaybackRequest(req, res, {
        sessions,
        fetchImpl: options?.playbackFetchImpl,
        lookup: options?.playbackLookup,
        allowHttp: options?.allowHttp,
        httpIpRedirectBinding: options?.playbackHttpIpRedirectBinding,
        httpIpRedirectTrust: options?.playbackHttpIpRedirectTrust,
        providerDomainTrust: options?.playbackProviderDomainTrust,
        boundDomainRedirectDispatcherFactory: options?.boundDomainRedirectDispatcherFactory,
        hostAllowlist: options?.playbackHostAllowlist,
      })) return true;
      pruneVodCatalogs();
      movieGrants.prune();
      if (req.method !== 'POST' || !['/api/playlist/xtream', '/api/playlist/remote', '/api/playback/grants', '/api/playback/grants/renew', '/api/media/grants', '/api/catalog/xtream/vod/categories', '/api/catalog/xtream/vod/items', '/api/catalog/xtream/series/categories', '/api/catalog/xtream/series/items', '/api/catalog/xtream/series/episodes'].includes(req.url)) return false;
      if (!req.headers['content-type']?.toLowerCase().startsWith('application/json')) throw new ConnectorError('Request body must be JSON.', 415, 'invalid_request');
      requireSameOrigin(req);
      rateLimit(req);
      const body = await jsonBody(req);
      if (req.url === '/api/playback/grants') {
        const session = sessions.getSession(readCookie(req.headers.cookie, 'sp_playback_session'));
        if (!session) throw new ConnectorError('Playback authorization expired. Import the provider playlist again.', 401, 'playback_unauthorized');
        sessions.rateLimit(session);
        const sessionId = readCookie(req.headers.cookie, 'sp_playback_session');
        const grantId = sessions.createGrant(sessionId, body?.itemId);
        sendJson(res, 200, { ok: true, manifestPath: `/api/playback/${grantId}/manifest.m3u8` });
        return true;
      }
      if (req.url === '/api/playback/grants/renew') {
        const sessionId = readCookie(req.headers.cookie, 'sp_playback_session');
        const session = sessions.getSession(sessionId);
        if (!session) throw new ConnectorError('Playback authorization expired. Import the provider playlist again.', 401, 'playback_unauthorized');
        sessions.rateLimit(session);
        const renewed = sessions.renewGrant(sessionId, body?.grantId);
        sendJson(res, 200, { ok: true, manifestPath: `/api/playback/${renewed.grantId}/manifest.m3u8` }, {
          'set-cookie': sessionCookie(sessionId, { secure: options?.cookieSecure, maxAgeSeconds: renewed.maxAgeSeconds }),
        });
        return true;
      }
      if (req.url === '/api/media/grants') {
        const sessionId = readCookie(req.headers.cookie, 'sp_playback_session');
        const session = sessions.getSession(sessionId);
        if (!session) throw new ConnectorError('Movie playback authorization expired. Request movie playback again.', 401, 'playback_unauthorized');
        const catalog = sessionId && session ? vodCatalogs.get(sessionId) : undefined;
        const movieId = typeof body?.movieId === 'string' ? body.movieId.trim() : '';
        const episodeId = typeof body?.episodeId === 'string' ? body.episodeId.trim() : '';
        const mediaId = movieId || episodeId;
        const isMovie = Boolean(movieId && catalog?.movieExtensions?.has(movieId));
        const isEpisode = Boolean(episodeId && seriesCatalogs.get(sessionId)?.episodeExtensions?.has(episodeId));
        if (!isMovie && !isEpisode) throw new ConnectorError('That movie or episode is not available for playback.', 404, 'playback_item_not_found');
        sessions.rateLimit(session);
        const grantId = movieGrants.issue(sessionId, mediaId, isMovie ? 'movie' : 'episode');
        sendJson(res, 200, { ok: true, mediaPath: `/media/${grantId}` });
        return true;
      }
      if (req.url === '/api/catalog/xtream/vod/categories' || req.url === '/api/catalog/xtream/vod/items') {
        const sessionId = readCookie(req.headers.cookie, 'sp_playback_session');
        const session = sessions.getSession(sessionId);
        const catalog = sessionId && session ? vodCatalogs.get(sessionId) : undefined;
        if (!catalog) throw new ConnectorError('The VOD catalogue is not available for this session.', 403, 'vod_catalog_unavailable');
        sessions.rateLimit(session);
        if (req.url === '/api/catalog/xtream/vod/categories') {
          const categories = await vodCatalog.categories(catalog.descriptor);
          catalog.categoryIds = new Set(categories.map((category) => category.id));
          sendJson(res, 200, { ok: true, categories });
          return true;
        }
        const categoryId = typeof body?.categoryId === 'string' ? body.categoryId.trim() : '';
        if (!catalog.categoryIds?.has(categoryId)) throw new ConnectorError('The movie category is not available for this session.', 403, 'vod_catalog_unavailable');
        const offset = body?.offset;
        const limit = body?.limit;
        const page = await vodCatalog.items(catalog.descriptor, { categoryId, ...(offset === undefined ? {} : { offset }), ...(limit === undefined ? {} : { limit }) });
        const extensions = getXtreamVodItemExtensions(page);
        catalog.movieExtensions ??= new Map();
        for (const item of page.items) catalog.movieExtensions.set(item.id, extensions.get(item.id));
        sendJson(res, 200, { ok: true, ...page });
        return true;
      }
      if (req.url?.startsWith('/api/catalog/xtream/series/')) {
        const sessionId = readCookie(req.headers.cookie, 'sp_playback_session');
        const session = sessions.getSession(sessionId);
        const catalog = sessionId && session ? seriesCatalogs.get(sessionId) : undefined;
        if (!catalog) throw new ConnectorError('The series catalogue is not available for this session.', 403, 'series_catalog_unavailable');
        sessions.rateLimit(session);
        if (req.url === '/api/catalog/xtream/series/categories') {
          const categories = await seriesCatalog.categories(catalog.descriptor);
          catalog.categoryIds = new Set(categories.map((category) => category.id));
          sendJson(res, 200, { ok: true, categories });
          return true;
        }
        if (req.url === '/api/catalog/xtream/series/items') {
          const categoryId = typeof body?.categoryId === 'string' ? body.categoryId.trim() : '';
          if (!catalog.categoryIds?.has(categoryId)) throw new ConnectorError('The series category is not available for this session.', 403, 'series_catalog_unavailable');
          const page = await seriesCatalog.items(catalog.descriptor, { categoryId, ...(body?.offset === undefined ? {} : { offset: body.offset }), ...(body?.limit === undefined ? {} : { limit: body.limit }) });
          for (const item of page.items) catalog.seriesIds.add(item.id);
          sendJson(res, 200, { ok: true, ...page });
          return true;
        }
        if (req.url === '/api/catalog/xtream/series/episodes') {
          const seriesId = typeof body?.seriesId === 'string' ? body.seriesId.trim() : '';
          if (!catalog.seriesIds?.has(seriesId)) throw new ConnectorError('The selected series is not available for this session.', 403, 'series_catalog_unavailable');
          const page = await seriesCatalog.episodes(catalog.descriptor, seriesId);
          catalog.episodeExtensions ??= new Map();
          const extensions = getXtreamSeriesItemExtensions(page.episodes);
          for (const episode of page.episodes) catalog.episodeExtensions.set(episode.id, extensions.get(episode.id));
          sendJson(res, 200, { ok: true, ...page });
          return true;
        }
      }
      const importedItems = [];
      const result = await (req.url === '/api/playlist/remote' ? importRemotePlaylist(body, { onItem: (item) => importedItems.push(item) }) : connect(body, { onItem: (item) => importedItems.push(item) }));
      const sessionId = sessions.createSession(importedItems);
      const xtreamCatalog = getXtreamCatalogDescriptor(result);
      if (sessionId && xtreamCatalog) {
        const expiresAt = Date.now() + 15 * 60_000;
        vodCatalogs.set(sessionId, { descriptor: xtreamCatalog, categoryIds: undefined, expiresAt });
        seriesCatalogs.set(sessionId, { descriptor: xtreamCatalog, categoryIds: undefined, seriesIds: new Set(), episodeExtensions: new Map(), expiresAt });
      }
      sendJson(res, 200, { ok: true, ...result, ...(sessionId && xtreamCatalog ? { vodAvailable: true, seriesAvailable: true } : {}) }, sessionId ? { 'set-cookie': sessionCookie(sessionId, { secure: options?.cookieSecure }) } : {});
    } catch (error) {
      const known = error instanceof ConnectorError;
      const status = known ? error.status : 500;
      const code = known ? error.code : 'internal_error';
      const message = known ? error.message : 'The playlist connector failed safely.';
      // Log only the safe route template, fixed error code/reason, and numeric
      // upstream status. Do not log opaque grant IDs, URLs, hostnames, or secrets.
      console.warn(`StreamPilot API request failed (${req.method} ${safeRouteLabel(req)}): ${redactSecrets(message)}${safeErrorDetails(error, known)}`);
      const phase = (req.url === '/api/playback/grants' || req.url === '/api/playback/grants/renew') ? 'grant' : req.url?.startsWith('/media/') ? 'media' : req.url?.includes('/asset/') ? 'asset' : 'manifest';
      const playbackCategory = playbackFailureCategory(error, { phase });
      const diagnostic = known ? { ...error.diagnostic, ...(playbackCategory ? { playbackCategory } : {}) } : { responseCategory: 'internal' };
            if (res.headersSent || res.writableEnded || res.destroyed) {
        if (res.headersSent && !res.writableEnded && !res.destroyed) {
          res.destroy();
        }
        return true;
      }

      sendJson(res, status, { ok: false, error: { code, ...(Object.keys(diagnostic).length ? { diagnostic } : {}) } });
    }
    return true;
  };
}
