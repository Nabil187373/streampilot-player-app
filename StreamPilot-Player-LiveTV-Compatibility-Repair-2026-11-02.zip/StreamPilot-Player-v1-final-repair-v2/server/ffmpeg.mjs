// Stage 1: isolated FFmpeg / FFprobe process runner.
//
// Scope: launch the two executables safely and report the result. This module
// is deliberately NOT connected to playback. It never fetches anything, never
// builds URLs, and never logs. Callers (later stages) are responsible for
// passing only inputs that were already authorized and validated elsewhere,
// preferably a local file or a pipe, never a raw provider URL.
//
// Safety properties:
// - child_process.spawn with shell:false and an argument array (no shell string)
// - validated executable paths and argument arrays
// - bounded run time and bounded combined stdout+stderr bytes
// - termination on timeout, overflow or abort, and the promise settles only
//   after the process has closed (with a force-kill and a final failsafe)
// - fixed error codes and messages; stderr is URL/secret-redacted and truncated
// - the arguments are never copied into an error, so secrets in args cannot leak

import { spawn as nodeSpawn } from 'node:child_process';

const DEFAULT_TIMEOUT_MS = 30_000;
const MAX_TIMEOUT_MS = 10 * 60_000;
const DEFAULT_MAX_OUTPUT_BYTES = 1024 * 1024;
const MAX_OUTPUT_BYTES = 64 * 1024 * 1024;
const DEFAULT_KILL_GRACE_MS = 2_000;
const MAX_KILL_GRACE_MS = 30_000;
const MAX_ARGUMENT_COUNT = 256;
const MAX_ARGUMENT_LENGTH = 8_192;
const MAX_EXECUTABLE_LENGTH = 4_096;
const MAX_STDERR_CHARS = 4_096;

const MESSAGES = Object.freeze({
  invalid_config: 'The media tool configuration is invalid.',
  invalid_arguments: 'The media tool arguments are invalid.',
  executable_not_found: 'The media tool executable was not found.',
  executable_not_executable: 'The media tool executable could not be run.',
  spawn_failed: 'The media tool could not be started.',
  timeout: 'The media tool timed out.',
  output_limit_exceeded: 'The media tool produced too much output.',
  nonzero_exit: 'The media tool exited with an error.',
  aborted: 'The media tool run was cancelled.',
});

export class MediaToolError extends Error {
  constructor(code, details = {}) {
    const known = Object.hasOwn(MESSAGES, code);
    super(known ? MESSAGES[code] : MESSAGES.spawn_failed);
    this.name = 'MediaToolError';
    this.code = known ? code : 'spawn_failed';
    this.exitCode = details.exitCode ?? null;
    this.signal = details.signal ?? null;
    this.stderr = details.stderr ?? '';
  }
}

function boundedInteger(value, fallback, max) {
  const resolved = value === undefined ? fallback : value;
  if (!Number.isSafeInteger(resolved) || resolved < 1 || resolved > max) {
    throw new MediaToolError('invalid_config');
  }
  return resolved;
}

function resolveExecutable(explicit, envValue, fallback) {
  const fromEnv = typeof envValue === 'string' && envValue.trim() !== '' ? envValue.trim() : undefined;
  const candidate = explicit !== undefined ? explicit : (fromEnv ?? fallback);
  if (
    typeof candidate !== 'string'
    || candidate.length < 1
    || candidate.length > MAX_EXECUTABLE_LENGTH
    || /[\0\r\n]/.test(candidate)
  ) {
    throw new MediaToolError('invalid_config');
  }
  return candidate;
}

function validateArguments(args) {
  if (!Array.isArray(args) || args.length < 1 || args.length > MAX_ARGUMENT_COUNT) {
    throw new MediaToolError('invalid_arguments');
  }
  for (const value of args) {
    if (
      typeof value !== 'string'
      || value.length < 1
      || value.length > MAX_ARGUMENT_LENGTH
      || value.includes('\0')
    ) {
      throw new MediaToolError('invalid_arguments');
    }
  }
  return [...args];
}

// Removes anything that looks like a URL or a credential-style key=value pair,
// then keeps only the tail. Redaction runs before truncation so a URL cut in
// half by the tail can never leave a readable fragment behind.
function sanitizeStderr(text) {
  const redacted = text
    .replace(/[A-Za-z][A-Za-z0-9+.-]*:\/\/[^\s'"<>]+/g, '[redacted-url]')
    .replace(/\b(password|passwd|pass|token|username|user|key|secret)=[^\s&'"<>]+/gi, '$1=[redacted]');
  return redacted.length > MAX_STDERR_CHARS ? redacted.slice(-MAX_STDERR_CHARS) : redacted;
}

function classifySpawnError(error) {
  const code = error && typeof error === 'object' ? error.code : undefined;
  if (code === 'ENOENT') return new MediaToolError('executable_not_found');
  if (code === 'EACCES' || code === 'EPERM') return new MediaToolError('executable_not_executable');
  return new MediaToolError('spawn_failed');
}

function run({ spawnImpl, executable, args, timeoutMs, maxOutputBytes, killGraceMs, signal }) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new MediaToolError('aborted'));
      return;
    }

    let child;
    try {
      child = spawnImpl(executable, args, {
        shell: false,
        windowsHide: true,
        stdio: ['ignore', 'pipe', 'pipe'],
      });
    } catch (error) {
      reject(classifySpawnError(error));
      return;
    }

    const stdoutChunks = [];
    const stderrChunks = [];
    let totalBytes = 0;
    let settled = false;
    let failure = null;
    let terminating = false;
    let timeoutTimer;
    let forceTimer;
    let failsafeTimer;

    const cleanup = () => {
      clearTimeout(timeoutTimer);
      clearTimeout(forceTimer);
      clearTimeout(failsafeTimer);
      signal?.removeEventListener?.('abort', onAbort);
    };

    const settle = (finish) => {
      if (settled) return;
      settled = true;
      cleanup();
      finish();
    };

    const safeKill = (killSignal) => {
      try {
        child.kill(killSignal);
      } catch {
        // The process may already be gone. Nothing to do.
      }
    };

    const terminate = (error) => {
      if (!failure) failure = error;
      if (terminating) return;
      terminating = true;
      safeKill('SIGTERM');
      forceTimer = setTimeout(() => safeKill('SIGKILL'), killGraceMs);
      // Last resort: if the process never reports 'close', stop waiting.
      failsafeTimer = setTimeout(() => settle(() => reject(failure)), killGraceMs * 2 + 100);
    };

    function onAbort() {
      terminate(new MediaToolError('aborted'));
    }

    const onData = (target) => (chunk) => {
      if (failure) return; // keep draining so the pipe cannot block the exit
      totalBytes += chunk.length;
      if (totalBytes > maxOutputBytes) {
        terminate(new MediaToolError('output_limit_exceeded'));
        return;
      }
      target.push(chunk);
    };

    timeoutTimer = setTimeout(() => terminate(new MediaToolError('timeout')), timeoutMs);
    signal?.addEventListener?.('abort', onAbort, { once: true });

    child.stdout?.on('data', onData(stdoutChunks));
    child.stderr?.on('data', onData(stderrChunks));
    child.stdout?.on('error', () => {});
    child.stderr?.on('error', () => {});

    child.on('error', (error) => {
      // A spawn failure (for example ENOENT) never gets a pid and never closes.
      if (child.pid === undefined) {
        settle(() => reject(failure ?? classifySpawnError(error)));
      }
    });

    child.on('close', (exitCode, closeSignal) => {
      settle(() => {
        if (failure) {
          reject(failure);
          return;
        }
        const stdout = Buffer.concat(stdoutChunks).toString('utf8');
        const stderr = Buffer.concat(stderrChunks).toString('utf8');
        if (exitCode === 0) {
          resolve({ exitCode: 0, stdout, stderr: sanitizeStderr(stderr) });
          return;
        }
        reject(new MediaToolError('nonzero_exit', {
          exitCode: typeof exitCode === 'number' ? exitCode : null,
          signal: typeof closeSignal === 'string' ? closeSignal : null,
          stderr: sanitizeStderr(stderr),
        }));
      });
    });
  });
}

export function createMediaToolRunner(options = {}) {
  const env = options.env ?? process.env;
  const spawnImpl = options.spawnImpl ?? nodeSpawn;
  if (typeof spawnImpl !== 'function') throw new MediaToolError('invalid_config');

  const ffmpegPath = resolveExecutable(options.ffmpegPath, env?.FFMPEG_PATH, 'ffmpeg');
  const ffprobePath = resolveExecutable(options.ffprobePath, env?.FFPROBE_PATH, 'ffprobe');
  const defaultTimeoutMs = boundedInteger(options.timeoutMs, DEFAULT_TIMEOUT_MS, MAX_TIMEOUT_MS);
  const defaultMaxOutputBytes = boundedInteger(options.maxOutputBytes, DEFAULT_MAX_OUTPUT_BYTES, MAX_OUTPUT_BYTES);
  const killGraceMs = boundedInteger(options.killGraceMs, DEFAULT_KILL_GRACE_MS, MAX_KILL_GRACE_MS);

  const execute = (executable, args, callOptions = {}) => {
    // Validate everything before spawning anything.
    const validatedArgs = validateArguments(args);
    const timeoutMs = boundedInteger(callOptions.timeoutMs, defaultTimeoutMs, MAX_TIMEOUT_MS);
    const maxOutputBytes = boundedInteger(callOptions.maxOutputBytes, defaultMaxOutputBytes, MAX_OUTPUT_BYTES);
    return run({
      spawnImpl,
      executable,
      args: validatedArgs,
      timeoutMs,
      maxOutputBytes,
      killGraceMs,
      signal: callOptions.signal,
    });
  };

  return Object.freeze({
    ffmpegPath,
    ffprobePath,
    runFfmpeg: (args, callOptions) => Promise.resolve().then(() => execute(ffmpegPath, args, callOptions)),
    runFfprobe: (args, callOptions) => Promise.resolve().then(() => execute(ffprobePath, args, callOptions)),
  });
}

// Lazy default runner configured from FFMPEG_PATH / FFPROBE_PATH. It is created
// on first use so that importing this module can never throw because of the
// environment.
let defaultRunner;
const getDefaultRunner = () => (defaultRunner ??= createMediaToolRunner());

export const mediaTools = Object.freeze({
  runFfmpeg: (args, callOptions) => getDefaultRunner().runFfmpeg(args, callOptions),
  runFfprobe: (args, callOptions) => getDefaultRunner().runFfprobe(args, callOptions),
});
