import crypto from 'node:crypto';
import net from 'node:net';
import { fetch as undiciFetch } from 'undici';
import { ConnectorError, isForbiddenAddress, resolveDestination } from './connector.mjs';
import { createPinnedDispatcher } from './pinned-transport.mjs';

const SESSION_TTL_MS = 15 * 60_000;
const SESSION_ABSOLUTE_TTL_MS = 6 * 60 * 60_000;
const GRANT_TTL_MS = 5 * 60_000;
const MAX_MANIFEST_BYTES = 1024 * 1024;
const MAX_ASSET_BYTES = 25 * 1024 * 1024;
const MAX_MANIFEST_LINE_BYTES = 16 * 1024;
const MAX_ASSETS_PER_GRANT = 10_000;
const REQUEST_TIMEOUT_MS = 30_000;
const MAX_REDIRECTS = 3;
const MAX_REQUESTS_PER_MINUTE = 300;
const PLAYBACK_STAGES = new Set(['initial_live_stream', 'nested_playlist', 'segment', 'key', 'map', 'redirect', 'asset']);
const LOCAL_DESTINATION_REJECTIONS = new Set(['hostname_not_allowlisted', 'dns_resolution_failed', 'resolved_address_not_allowed', 'ip_literal_not_allowed']);
const LOCAL_ASSET_IP_MISMATCHES = new Set(['source_ip_mismatch', 'port_mismatch']);
const LOCAL_IP_REDIRECT_BINDING_STATUSES = new Set(['disabled_in_production', 'missing_or_invalid', 'source_mismatch', 'destination_mismatch']);
const LOCAL_DOMAIN_TRUST_MISMATCHES = new Set(['domain_trust_mismatch']);
const LOCAL_MEDIA_IP_TRUST_MISMATCHES = new Set(['media_ip_trust_mismatch']);
const LOCAL_UPSTREAM_CAUSES = new Set(['dns_failed', 'connect_refused', 'connect_timeout', 'response_timeout', 'connection_reset', 'tls_error', 'upstream_http_status', 'pinned_lookup_error', 'unknown']);
const LOCAL_DIAGNOSTIC_TOKEN = /^[A-Za-z0-9_.-]{1,40}$/;

function opaqueId() { return crypto.randomBytes(32).toString('base64url'); }
function noStoreHeaders(contentType = 'application/json; charset=utf-8') {
  return { 'content-type': contentType, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' };
}

function localHostDiagnostic(url, playbackStage, destinationRejection, { requestPhase, redirectCount, ipRedirectBindingStatus, assetIpMismatch, domainTrustMismatch, mediaIpTrustMismatch } = {}) {
  const diagnostic = PLAYBACK_STAGES.has(playbackStage) ? { playbackStage } : {};
  if (process.env.NODE_ENV === 'production' || process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS !== '1') return diagnostic;
  if (requestPhase === 'manifest' || requestPhase === 'asset') diagnostic.requestPhase = requestPhase;
  if (Number.isInteger(redirectCount) && redirectCount >= 0 && redirectCount <= MAX_REDIRECTS) diagnostic.redirectCount = redirectCount;
  if (LOCAL_IP_REDIRECT_BINDING_STATUSES.has(ipRedirectBindingStatus)) diagnostic.ipRedirectBindingStatus = ipRedirectBindingStatus;
  if (LOCAL_ASSET_IP_MISMATCHES.has(assetIpMismatch)) diagnostic.assetIpMismatch = assetIpMismatch;
  if (LOCAL_DOMAIN_TRUST_MISMATCHES.has(domainTrustMismatch)) diagnostic.domainTrustMismatch = domainTrustMismatch;
  if (LOCAL_MEDIA_IP_TRUST_MISMATCHES.has(mediaIpTrustMismatch)) diagnostic.mediaIpTrustMismatch = mediaIpTrustMismatch;
  const hostname = url.hostname.toLowerCase().replace(/\.$/, '');
  const isIp = Boolean(canonicalIpLiteral(hostname));
  if (!domainTrustMismatch && !isIp && /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(hostname)) diagnostic.rejectedHostname = hostname;
  if (url.protocol === 'http:' || url.protocol === 'https:') diagnostic.rejectedScheme = url.protocol.slice(0, -1);
  if (LOCAL_DESTINATION_REJECTIONS.has(destinationRejection)) diagnostic.destinationRejection = destinationRejection;
  // Local-only operator aid for the exact HTTP-IP binding. This intentionally
  // excludes the URL, path, query, credentials, and every non-public address.
  const redirectIp = canonicalIpLiteral(url.hostname);
  if (requestPhase === 'manifest' && playbackStage === 'redirect' && url.protocol === 'http:' && redirectIp && !isForbiddenAddress(redirectIp)) {
    const redirectPort = url.port ? Number(url.port) : 80;
    if (Number.isInteger(redirectPort) && redirectPort >= 1 && redirectPort <= 65_535) {
      diagnostic.redirectDestinationIp = redirectIp;
      diagnostic.redirectDestinationPort = redirectPort;
    }
  }
  return diagnostic;
}

export function playbackUpstreamStage(playbackStage, requestPhase) {
  if (playbackStage === 'redirect') return 'redirect';
  return requestPhase === 'asset' ? 'asset' : 'manifest';
}

function localDiagnosticToken(value) {
  return typeof value === 'string' && LOCAL_DIAGNOSTIC_TOKEN.test(value) ? value : 'other';
}

function localUnknownErrorDiagnostic(error) {
  let current = error;
  for (let depth = 0; current && depth <= 3; depth += 1, current = current.cause) {
    if (Object.hasOwn(current, 'localDiagnosticName')) {
      return {
        upstreamErrorName: localDiagnosticToken(current.localDiagnosticName),
        upstreamErrorCode: localDiagnosticToken(current.localDiagnosticCode),
        upstreamErrorCauseCode: localDiagnosticToken(current.localDiagnosticCauseCode),
        upstreamErrorCauseCauseCode: localDiagnosticToken(current.localDiagnosticCauseCauseCode),
      };
    }
  }
  return {
    upstreamErrorName: localDiagnosticToken(error?.name),
    upstreamErrorCode: localDiagnosticToken(error?.code),
    upstreamErrorCauseCode: localDiagnosticToken(error?.cause?.code),
    upstreamErrorCauseCauseCode: localDiagnosticToken(error?.cause?.cause?.code),
  };
}

function localRedirectEndpointDiagnostic(url, playbackStage) {
  if (process.env.NODE_ENV === 'production' || process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS !== '1') return {};
  const redirectIp = canonicalIpLiteral(url.hostname);
  if (playbackStage !== 'redirect' || url.protocol !== 'http:' || !redirectIp || isForbiddenAddress(redirectIp)) return {};
  const redirectPort = url.port ? Number(url.port) : 80;
  return Number.isInteger(redirectPort) && redirectPort >= 1 && redirectPort <= 65_535
    ? { redirectDestinationIp: redirectIp, redirectDestinationPort: redirectPort }
    : {};
}

function localUpstreamAttemptDiagnostic(playbackStage, { requestPhase, redirectCount, upstreamCause, upstreamHttpStatus, error, requestTarget, url } = {}) {
  const diagnostic = PLAYBACK_STAGES.has(playbackStage) ? { playbackStage } : {};
  if (process.env.NODE_ENV === 'production' || process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS !== '1') return diagnostic;
  if (requestPhase === 'manifest' || requestPhase === 'asset') diagnostic.requestPhase = requestPhase;
  if (Number.isInteger(redirectCount) && redirectCount >= 0 && redirectCount <= MAX_REDIRECTS) diagnostic.redirectCount = redirectCount;
  if (LOCAL_UPSTREAM_CAUSES.has(upstreamCause)) {
    diagnostic.upstreamStage = playbackUpstreamStage(playbackStage, requestPhase);
    diagnostic.upstreamCause = upstreamCause;
  }
  if (upstreamCause === 'upstream_http_status' && Number.isInteger(upstreamHttpStatus) && upstreamHttpStatus >= 100 && upstreamHttpStatus <= 599) diagnostic.upstreamHttpStatus = upstreamHttpStatus;
  if (upstreamCause === 'unknown' && playbackStage === 'redirect') {
    Object.assign(diagnostic, localUnknownErrorDiagnostic(error), localRedirectEndpointDiagnostic(url, playbackStage));
    diagnostic.upstreamRequestTarget = requestTarget === 'pinned_redirect_destination' ? 'pinned_redirect_destination' : 'source_host';
  }
  return diagnostic;
}

function errorCodes(error, depth = 0, codes = new Set()) {
  if (!error || depth > 3) return codes;
  for (const value of [error.code, error.transportCode]) if (typeof value === 'string') codes.add(value);
  return errorCodes(error.cause, depth + 1, codes);
}

export function playbackUpstreamCause(error) {
  const codes = errorCodes(error);
  if (codes.has('ENOTFOUND') || codes.has('EAI_AGAIN') || codes.has('UND_ERR_DNS')) return 'dns_failed';
  if (codes.has('ECONNREFUSED')) return 'connect_refused';
  if (codes.has('ETIMEDOUT') || codes.has('UND_ERR_CONNECT_TIMEOUT')) return 'connect_timeout';
  if (codes.has('UND_ERR_HEADERS_TIMEOUT') || codes.has('ABORT_ERR') || error?.name === 'TimeoutError' || error?.name === 'AbortError') return 'response_timeout';
  if (codes.has('ECONNRESET') || codes.has('UND_ERR_SOCKET')) return 'connection_reset';
  if ([...codes].some((code) => /^(ERR_TLS|ERR_SSL|CERT_|DEPTH_|UNABLE_TO_VERIFY)/.test(code))) return 'tls_error';
  if (codes.has('PINNED_LOOKUP_ERROR')) return 'pinned_lookup_error';
  return 'unknown';
}

function readWithIdleTimeout(reader, timeoutMs) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => {
      const error = new Error('Playback body idle timeout.');
      error.name = 'TimeoutError';
      reject(error);
      // Reject first: cancelling a pending Web Stream read can synchronously
      // resolve it as `{ done: true }`, which must not turn an idle timeout
      // into an empty-manifest validation error.
      void reader.cancel().catch(() => {});
    }, timeoutMs);
  });
  return Promise.race([reader.read(), timeout]).finally(() => clearTimeout(timer));
}

function upstreamReadError(error, attempt) {
  if (error instanceof ConnectorError) return error;
  const cause = playbackUpstreamCause(error);
  const code = cause === 'response_timeout' ? 'provider_timeout' : 'provider_unreachable';
  return new ConnectorError(
    code === 'provider_timeout' ? 'The playback response timed out.' : 'The playback response could not be read.',
    code === 'provider_timeout' ? 504 : 502,
    code,
    localUpstreamAttemptDiagnostic(attempt.playbackStage, { ...attempt, upstreamCause: cause }),
  );
}

export function playbackFailureCategory(error, { phase = 'manifest' } = {}) {
  if (!(error instanceof ConnectorError)) return undefined;
  if (error.code === 'playback_unauthorized') return 'session_expired';
  if (error.code === 'playback_item_not_found') return phase === 'grant' ? 'grant_rejected' : 'asset_rejected';
  if (error.code === 'destination_not_allowed' || error.code === 'playback_not_configured') return 'host_not_allowed';
  if (error.code === 'playback_redirect_rejected') return 'redirect_rejected';
  if (error.code === 'provider_unreachable' || error.code === 'provider_timeout' || error.code === 'provider_http_error') return 'upstream_unreachable';
  if (error.code === 'playlist_too_large' || error.code === 'playback_manifest_invalid') return phase === 'asset' ? 'asset_rejected' : 'manifest_invalid';
  if (error.code === 'unsupported_response') return phase === 'media' ? 'media_codec_error' : phase === 'asset' ? 'asset_rejected' : 'manifest_invalid';
  return undefined;
}

export function playbackHostAllowlist(value = process.env.PLAYBACK_HOST_ALLOWLIST || '') {
  return value.split(',').map((host) => host.trim().toLowerCase()).filter(Boolean);
}

function canonicalHostname(value) {
  const hostname = typeof value === 'string' ? value.trim().toLowerCase().replace(/\.$/, '') : '';
  return /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(hostname) ? hostname : undefined;
}

function canonicalIpLiteral(value) {
  const hostname = typeof value === 'string' ? value.replace(/^\[|\]$/g, '').toLowerCase() : '';
  return net.isIP(hostname) ? hostname : undefined;
}

// This is an explicit operator-approved production setting, not a wildcard
// trust switch. It permits exactly one public IP for exactly one exact source
// hostname; a redundant global host allowlist entry is not required because
// the redirect source was already validated on the initial request. Every
// request still requires HTTP compatibility, a single redirect hop, public-
// address validation, and a pinned outbound connection.
// Invalid values disable the exception rather than broadening trust.
export function playbackHttpIpRedirectBinding(value = process.env.PLAYBACK_HTTP_IP_REDIRECT_BINDING || '') {
  const [source, destination, extra] = value.split('=').map((part) => part?.trim());
  const sourceHostname = canonicalHostname(source);
  const destinationIp = canonicalIpLiteral(destination);
  if (extra !== undefined || !sourceHostname || !destinationIp || isForbiddenAddress(destinationIp)) return undefined;
  return { sourceHostname, destinationIp };
}

// Local-development-only compatibility for a provider that chooses a public
// literal address at redirect time. Unlike the exact binding above, the IP is
// not configured; it is still constrained to a one-hop, same-port redirect
// from this one allowlisted source hostname.
export function playbackHttpIpRedirectTrust(value = process.env.PLAYBACK_HTTP_IP_REDIRECT_TRUST || '') {
  if (process.env.NODE_ENV === 'production') return undefined;
  return canonicalHostname(value);
}

// Local-development-only compatibility for a movie provider that redirects
// from one allowlisted hostname to a public literal address. The destination
// is still independently classified and connected through a pinned dispatcher.
export function playbackMediaIpRedirectTrust(value = process.env.PLAYBACK_MEDIA_IP_REDIRECT_TRUST || '') {
  if (process.env.NODE_ENV === 'production') return undefined;
  return canonicalHostname(value);
}

// Development-only compatibility for a provider that redirects from one
// explicitly approved source hostname to a rotating hostname under a tightly
// configured suffix. The destination is still resolved, checked, and pinned.
export function playbackProviderDomainTrust(value = process.env.PLAYBACK_PROVIDER_DOMAIN_TRUST || '') {
  if (process.env.NODE_ENV === 'production') return undefined;
  const [source, rawSuffixes, extra] = value.split('=').map((part) => part?.trim());
  const sourceHostname = canonicalHostname(source);
  if (extra !== undefined || !sourceHostname || !rawSuffixes) return undefined;
  const suffixes = rawSuffixes.split('|').map((value) => value.trim()).map((suffix) => {
    if (!suffix.startsWith('.')) return undefined;
    const hostname = canonicalHostname(suffix.slice(1));
    return hostname && hostname.split('.').length >= 2 ? `.${hostname}` : undefined;
  });
  if (!suffixes.length || suffixes.some((suffix) => !suffix) || new Set(suffixes).size !== suffixes.length) return undefined;
  return { sourceHostname, suffixes };
}

function effectivePort(url) {
  return Number(url.port) || (url.protocol === 'https:' ? 443 : 80);
}

function ipRedirectBindingStatus({ url, playbackStage, redirectSourceHostname, httpIpRedirectBinding }) {
  const destinationIp = canonicalIpLiteral(url.hostname);
  if (!destinationIp || playbackStage !== 'redirect' || url.protocol !== 'http:') return undefined;
  if (!httpIpRedirectBinding) return 'missing_or_invalid';
  if (redirectSourceHostname !== httpIpRedirectBinding.sourceHostname) return 'source_mismatch';
  if (destinationIp !== httpIpRedirectBinding.destinationIp) return 'destination_mismatch';
  return undefined;
}

function createBoundIpRedirectDispatcher({ destinationIp, timeoutMs = REQUEST_TIMEOUT_MS }) {
  return createPinnedDispatcher({ allowHttp: true, ipLiteralAllowlist: [destinationIp], connections: 1, pipelining: 0, connectTimeout: timeoutMs, headersTimeout: timeoutMs, bodyTimeout: 0 }).dispatcher;
}

function matchesTrustedDomainSuffix(hostname, suffixes) {
  return Boolean(hostname && suffixes?.some((suffix) => hostname.length > suffix.length && hostname.endsWith(suffix)));
}

function domainTrustMismatchStatus({ url, playbackStage, redirectSourceHostname, providerDomainTrust }) {
  if (process.env.NODE_ENV === 'production' || playbackStage !== 'redirect' || !providerDomainTrust || redirectSourceHostname !== providerDomainTrust.sourceHostname) return undefined;
  const destinationHostname = canonicalHostname(url.hostname);
  return !destinationHostname || canonicalIpLiteral(url.hostname) || !matchesTrustedDomainSuffix(destinationHostname, providerDomainTrust.suffixes)
    ? 'domain_trust_mismatch'
    : undefined;
}

function mediaIpTrustMismatchStatus({ url, playbackStage, requestPhase, requestMethod, redirectSourceHostname, redirectSourcePort, mediaIpRedirectTrust, hostAllowlist }) {
  const destinationIp = canonicalIpLiteral(url.hostname);
  if (!destinationIp || playbackStage !== 'redirect' || requestPhase !== 'media') return undefined;
  if (process.env.NODE_ENV === 'production' || !mediaIpRedirectTrust || !hostAllowlist.includes(mediaIpRedirectTrust) || redirectSourceHostname !== mediaIpRedirectTrust || !['GET', 'HEAD'].includes(requestMethod) || url.protocol !== 'http:' || url.username || url.password || (effectivePort(url) !== 80 && effectivePort(url) !== redirectSourcePort)) {
    return 'media_ip_trust_mismatch';
  }
  return undefined;
}

function createBoundDomainRedirectDispatcher({ destinationHostname, destinationRecords, allowHttp, timeoutMs = REQUEST_TIMEOUT_MS }) {
  const hostname = canonicalHostname(destinationHostname);
  const records = Array.isArray(destinationRecords) ? destinationRecords.map(({ address, family }) => ({ address, family })) : [];
  if (!hostname || !records.length) throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed');
  const lookup = async (requestedHostname) => {
    if (canonicalHostname(requestedHostname) !== hostname) throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed');
    return records;
  };
  return createPinnedDispatcher({ lookup, allowHttp, hostAllowlist: [hostname], connections: 1, pipelining: 0, connectTimeout: timeoutMs, headersTimeout: timeoutMs, bodyTimeout: 0 }).dispatcher;
}

async function validatePlaybackDestination(url, { lookup, allowHttp, hostAllowlist, httpIpRedirectBinding, httpIpRedirectTrust, mediaIpRedirectTrust, providerDomainTrust, trustedAssetEndpoint, trustedDomainEndpoint, playbackStage, redirectSourceHostname, redirectSourcePort, requestMethod, requestPhase, disableMovieIpRedirect }) {
  const destinationIp = canonicalIpLiteral(url.hostname);
  const destinationHostname = canonicalHostname(url.hostname);
  // If an operator explicitly configured a provider-domain trust suffix, keep
  // that narrow trust contract strict. This is separate from ordinary provider
  // compatibility, which does not require deployment-wide host allowlisting.
  const domainTrustMismatch = domainTrustMismatchStatus({ url, playbackStage, redirectSourceHostname, providerDomainTrust });
  if (domainTrustMismatch) {
    throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed', {}, { destinationRejection: 'redirect_target_not_trusted' });
  }
  // Once a grant is bound to a trusted provider-domain redirect endpoint, its
  // nested assets must stay on that exact validated hostname. Ordinary grants
  // without this explicit trust mode can use independently validated public
  // CDN hosts for HLS segments, keys, and nested playlists.
  if ((requestPhase === 'asset' || playbackStage === 'redirect') && trustedDomainEndpoint
      && (!destinationHostname || destinationIp || destinationHostname !== trustedDomainEndpoint.destinationHostname)) {
    throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed', {}, { destinationRejection: 'redirect_target_not_trusted' });
  }
  const isExactBoundHttpRedirect = Boolean(
    destinationIp
    && playbackStage === 'redirect'
    && allowHttp
    && url.protocol === 'http:'
    && httpIpRedirectBinding
    && redirectSourceHostname === httpIpRedirectBinding.sourceHostname
    && destinationIp === httpIpRedirectBinding.destinationIp, // Exact operator binding is sufficient; global hostAllowlist is not required.
  );
  const isTrustedSamePortHttpRedirect = Boolean(
    destinationIp
    && process.env.NODE_ENV !== 'production'
    && playbackStage === 'redirect'
    && requestMethod === 'GET'
    && allowHttp
    && url.protocol === 'http:'
    && httpIpRedirectTrust
    && redirectSourceHostname === httpIpRedirectTrust
    && hostAllowlist.includes(httpIpRedirectTrust)
    && redirectSourcePort === effectivePort(url),
  );
  const isTrustedMediaIpRedirect = Boolean(
    destinationIp
    && process.env.NODE_ENV !== 'production'
    && playbackStage === 'redirect'
    && requestPhase === 'media'
    && ['GET', 'HEAD'].includes(requestMethod)
    && allowHttp
    && url.protocol === 'http:'
    && mediaIpRedirectTrust
    && redirectSourceHostname === mediaIpRedirectTrust
    && hostAllowlist.includes(mediaIpRedirectTrust)
    && (effectivePort(url) === 80 || redirectSourcePort === effectivePort(url)),
  );
  const canUseTrustedAssetEndpoint = Boolean(
    destinationIp
    && process.env.NODE_ENV !== 'production'
    && requestPhase === 'asset'
    && requestMethod === 'GET'
    && allowHttp
    && url.protocol === 'http:'
    && httpIpRedirectTrust
    && trustedAssetEndpoint
    && httpIpRedirectTrust === trustedAssetEndpoint.sourceHostname
    && hostAllowlist.includes(httpIpRedirectTrust),
  );
  const isTrustedDomainRedirect = Boolean(
    !destinationIp
    && process.env.NODE_ENV !== 'production'
    && playbackStage === 'redirect'
    && requestMethod === 'GET'
    && providerDomainTrust
    && redirectSourceHostname === providerDomainTrust.sourceHostname
    && hostAllowlist.includes(providerDomainTrust.sourceHostname)
    && matchesTrustedDomainSuffix(destinationHostname, providerDomainTrust.suffixes),
  );
  const canUseTrustedDomainEndpoint = Boolean(
    !destinationIp
    && process.env.NODE_ENV !== 'production'
    && requestPhase === 'asset'
    && requestMethod === 'GET'
    && providerDomainTrust
    && trustedDomainEndpoint
    && providerDomainTrust.sourceHostname === trustedDomainEndpoint.sourceHostname
    && hostAllowlist.includes(providerDomainTrust.sourceHostname)
    && destinationHostname === trustedDomainEndpoint.destinationHostname,
  );
  if (isTrustedDomainRedirect || canUseTrustedDomainEndpoint) {
    if (url.username || url.password || url.hash) throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed', {}, { destinationRejection: 'resolved_address_not_allowed' });
    const trustedLookup = async (requestedHostname) => {
      if (canonicalHostname(requestedHostname) !== destinationHostname) {
        throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed');
      }
      return trustedDomainEndpoint.destinationRecords;
    };
    const resolved = await resolveDestination(url.toString(), {
      lookup: canUseTrustedDomainEndpoint ? trustedLookup : lookup,
      allowHttp,
      hostAllowlist: [destinationHostname],
    });
    if (!Array.isArray(resolved.records) || !resolved.records.length || resolved.records.some(({ address }) => isForbiddenAddress(address))) {
      throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed', {}, { destinationRejection: 'resolved_address_not_allowed' });
    }
    return {
      trustedDomainEndpoint: isTrustedDomainRedirect
        ? { sourceHostname: providerDomainTrust.sourceHostname, destinationHostname, destinationRecords: resolved.records.map(({ address, family }) => ({ address, family })) }
        : trustedDomainEndpoint,
    };
  }
  // Provider and CDN hostnames come from the customer-authorized, server-held
  // playback grant. Do not require deployment-wide hostname allowlist entries
  // for initial streams, redirects, or HLS assets. Every destination still
  // passes scheme checks, complete DNS-answer validation, private/reserved-IP
  // rejection, bounded redirect handling, and a DNS-pinned outbound connection.
  if (!isExactBoundHttpRedirect && !isTrustedSamePortHttpRedirect && !isTrustedMediaIpRedirect && !canUseTrustedAssetEndpoint) {
    // Public IP-literal redirects are a normal provider compatibility case for
    // Live TV, VOD, and HLS assets. Validate the exact address with the same
    // public-address policy as a hostname resolution, then pin the outbound
    // socket to that literal. Redirect chains from an IP literal are rejected
    // by fetchValidated, so a provider gets one validated hostname-to-IP hop,
    // not an unrestricted redirect proxy. HTTPS still uses strict TLS checks.
    if (disableMovieIpRedirect && playbackStage === 'redirect' && requestPhase === 'media' && destinationIp) {
      throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed', {}, { destinationRejection: 'redirect_target_not_trusted' });
    }
    const resolved = await resolveDestination(url.toString(), { lookup, allowHttp, hostAllowlist });
    if (destinationIp && playbackStage === 'redirect') {
      return { destinationIp, destinationRecords: resolved.records.map(({ address, family }) => ({ address, family })) };
    }
    return { destinationRecords: resolved.records.map(({ address, family }) => ({ address, family })) };
  }
  if (url.username || url.password || url.hash || isForbiddenAddress(destinationIp)) {
    throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed', {}, { destinationRejection: 'resolved_address_not_allowed' });
  }
  if (canUseTrustedAssetEndpoint && destinationIp !== trustedAssetEndpoint.destinationIp) {
    throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed', {}, { assetIpMismatch: 'source_ip_mismatch' });
  }
  if (canUseTrustedAssetEndpoint && effectivePort(url) !== trustedAssetEndpoint.destinationPort) {
    throw new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed', {}, { assetIpMismatch: 'port_mismatch' });
  }
  return {
    destinationIp,
    trustedAssetEndpoint: isTrustedSamePortHttpRedirect
      ? { sourceHostname: httpIpRedirectTrust, destinationIp, destinationPort: effectivePort(url) }
      : undefined,
  };
}

export function readCookie(header, name) {
  for (const part of String(header || '').split(';')) {
    const [key, ...value] = part.trim().split('=');
    if (key === name) return value.join('=');
  }
  return undefined;
}

export function sessionCookie(sessionId, { secure = process.env.NODE_ENV === 'production', maxAgeSeconds = Math.floor(SESSION_TTL_MS / 1000) } = {}) {
  return `sp_playback_session=${sessionId}; Max-Age=${maxAgeSeconds}; Path=/; HttpOnly; SameSite=Strict${secure ? '; Secure' : ''}`;
}

export class PlaybackSessions {
  constructor({ now = () => Date.now(), sessionTtlMs = SESSION_TTL_MS, sessionAbsoluteTtlMs = SESSION_ABSOLUTE_TTL_MS, grantTtlMs = GRANT_TTL_MS } = {}) {
    this.now = now; this.sessionTtlMs = sessionTtlMs; this.sessionAbsoluteTtlMs = sessionAbsoluteTtlMs; this.grantTtlMs = grantTtlMs; this.sessions = new Map();
    this.cleanupTimer = setInterval(() => this.cleanup(), Math.min(this.sessionTtlMs, 60_000));
    this.cleanupTimer.unref?.();
  }
  cleanup() {
    const now = this.now();
    for (const [id, session] of this.sessions) if (session.expiresAt <= now) this.sessions.delete(id);
  }
  createSession(importedItems) {
    this.cleanup();
    const items = new Map(importedItems.filter((item) => item.kind === 'live').map((item) => [item.id, { id: item.id, upstreamUrl: item.upstreamUrl }]));
    if (!items.size) return undefined;
    const id = opaqueId();
    const createdAt = this.now();
    const absoluteExpiresAt = createdAt + this.sessionAbsoluteTtlMs;
    this.sessions.set(id, { createdAt, absoluteExpiresAt, expiresAt: Math.min(absoluteExpiresAt, createdAt + this.sessionTtlMs), items, grants: new Map(), requests: [] });
    return id;
  }
  getSession(sessionId) {
    this.cleanup();
    return sessionId ? this.sessions.get(sessionId) : undefined;
  }
  assertCanTouchForMovie(sessionId) {
    const session = this.getSession(sessionId);
    const now = this.now();
    if (!session || now >= session.absoluteExpiresAt) throw new ConnectorError('Movie playback authorization expired. Request movie playback again.', 401, 'playback_unauthorized');
    return { session, now };
  }
  touchForMovie(sessionId) {
    const { session, now } = this.assertCanTouchForMovie(sessionId);
    session.expiresAt = Math.min(session.absoluteExpiresAt, now + this.sessionTtlMs);
    return { session, maxAgeSeconds: Math.max(0, Math.floor((session.expiresAt - now) / 1000)) };
  }
  touchForPlayback(sessionId, grantId) {
    const { session, grant } = this.getGrant(sessionId, grantId);
    const refreshed = this.touchForMovie(sessionId);
    grant.expiresAt = Math.min(session.absoluteExpiresAt, refreshed.session.expiresAt, this.now() + this.grantTtlMs);
    return { session: refreshed.session, grant, maxAgeSeconds: refreshed.maxAgeSeconds };
  }
  renewGrant(sessionId, grantId) {
    const session = this.getSession(sessionId);
    const previous = session?.grants.get(grantId);
    if (!session || !previous || session.absoluteExpiresAt <= this.now()) throw new ConnectorError('Playback authorization expired. Import the provider playlist again.', 401, 'playback_unauthorized');
    session.expiresAt = Math.min(session.absoluteExpiresAt, this.now() + this.sessionTtlMs);
    return { grantId: this.createGrant(sessionId, previous.itemId), maxAgeSeconds: Math.max(0, Math.floor((session.expiresAt - this.now()) / 1000)) };
  }
  createGrant(sessionId, itemId) {
    const session = this.getSession(sessionId);
    if (!session) throw new ConnectorError('Playback authorization expired. Import the provider playlist again.', 401, 'playback_unauthorized');
    if (typeof itemId !== 'string' || !session.items.has(itemId)) throw new ConnectorError('That provider item is not available for live playback.', 404, 'playback_item_not_found');
    const id = opaqueId();
    session.grants.set(id, { itemId, expiresAt: Math.min(session.expiresAt, this.now() + this.grantTtlMs), assets: new Map(), trustedAssetEndpoint: undefined, trustedDomainEndpoint: undefined, lastDiagnostic: undefined });
    return id;
  }
  getGrant(sessionId, grantId) {
    const session = this.getSession(sessionId);
    const grant = session?.grants.get(grantId);
    if (!session || !grant || grant.expiresAt <= this.now()) throw new ConnectorError('Playback authorization expired. Import the provider playlist again.', 401, 'playback_unauthorized');
    return { session, grant, item: session.items.get(grant.itemId) };
  }
  addAsset(grant, upstreamUrl, playbackStage = 'segment') {
    if (grant.assets.size >= MAX_ASSETS_PER_GRANT) throw new ConnectorError('The HLS manifest has too many playback resources.', 502, 'unsupported_response');
    const id = opaqueId(); grant.assets.set(id, { upstreamUrl, playbackStage }); return id;
  }
  getAsset(sessionId, grantId, assetId) {
    const { grant } = this.getGrant(sessionId, grantId);
    const asset = grant.assets.get(assetId);
    if (!asset) throw new ConnectorError('That playback resource is not available.', 404, 'playback_item_not_found');
    return { grant, ...asset };
  }
  setDiagnostic(grant, diagnostic) { if (diagnostic?.category) grant.lastDiagnostic = diagnostic; }
  rateLimit(session) {
    const now = this.now(); session.requests = session.requests.filter((time) => now - time < 60_000);
    if (session.requests.length >= MAX_REQUESTS_PER_MINUTE) throw new ConnectorError('Too many playback requests. Try again shortly.', 429, 'rate_limited');
    session.requests.push(now);
  }
}

async function fetchValidated(rawUrl, { fetchImpl, dispatcher, boundIpRedirectDispatcherFactory = createBoundIpRedirectDispatcher, boundDomainRedirectDispatcherFactory = createBoundDomainRedirectDispatcher, lookup, allowHttp = true, httpIpRedirectBinding = playbackHttpIpRedirectBinding(), httpIpRedirectTrust = playbackHttpIpRedirectTrust(), mediaIpRedirectTrust, providerDomainTrust = playbackProviderDomainTrust(), trustedAssetEndpoint, trustedDomainEndpoint, disableMovieIpRedirect = false, hostAllowlist, timeoutMs = REQUEST_TIMEOUT_MS, accept, requestHeaders = {}, requestMethod = 'GET', acceptedStatuses = [], playbackStage = 'asset', requestPhase }) {
  let current;
  try { current = new URL(rawUrl); } catch { throw new ConnectorError('The playback source URL is invalid.', 502, 'unsupported_response'); }
  let currentStage = playbackStage;
  let redirectSourceHostname;
  let redirectSourcePort;
  for (let count = 0; count <= MAX_REDIRECTS; count += 1) {
    let validation;
    try { validation = await validatePlaybackDestination(current, { lookup, allowHttp, hostAllowlist, httpIpRedirectBinding, httpIpRedirectTrust, mediaIpRedirectTrust, providerDomainTrust, trustedAssetEndpoint, trustedDomainEndpoint, disableMovieIpRedirect, playbackStage: currentStage, redirectSourceHostname, redirectSourcePort, requestMethod, requestPhase }); }
    catch (error) {
      if (error instanceof ConnectorError) {
        // The only optional local diagnostic is assembled in memory for the
        // session-bound diagnostic endpoint.  Do not log a redirect target:
        // its port, path, query, and credentials can be sensitive.
        const bindingStatus = ipRedirectBindingStatus({ url: current, playbackStage: currentStage, redirectSourceHostname, httpIpRedirectBinding });
        const domainTrustMismatch = domainTrustMismatchStatus({ url: current, playbackStage: currentStage, redirectSourceHostname, providerDomainTrust });
        const mediaIpTrustMismatch = mediaIpTrustMismatchStatus({ url: current, playbackStage: currentStage, requestPhase, requestMethod, redirectSourceHostname, redirectSourcePort, mediaIpRedirectTrust, hostAllowlist });
        error.diagnostic = { ...error.diagnostic, ...localHostDiagnostic(current, currentStage, error.localDiagnostic.destinationRejection, { requestPhase, redirectCount: count, ipRedirectBindingStatus: bindingStatus, assetIpMismatch: error.localDiagnostic.assetIpMismatch, domainTrustMismatch, mediaIpTrustMismatch }) };
        throw error;
      }
      throw new ConnectorError('The playback source could not be reached.', 502, 'provider_unreachable');
    }
    // Carry a development-only provider-domain redirect binding across the
    // redirect chain. A trusted first hop may serve its own assets, but must
    // not silently authorize a second, unrelated CDN hostname.
    if (validation.trustedDomainEndpoint) trustedDomainEndpoint = validation.trustedDomainEndpoint;
    const boundDispatcher = validation.destinationIp
      ? boundIpRedirectDispatcherFactory({ destinationIp: validation.destinationIp, timeoutMs })
      : validation.trustedDomainEndpoint
        ? boundDomainRedirectDispatcherFactory({ ...validation.trustedDomainEndpoint, allowHttp, timeoutMs })
        : validation.destinationRecords && currentStage === 'redirect'
          ? boundDomainRedirectDispatcherFactory({ destinationHostname: current.hostname, destinationRecords: validation.destinationRecords, allowHttp, timeoutMs })
          : validation.destinationRecords && !dispatcher
            ? createBoundDomainRedirectDispatcher({ destinationHostname: current.hostname, destinationRecords: validation.destinationRecords, allowHttp, timeoutMs })
            : undefined;
    const closeBoundDispatcher = async () => { await boundDispatcher?.close?.().catch(() => {}); };
    const requestDispatcher = boundDispatcher || dispatcher;
    // A dispatcher created by the separately installed Undici package is not
    // accepted by Node's built-in fetch. Keep injected fetch functions for
    // tests, but pair the default dispatcher path with Undici's fetch.
    const requestFetch = fetchImpl ?? (requestDispatcher ? undiciFetch : fetch);
    let response;
    const responseDeadline = new AbortController();
    const responseTimer = setTimeout(() => responseDeadline.abort(), timeoutMs);
    try { response = await requestFetch(current, { method: requestMethod, redirect: 'manual', signal: responseDeadline.signal, headers: { Accept: accept, ...requestHeaders }, ...(requestDispatcher ? { dispatcher: requestDispatcher } : {}) }); }
    catch (error) {
      await closeBoundDispatcher();
      const cause = playbackUpstreamCause(error);
      throw new ConnectorError(
        cause === 'response_timeout' || cause === 'connect_timeout' ? 'The playback source timed out.' : 'The playback source could not be reached.',
        cause === 'response_timeout' || cause === 'connect_timeout' ? 504 : 502,
        cause === 'response_timeout' || cause === 'connect_timeout' ? 'provider_timeout' : 'provider_unreachable',
        localUpstreamAttemptDiagnostic(currentStage, { requestPhase, redirectCount: count, upstreamCause: cause, error, requestTarget: validation.destinationIp ? 'pinned_redirect_destination' : 'source_host', url: current }),
      );
    } finally {
      clearTimeout(responseTimer);
    }
    if (![301, 302, 303, 307, 308].includes(response.status)) {
      if (!response.ok && !acceptedStatuses.includes(response.status)) {
        await closeBoundDispatcher();
        throw new ConnectorError('The playback source returned an error.', 502, 'provider_http_error', { providerStatus: response.status, ...localUpstreamAttemptDiagnostic(currentStage, { requestPhase, redirectCount: count, upstreamCause: 'upstream_http_status', upstreamHttpStatus: response.status }) });
      }
      return { response, url: current, closeDispatcher: closeBoundDispatcher, trustedAssetEndpoint: validation.trustedAssetEndpoint, trustedDomainEndpoint: validation.trustedDomainEndpoint, attempt: { playbackStage: currentStage, requestPhase, redirectCount: count, idleTimeoutMs: timeoutMs } };
    }
    const location = response.headers.get('location');
    if (!location || count === MAX_REDIRECTS) { await closeBoundDispatcher(); throw new ConnectorError('The playback redirect could not be followed safely.', 502, 'playback_redirect_rejected'); }
    // A literal destination may return the requested manifest, but it may not
    // continue the chain. This keeps the trusted compatibility mode to one
    // source-hostname-to-literal-IP hop.
    if (canonicalIpLiteral(current.hostname)) { await closeBoundDispatcher(); throw new ConnectorError('The playback redirect could not be followed safely.', 502, 'playback_redirect_rejected'); }
    await response.body?.cancel().catch(() => {});
    await closeBoundDispatcher();
    redirectSourceHostname = canonicalHostname(current.hostname);
    redirectSourcePort = effectivePort(current);
    try { current = new URL(location, current); } catch { throw new ConnectorError('The playback redirect could not be followed safely.', 502, 'playback_redirect_rejected'); }
    currentStage = 'redirect';
  }
  throw new ConnectorError('The playback redirect could not be followed safely.', 502, 'playback_redirect_rejected');
}

async function readLimitedText(response, limit = MAX_MANIFEST_BYTES, attempt) {
  const declared = Number(response.headers.get('content-length') || 0);
  if (declared > limit) throw new ConnectorError('The HLS manifest is too large to proxy safely.', 413, 'playlist_too_large');
  const reader = response.body?.getReader();
  if (!reader) throw new ConnectorError('The HLS manifest could not be read.', 502, 'unsupported_response');
  const chunks = []; let size = 0;
  try {
    while (true) {
      let result;
      try { result = await readWithIdleTimeout(reader, attempt?.idleTimeoutMs ?? REQUEST_TIMEOUT_MS); }
      catch (error) { throw upstreamReadError(error, attempt); }
      const { done, value } = result; if (done) break;
      size += value.byteLength; if (size > limit) throw new ConnectorError('The HLS manifest is too large to proxy safely.', 413, 'playlist_too_large');
      chunks.push(value);
    }
  } finally { await reader.cancel().catch(() => {}); }
  const text = new TextDecoder().decode(Buffer.concat(chunks));
  if (!text.trimStart().startsWith('#EXTM3U')) throw new ConnectorError('The playback source was not an HLS manifest.', 502, 'playback_manifest_invalid');
  if (text.split(/\r?\n/).some((line) => Buffer.byteLength(line, 'utf8') > MAX_MANIFEST_LINE_BYTES)) throw new ConnectorError('The HLS manifest contains an unsafe line length.', 502, 'playback_manifest_invalid');
  return text;
}

function rewriteManifest(manifest, baseUrl, addAsset) {
  let nextLineStage = 'segment';
  const rewrite = (value, playbackStage) => {
    let target;
    try { target = new URL(value, baseUrl); } catch { throw new ConnectorError('The HLS manifest contains an invalid resource reference.', 502, 'unsupported_response'); }
    if (!['https:', 'http:'].includes(target.protocol)) throw new ConnectorError('The HLS manifest contains an unsupported resource reference.', 502, 'unsupported_response');
    return `/api/playback/${addAsset(target.toString(), playbackStage)}`;
  };
  return manifest.split(/(\r?\n)/).map((line) => {
    if (!line || /^\r?\n$/.test(line)) return line;
    if (!line.startsWith('#')) {
      const stage = nextLineStage; nextLineStage = 'segment';
      return rewrite(line.trim(), stage);
    }
    if (/^#EXT-X-STREAM-INF:/i.test(line)) nextLineStage = 'nested_playlist';
    let attributeStage = 'segment';
    if (/^#EXT-X-(?:KEY|SESSION-KEY):/i.test(line)) attributeStage = 'key';
    else if (/^#EXT-X-MAP:/i.test(line)) attributeStage = 'map';
    else if (/^#EXT-X-(?:MEDIA|I-FRAME-STREAM-INF|IMAGE-STREAM-INF|RENDITION-REPORT):/i.test(line)) attributeStage = 'nested_playlist';
    else if (/^#EXT-X-(?:SESSION-DATA|PART|PRELOAD-HINT):/i.test(line)) attributeStage = 'segment';
    return line.replace(/\bURI=(?:"([^"]*)"|'([^']*)')/gi, (_match, doubleQuoted, singleQuoted) => `URI="${rewrite(doubleQuoted ?? singleQuoted, attributeStage)}"`);
  }).join('');
}

function isManifestResponse(response, url) {
  const contentType = (response.headers.get('content-type') || '').toLowerCase();
  return /mpegurl|mpeg-url/.test(contentType) || new URL(url).pathname.toLowerCase().endsWith('.m3u8');
}

async function sendAsset(res, response, attempt, extraHeaders = {}) {
  const declared = Number(response.headers.get('content-length') || 0);
  if (declared > MAX_ASSET_BYTES) throw new ConnectorError('The playback segment is too large to proxy safely.', 413, 'playlist_too_large');
  const reader = response.body?.getReader();
  if (!reader) throw new ConnectorError('The playback segment could not be read.', 502, 'unsupported_response');
  const upstreamType = response.headers.get('content-type') || 'application/octet-stream';
  const contentType = /^[\w!#$&^_.+\-]+\/[\w!#$&^_.+\-]+(?:;[^\r\n]*)?$/i.test(upstreamType) ? upstreamType : 'application/octet-stream';
  const headers = { ...noStoreHeaders(contentType) };
  const contentRange = response.headers.get('content-range');
  if (contentRange && /^bytes \d+-\d+\/\d+$/.test(contentRange)) headers['content-range'] = contentRange;
  if (response.headers.get('accept-ranges') === 'bytes') headers['accept-ranges'] = 'bytes';
  res.writeHead(response.status === 206 ? 206 : 200, headers);
  let size = 0;
  try {
    while (true) {
      let result;
      try { result = await readWithIdleTimeout(reader, attempt?.idleTimeoutMs ?? REQUEST_TIMEOUT_MS); }
      catch (error) { throw upstreamReadError(error, attempt); }
      const { done, value } = result; if (done) break;
      size += value.byteLength; if (size > MAX_ASSET_BYTES) { res.destroy(); return; }
      if (!res.write(Buffer.from(value))) {
  const drained = await new Promise((resolve) => {
    let settled = false;
    const cleanup = () => {
      res.removeListener('drain', onDrain);
      res.removeListener('close', onClose);
    };
    const finish = (value) => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve(value);
    };
    const onDrain = () => finish(true);
    const onClose = () => finish(false);
    res.once('drain', onDrain);
    res.once('close', onClose);
    if (res.destroyed || res.writableEnded) finish(false);
  });
  if (!drained) {
    await reader.cancel().catch(() => {});
    return;
  }
}
    }
    res.end();
  } finally { await reader.cancel().catch(() => {}); }
}

function parseSingleRange(value) {
  if (value === undefined) return undefined;
  if (typeof value !== 'string') throw new ConnectorError('The movie Range request is invalid.', 416, 'invalid_range');
  const match = value.match(/^bytes=(\d*)-(\d*)$/);
  if (!match || (!match[1] && !match[2]) || (match[1] && match[2] && Number(match[1]) > Number(match[2]))) {
    throw new ConnectorError('The movie Range request is invalid.', 416, 'invalid_range');
  }
  return value;
}

function mediaHeaders(response) {
  const upstreamType = response.headers.get('content-type') || 'application/octet-stream';
  const safeMovieType = /^(?:video\/[\w!#$&^_.+\-]+|application\/octet-stream)(?:;[^\r\n]*)?$/i.test(upstreamType);
  if (!safeMovieType) throw new ConnectorError('The provider returned an unsupported movie media type.', 502, 'unsupported_response');
  const contentType = upstreamType;
  const headers = { ...noStoreHeaders(contentType) };
  const contentLength = response.headers.get('content-length');
  if (contentLength && /^\d+$/.test(contentLength)) headers['content-length'] = contentLength;
  const contentRange = response.headers.get('content-range');
  if (contentRange && /^(?:bytes \d+-\d+\/\d+|bytes \*\/\d+)$/.test(contentRange)) headers['content-range'] = contentRange;
  if (response.headers.get('accept-ranges') === 'bytes') headers['accept-ranges'] = 'bytes';
  return headers;
}

async function sendMovieMedia(req, res, response, attempt, requestMethod, requestedRange, responseHeaders) {
  if (requestedRange && response.status !== 206 && response.status !== 416) {
    await response.body?.cancel().catch(() => {});
    throw new ConnectorError('The provider does not support the requested movie range.', 416, 'invalid_range');
  }
  let headers = responseHeaders;
  if (!headers) {
    try { headers = mediaHeaders(response); }
    catch (error) { await response.body?.cancel().catch(() => {}); throw error; }
  }
  if (response.status === 416) { res.writeHead(416, headers); res.end(); return; }
  const status = response.status === 206 ? 206 : 200;
  if (requestMethod === 'HEAD') { res.writeHead(status, headers); res.end(); await response.body?.cancel().catch(() => {}); return; }
  const reader = response.body?.getReader();
  if (!reader) throw new ConnectorError('The movie response could not be read.', 502, 'unsupported_response');
  let disconnected = false;
  const cancel = () => { disconnected = true; void reader.cancel().catch(() => {}); };
  const onResponseClose = () => { if (!res.writableEnded) cancel(); };
  req.once?.('aborted', cancel);
  res.once?.('close', onResponseClose);
  res.writeHead(status, headers);
  try {
    while (!disconnected) {
      let result;
      try { result = await readWithIdleTimeout(reader, attempt?.idleTimeoutMs ?? REQUEST_TIMEOUT_MS); }
      catch (error) { throw upstreamReadError(error, attempt); }
      const { done, value } = result;
      if (done || disconnected) break;
      if (!res.write(Buffer.from(value))) {
        const drained = await new Promise((resolve) => {
          let settled = false;
          const cleanup = () => {
            res.removeListener('drain', onDrain);
            res.removeListener('close', onClose);
          };
          const finish = (value) => {
            if (settled) return;
            settled = true;
            cleanup();
            resolve(value);
          };
          const onDrain = () => finish(true);
          const onClose = () => finish(false);
          res.once('drain', onDrain);
          res.once('close', onClose);
          if (res.destroyed || res.writableEnded) finish(false);
        });
        if (!drained) {
          disconnected = true;
          await reader.cancel().catch(() => {});
          break;
        }
      }
    }
    if (!disconnected) res.end();
  } finally {
    req.removeListener?.('aborted', cancel);
    res.removeListener?.('close', onResponseClose);
    await reader.cancel().catch(() => {});
  }
}

// Movie requests resolve an opaque grant through a server-owned callback. The
// browser never supplies an upstream URL, provider ID, or provider credentials.
export async function handleMovieMediaRequest(req, res, { resolveAuthorizedMovie, fetchImpl, dispatcher, boundIpRedirectDispatcherFactory, boundDomainRedirectDispatcherFactory, lookup, allowHttp = true, mediaIpRedirectTrust, providerDomainTrust = playbackProviderDomainTrust(), hostAllowlist = playbackHostAllowlist(), timeoutMs = REQUEST_TIMEOUT_MS } = {}) {
  const requestUrl = new URL(req.url || '/', 'http://localhost');
  const match = requestUrl.pathname.match(/^\/media\/([A-Za-z0-9_-]+)$/);
  if (!match) return false;
  if (!['GET', 'HEAD'].includes(req.method)) throw new ConnectorError('Movie requests must use GET or HEAD.', 405, 'invalid_request');
  if (typeof resolveAuthorizedMovie !== 'function') throw new ConnectorError('Movie playback is unavailable.', 503, 'playback_not_configured');
  const sessionId = readCookie(req.headers.cookie, 'sp_playback_session');
  const media = await resolveAuthorizedMovie(sessionId, match[1]);
  if (!media || typeof media.upstreamUrl !== 'string') throw new ConnectorError('Movie playback authorization expired. Request movie playback again.', 401, 'playback_unauthorized');
  // In local development, bind the one-hop public-IP media redirect exception
  // to this grant's own validated provider origin. This avoids a global
  // PLAYBACK_MEDIA_IP_REDIRECT_TRUST hostname while preserving the existing
  // restrictions: exact allowlisted source, HTTP only, public IP only, same
  // port, GET/HEAD, one redirect, and a pinned socket. Production disables
  // this compatibility path in validatePlaybackDestination.
  let grantMediaSourceHostname;
  try { grantMediaSourceHostname = canonicalHostname(new URL(media.upstreamUrl).hostname); } catch {}
  const grantScopedMediaIpTrust = process.env.NODE_ENV === 'production'
    ? undefined
    : mediaIpRedirectTrust ?? playbackMediaIpRedirectTrust()
      ?? (grantMediaSourceHostname && hostAllowlist.includes(grantMediaSourceHostname) ? grantMediaSourceHostname : undefined);
  const requestedRange = parseSingleRange(req.headers.range);
  // Each movie request gets a short-lived pinned dispatcher. The connector
  // validates DNS answers before this transport dials the selected address, so
  // a later socket connection cannot silently re-resolve a provider hostname.
  const ownsDispatcher = !dispatcher;
  const movieDispatcher = dispatcher ?? createPinnedDispatcher({ lookup, allowHttp, hostAllowlist, connections: 1, pipelining: 0, connectTimeout: timeoutMs, headersTimeout: timeoutMs, bodyTimeout: 0 }).dispatcher;
  let closeDispatcher;
  try {
    const result = await fetchValidated(media.upstreamUrl, {
      fetchImpl, dispatcher: movieDispatcher, boundIpRedirectDispatcherFactory, boundDomainRedirectDispatcherFactory, lookup, allowHttp, hostAllowlist, timeoutMs,
      // Movie and episode streams use the same narrowly scoped redirect
      // validation as Live TV. Do not override the server-only development
      // bindings with null here: fetchValidated must apply its validated
      // PLAYBACK_HTTP_IP_REDIRECT_BINDING / PLAYBACK_HTTP_IP_REDIRECT_TRUST
      // defaults for this media request too. These parsers disable exceptions
      // in production, and the destination is still pinned before connection.
      mediaIpRedirectTrust: grantScopedMediaIpTrust, providerDomainTrust,
      disableMovieIpRedirect: process.env.NODE_ENV === 'production' && mediaIpRedirectTrust !== undefined,
      requestMethod: req.method, acceptedStatuses: [416], requestHeaders: requestedRange ? { Range: requestedRange } : {},
      accept: 'video/mp4, video/*, application/octet-stream', playbackStage: 'media', requestPhase: 'media',
    });
    closeDispatcher = result.closeDispatcher;
    if (requestedRange && result.response.status !== 206 && result.response.status !== 416) {
      await result.response.body?.cancel().catch(() => {});
      throw new ConnectorError('The provider does not support the requested movie range.', 416, 'invalid_range');
    }
    let responseHeaders;
    try { responseHeaders = mediaHeaders(result.response); }
    catch (error) { await result.response.body?.cancel().catch(() => {}); throw error; }
    const refreshed = typeof media.refresh === 'function' ? await media.refresh() : undefined;
    if (typeof refreshed?.sessionCookie === 'string') responseHeaders['set-cookie'] = refreshed.sessionCookie;
    await sendMovieMedia(req, res, result.response, result.attempt, req.method, requestedRange, responseHeaders);
  } finally {
    await closeDispatcher?.();
    if (ownsDispatcher) await movieDispatcher.close().catch(() => {});
  }
  return true;
}

export async function handlePlaybackRequest(req, res, { sessions, fetchImpl, dispatcher, boundIpRedirectDispatcherFactory, boundDomainRedirectDispatcherFactory, lookup, allowHttp = true, httpIpRedirectBinding = playbackHttpIpRedirectBinding(), httpIpRedirectTrust = playbackHttpIpRedirectTrust(), providerDomainTrust = playbackProviderDomainTrust(), hostAllowlist = playbackHostAllowlist(), timeoutMs = REQUEST_TIMEOUT_MS } = {}) {
  const requestUrl = new URL(req.url || '/', 'http://localhost');
  const match = requestUrl.pathname.match(/^\/api\/playback\/([A-Za-z0-9_-]+)\/(manifest\.m3u8|asset\/([A-Za-z0-9_-]+)|diagnostic)$/);
  if (!match) return false;
  if (req.method !== 'GET') throw new ConnectorError('Playback requests must use GET.', 405, 'invalid_request');
  const sessionId = readCookie(req.headers.cookie, 'sp_playback_session');
  const { session, grant, item } = sessions.getGrant(sessionId, match[1]);
  sessions.rateLimit(session);
  const refreshedSession = sessions.touchForPlayback(sessionId, match[1]);
  const playbackCookie = sessionCookie(sessionId, { maxAgeSeconds: refreshedSession.maxAgeSeconds });
  if (match[2] === 'diagnostic') {
    res.writeHead(200, { ...noStoreHeaders(), 'set-cookie': playbackCookie }); res.end(JSON.stringify({ ok: true, ...(grant.lastDiagnostic ?? { category: null }) }));
    return true;
  }
  const phase = match[2] === 'manifest.m3u8' ? 'manifest' : 'asset';
  try {
      const asset = phase === 'manifest' ? { upstreamUrl: item.upstreamUrl, playbackStage: 'initial_live_stream', grant } : sessions.getAsset(sessionId, match[1], match[3]);
    const { upstreamUrl, playbackStage } = asset;
    const range = typeof req.headers.range === 'string' && /^bytes=\d*-\d*$/.test(req.headers.range) ? req.headers.range : undefined;
    const { response, url, closeDispatcher, trustedAssetEndpoint, trustedDomainEndpoint, attempt } = await fetchValidated(upstreamUrl, {
      fetchImpl, dispatcher, boundIpRedirectDispatcherFactory, boundDomainRedirectDispatcherFactory, lookup, allowHttp, httpIpRedirectBinding, httpIpRedirectTrust, providerDomainTrust, trustedAssetEndpoint: asset.grant.trustedAssetEndpoint, trustedDomainEndpoint: asset.grant.trustedDomainEndpoint, hostAllowlist, timeoutMs, playbackStage, requestPhase: phase, accept: 'application/vnd.apple.mpegurl, video/mp2t, video/mp4, application/octet-stream',
      requestHeaders: phase === 'manifest' || !range ? {} : { Range: range },
    });
    try {
      if (phase === 'manifest' || isManifestResponse(response, url)) {
        const manifest = await readLimitedText(response, MAX_MANIFEST_BYTES, attempt);
        if (phase === 'manifest' && trustedAssetEndpoint) grant.trustedAssetEndpoint = trustedAssetEndpoint;
        if (phase === 'manifest' && trustedDomainEndpoint) grant.trustedDomainEndpoint = trustedDomainEndpoint;
        const rewritten = rewriteManifest(manifest, url, (target, stage) => `${match[1]}/asset/${sessions.addAsset(grant, target, stage)}`);
        res.writeHead(200, { ...noStoreHeaders('application/vnd.apple.mpegurl; charset=utf-8'), 'set-cookie': playbackCookie });
        res.end(rewritten);
      } else await sendAsset(res, response, attempt, { 'set-cookie': playbackCookie });
    } finally { await closeDispatcher?.(); }
  } catch (error) {
    const category = playbackFailureCategory(error, { phase });
    sessions.setDiagnostic(grant, category ? {
      category,
      ...(error instanceof ConnectorError && PLAYBACK_STAGES.has(error.diagnostic.playbackStage) ? { stage: error.diagnostic.playbackStage } : {}),
      ...(error instanceof ConnectorError && ['manifest', 'asset'].includes(error.diagnostic.requestPhase) ? { requestPhase: error.diagnostic.requestPhase } : {}),
      ...(error instanceof ConnectorError && Number.isInteger(error.diagnostic.redirectCount) && error.diagnostic.redirectCount >= 0 && error.diagnostic.redirectCount <= MAX_REDIRECTS ? { redirectCount: error.diagnostic.redirectCount } : {}),
      ...(error instanceof ConnectorError && LOCAL_IP_REDIRECT_BINDING_STATUSES.has(error.diagnostic.ipRedirectBindingStatus) ? { ipRedirectBindingStatus: error.diagnostic.ipRedirectBindingStatus } : {}),
      ...(error instanceof ConnectorError && LOCAL_ASSET_IP_MISMATCHES.has(error.diagnostic.assetIpMismatch) ? { assetIpMismatch: error.diagnostic.assetIpMismatch } : {}),
      ...(error instanceof ConnectorError && LOCAL_DOMAIN_TRUST_MISMATCHES.has(error.diagnostic.domainTrustMismatch) ? { domainTrustMismatch: error.diagnostic.domainTrustMismatch } : {}),
      ...(error instanceof ConnectorError && LOCAL_UPSTREAM_CAUSES.has(error.diagnostic.upstreamCause) ? { upstreamStage: error.diagnostic.upstreamStage, upstreamCause: error.diagnostic.upstreamCause } : {}),
      ...(error instanceof ConnectorError && error.diagnostic.upstreamCause === 'upstream_http_status' && Number.isInteger(error.diagnostic.upstreamHttpStatus) && error.diagnostic.upstreamHttpStatus >= 100 && error.diagnostic.upstreamHttpStatus <= 599 ? { upstreamHttpStatus: error.diagnostic.upstreamHttpStatus } : {}),
      ...(error instanceof ConnectorError && error.diagnostic.upstreamCause === 'unknown' && ['source_host', 'pinned_redirect_destination'].includes(error.diagnostic.upstreamRequestTarget) ? {
        upstreamRequestTarget: error.diagnostic.upstreamRequestTarget,
        upstreamErrorName: localDiagnosticToken(error.diagnostic.upstreamErrorName),
        upstreamErrorCode: localDiagnosticToken(error.diagnostic.upstreamErrorCode),
        upstreamErrorCauseCode: localDiagnosticToken(error.diagnostic.upstreamErrorCauseCode),
        upstreamErrorCauseCauseCode: localDiagnosticToken(error.diagnostic.upstreamErrorCauseCauseCode),
      } : {}),
      // Preserve only the development-only, already-public redirect endpoint
      // fields assembled above; never copy a URL or arbitrary diagnostic data.
      ...(error instanceof ConnectorError
        && canonicalIpLiteral(error.diagnostic.redirectDestinationIp)
        && !isForbiddenAddress(error.diagnostic.redirectDestinationIp)
        && Number.isInteger(error.diagnostic.redirectDestinationPort)
        && error.diagnostic.redirectDestinationPort >= 1
        && error.diagnostic.redirectDestinationPort <= 65_535
        ? { redirectDestinationIp: error.diagnostic.redirectDestinationIp, redirectDestinationPort: error.diagnostic.redirectDestinationPort } : {}),
      ...(error instanceof ConnectorError && typeof error.diagnostic.rejectedHostname === 'string' ? { rejectedHostname: error.diagnostic.rejectedHostname } : {}),
      ...(error instanceof ConnectorError && ['http', 'https'].includes(error.diagnostic.rejectedScheme) ? { rejectedScheme: error.diagnostic.rejectedScheme } : {}),
      ...(error instanceof ConnectorError && LOCAL_DESTINATION_REJECTIONS.has(error.diagnostic.destinationRejection) ? { destinationRejection: error.diagnostic.destinationRejection } : {}),
    } : undefined);
    throw error;
  }
  return true;
}
