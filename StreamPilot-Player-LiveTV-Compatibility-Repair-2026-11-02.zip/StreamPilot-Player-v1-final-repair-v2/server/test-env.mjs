// Test processes must not inherit developer shell settings. Several security
// options intentionally default from process.env in production, so tests start
// from a known baseline and opt in explicitly per test.
const TEST_ENV_KEYS = [
  'NODE_ENV',
  'ALLOW_HTTP_PROVIDER',
  'PROVIDER_HOST_ALLOWLIST',
  'PROVIDER_REQUEST_TIMEOUT_MS',
  'PLAYBACK_HOST_ALLOWLIST',
  'PLAYBACK_LOCAL_HOST_DIAGNOSTICS',
  'PLAYBACK_HTTP_IP_REDIRECT_BINDING',
  'PLAYBACK_HTTP_IP_REDIRECT_TRUST',
  'PLAYBACK_PROVIDER_DOMAIN_TRUST',
  'PLAYBACK_MEDIA_IP_REDIRECT_TRUST',
  'FFMPEG_PATH',
  'FFPROBE_PATH',
];

for (const key of TEST_ENV_KEYS) {
  delete process.env[key];
}

export function withTestEnv(overrides, run) {
  const previous = Object.fromEntries(TEST_ENV_KEYS.map((key) => [key, process.env[key]]));
  for (const key of TEST_ENV_KEYS) delete process.env[key];
  Object.assign(process.env, overrides);
  try {
    return run();
  } finally {
    for (const key of TEST_ENV_KEYS) {
      if (previous[key] === undefined) delete process.env[key];
      else process.env[key] = previous[key];
    }
  }
}
