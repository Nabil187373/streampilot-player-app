import './test-env.mjs';
import assert from 'node:assert/strict';
import test from 'node:test';
import { ConnectorError, isForbiddenAddress, createConnector, createXtreamConnector, createRemotePlaylistImporter, createXtreamVodCatalog, getXtreamCatalogDescriptor, getXtreamVodItemExtensions, providerRequestTimeoutMs, redactSecrets } from './connector.mjs';

const publicLookup = async () => [{ address: '93.184.216.34', family: 4 }];
const m3u = '#EXTM3U\n#EXTINF:-1 group-title="News",Example News\nhttps://media.example/live.m3u8';

function jsonResponse(value, options = {}) {
  return new Response(JSON.stringify(value), { headers: { 'content-type': 'application/json', ...options.headers }, status: options.status });
}


test('blocks the well-known NAT64 prefix and preserves the existing NAT64 local-use block', () => {
  for (const address of ['64:ff9b::1', '64:ff9b::c000:201', '64:ff9b:1::1']) {
    assert.equal(isForbiddenAddress(address), true, `${address} must be rejected`);
  }
  assert.equal(isForbiddenAddress('2606:4700:4700::1111'), false);
});

test('imports only Xtream live channels from a validated get.php playlist URL', async () => {
  const serverItems = [];
  const importer = createRemotePlaylistImporter({
    allowHttp: true, hostAllowlist: ['provider.example'], lookup: publicLookup,
    fetchImpl: async (url) => {
      const action = new URL(url).searchParams.get('action');
      if (action === 'get_live_categories') return jsonResponse([{ category_id: '10', category_name: 'News' }]);
      if (action === 'get_live_streams') return jsonResponse([
        { stream_id: 7, name: 'World News', category_id: '10', stream_icon: 'https://images.example/logo.png' },
        { stream_id: 8, name: 'Other', category_id: 'unknown' },
        { stream_id: 9, category_id: '10' },
        { name: 'Missing ID', category_id: '10' },
      ]);
      throw new Error('unexpected Xtream action');
    },
  });
  const result = await importer({ playlistUrl: 'http://provider.example:88/get.php?username=test-user&password=test-password&type=m3u_plus' }, { onItem: (item) => serverItems.push(item) });
  assert.deepEqual(result.items, [
    { id: 'provider-0', name: 'World News', group: 'News', logo: 'https://images.example/logo.png', kind: 'live', playbackBlocked: true },
    { id: 'provider-1', name: 'Other', group: 'Uncategorized', kind: 'live', playbackBlocked: true },
  ]);
  assert.equal(serverItems.length, 2);
  assert.equal(JSON.stringify(result).includes('test-user'), false);
  assert.equal(JSON.stringify(result).includes('test-password'), false);
});


test('Xtream Codes connector uses player_api.php actions and returns a server-held VOD/series descriptor', async () => {
  const requested = [];
  const importedItems = [];
  const connector = createXtreamConnector({
    allowHttp: true, hostAllowlist: ['provider.example'], lookup: publicLookup,
    fetchImpl: async (url) => {
      const parsed = new URL(url);
      requested.push({ pathname: parsed.pathname, action: parsed.searchParams.get('action'), username: parsed.searchParams.get('username'), password: parsed.searchParams.get('password') });
      if (parsed.searchParams.get('action') === 'get_live_categories') return jsonResponse([{ category_id: '10', category_name: 'News' }]);
      if (parsed.searchParams.get('action') === 'get_live_streams') return jsonResponse([{ stream_id: 7, name: 'World News', category_id: '10' }]);
      throw new Error('unexpected Xtream action');
    },
  });
  const result = await connector({ serverUrl: 'http://provider.example:2086', username: 'test-user', password: 'test-password' }, { onItem: (item) => importedItems.push(item) });
  assert.deepEqual(result.items, [{ id: 'provider-0', name: 'World News', group: 'News', kind: 'live', playbackBlocked: true }]);
  assert.equal(importedItems.length, 1);
  assert.ok(getXtreamCatalogDescriptor(result));
  assert.equal(requested.length, 2);
  assert.ok(requested.every((entry) => entry.pathname === '/player_api.php'));
  assert.deepEqual(requested.map((entry) => entry.action), ['get_live_categories', 'get_live_streams']);
  assert.ok(requested.every((entry) => entry.username === 'test-user' && entry.password === 'test-password'));
  assert.equal(JSON.stringify(result).includes('test-password'), false);
});

test('loads only a bounded Xtream VOD category page without exposing provider credentials', async () => {
  const importer = createRemotePlaylistImporter({
    allowHttp: true, hostAllowlist: ['provider.example'], lookup: publicLookup,
    fetchImpl: async (url) => {
      const action = new URL(url).searchParams.get('action');
      if (action === 'get_live_categories') return jsonResponse([{ category_id: '1', category_name: 'News' }]);
      if (action === 'get_live_streams') return jsonResponse([{ stream_id: 1, name: 'News' }]);
      throw new Error('unexpected import action');
    },
  });
  const imported = await importer({ playlistUrl: 'http://provider.example/get.php?username=test-user&password=test-password' });
  const descriptor = getXtreamCatalogDescriptor(imported);
  assert.ok(descriptor);
  const requestedActions = [];
  const catalog = createXtreamVodCatalog({
    allowHttp: true, hostAllowlist: ['provider.example'], lookup: publicLookup,
    fetchImpl: async (url) => {
      const parsed = new URL(url); const action = parsed.searchParams.get('action'); requestedActions.push(action);
      if (action === 'get_vod_categories') return jsonResponse([{ category_id: 'movies', category_name: 'Movies' }]);
      if (action === 'get_vod_streams') return jsonResponse([
        { stream_id: 1, name: 'First', stream_icon: 'https://images.example/first.png', year: 2024, rating: '7.1', container_extension: 'mkv' },
        { stream_id: 2, name: 'Second', container_extension: 'php' },
        { stream_id: 3, name: 'Private icon', stream_icon: 'https://images.example/icon.png?token=private' },
        { name: 'Missing id' },
      ]);
      throw new Error('unexpected VOD action');
    },
  });
  assert.deepEqual(await catalog.categories(descriptor), [{ id: 'movies', name: 'Movies' }]);
  const firstPage = await catalog.items(descriptor, { categoryId: 'movies', offset: 0, limit: 1 });
  assert.deepEqual(firstPage.items, [{ id: '1', name: 'First', icon: 'https://images.example/first.png', year: '2024', rating: '7.1' }]);
  assert.equal(getXtreamVodItemExtensions(firstPage).get('1'), 'mkv');
  const page = await catalog.items(descriptor, { categoryId: 'movies', offset: 1, limit: 500 });
  assert.deepEqual(page, {
    items: [{ id: '2', name: 'Second' }, { id: '3', name: 'Private icon' }], offset: 1, limit: 500, hasMore: false,
  });
  assert.equal(getXtreamVodItemExtensions(page).get('2'), 'php');
  assert.match(new URL(catalog.movieUrl(descriptor, '1', 'mkv')).pathname, /\.mkv$/);
  for (const extension of ['php', 'html', '../', undefined]) {
    assert.match(new URL(catalog.movieUrl(descriptor, '1', extension)).pathname, /\.mp4$/);
  }
  assert.deepEqual(requestedActions, ['get_vod_categories', 'get_vod_streams', 'get_vod_streams']);
  assert.equal(JSON.stringify(await catalog.categories(descriptor)).includes('test-password'), false);
  assert.equal(JSON.stringify(page).includes('private'), false);
});

test('rejects unsafe or oversized Xtream VOD catalogue responses before returning items', async () => {
  const descriptor = { origin: 'http://provider.example', username: 'test-user', password: 'test-password' };
  for (const response of [
    new Response('not json', { headers: { 'content-type': 'text/plain' } }),
    jsonResponse({ invalid: true }),
    new Response('[]', { headers: { 'content-type': 'application/json', 'content-length': String(10 * 1024 * 1024 + 1) } }),
  ]) {
    const catalog = createXtreamVodCatalog({ allowHttp: true, hostAllowlist: ['provider.example'], lookup: publicLookup, fetchImpl: async () => response });
    await assert.rejects(() => catalog.categories(descriptor), (error) => error instanceof ConnectorError && ['unsupported_response', 'playlist_too_large'].includes(error.code));
  }
  const catalog = createXtreamVodCatalog({ allowHttp: true, hostAllowlist: ['provider.example'], lookup: publicLookup, fetchImpl: async () => jsonResponse(Array.from({ length: 501 }, (_, index) => ({ stream_id: index, name: `Movie ${index}` }))) });
  await assert.rejects(() => catalog.items(descriptor, { categoryId: 'movies', offset: 0, limit: 501 }), (error) => error instanceof ConnectorError && error.code === 'invalid_request');
  const anyPublicHost = createXtreamVodCatalog({ allowHttp: true, hostAllowlist: ['other.example'], lookup: publicLookup, fetchImpl: async () => jsonResponse([]) });
  await assert.rejects(() => anyPublicHost.categories(descriptor), (error) => error instanceof ConnectorError && error.code === 'playlist_invalid');
});

test('rejects invalid, non-array, oversized, and over-limit Xtream live responses safely', async () => {
  const base = { allowHttp: true, hostAllowlist: ['provider.example'], lookup: publicLookup };
  const url = 'http://provider.example/get.php?username=test-user&password=test-password';
  for (const response of [
    new Response('not json', { headers: { 'content-type': 'text/plain' } }),
    jsonResponse({ category_id: '1' }),
  ]) {
    const importer = createRemotePlaylistImporter({ ...base, fetchImpl: async () => response });
    await assert.rejects(() => importer({ playlistUrl: url }), (error) => error instanceof ConnectorError && error.code === 'unsupported_response');
  }
  const rejected = createRemotePlaylistImporter({ ...base, fetchImpl: async () => new Response('', { status: 500 }) });
  await assert.rejects(() => rejected({ playlistUrl: url }), (error) => error instanceof ConnectorError && error.code === 'provider_http_error');
  const oversized = createRemotePlaylistImporter({ ...base, fetchImpl: async () => new Response('[]', { headers: { 'content-type': 'application/json', 'content-length': String(10 * 1024 * 1024 + 1) } }) });
  await assert.rejects(() => oversized({ playlistUrl: url }), (error) => error instanceof ConnectorError && error.code === 'playlist_too_large');

  let calls = 0;
  const tooMany = createRemotePlaylistImporter({ ...base, fetchImpl: async () => {
    calls += 1;
    return calls === 1 ? jsonResponse([]) : jsonResponse(Array.from({ length: 20_001 }, (_, index) => ({ stream_id: index + 1, name: `Live ${index + 1}` })));
  } });
  await assert.rejects(() => tooMany({ playlistUrl: url }), (error) => error instanceof ConnectorError && error.code === 'playlist_too_large');
});

test('keeps Xtream credentials out of safe errors and rejects HTTP-disabled requests before fetching', async () => {
  const playlistUrl = 'http://provider.example/get.php?username=test-user&password=test-password';
  for (const options of [
    { allowHttp: false, hostAllowlist: ['provider.example'] },
  ]) {
    const importer = createRemotePlaylistImporter({ ...options, lookup: publicLookup, fetchImpl: async () => { throw new Error('must not fetch'); } });
    await assert.rejects(() => importer({ playlistUrl }), (error) => {
      assert.equal(error instanceof ConnectorError, true);
      assert.equal(error.message.includes('test-user'), false);
      assert.equal(error.message.includes('test-password'), false);
      return error.code === 'http_not_allowed' || error.code === 'destination_not_allowed';
    });
  }
});

test('imports a remote playlist through the same bounded metadata path without returning source URLs', async () => {
  const importer = createRemotePlaylistImporter({ lookup: publicLookup, fetchImpl: async () => new Response(`${m3u}?token=secret`) });
  const result = await importer({ playlistUrl: 'https://provider.example/playlist.m3u8?token=source-secret' });
  assert.deepEqual(result.items, [{ id: 'provider-0', name: 'Example News', group: 'News', kind: 'live', playbackBlocked: true }]);
  assert.equal(JSON.stringify(result).includes('secret'), false);
  assert.equal(JSON.stringify(result).includes('media.example'), false);
});

test('accepts new public provider and CDN hostnames without deployment allowlist entries', async () => {
  const requestedHosts = [];
  const resolvedHosts = [];
  const importer = createRemotePlaylistImporter({
    lookup: async (hostname) => { resolvedHosts.push(hostname); return publicLookup(); },
    fetchImpl: async (url) => {
      requestedHosts.push(new URL(url).hostname);
      if (new URL(url).hostname === 'new-provider.example') {
        return new Response('', { status: 302, headers: { location: 'https://dynamic-cdn.example/playlist.m3u' } });
      }
      return new Response(m3u);
    },
  });
  const result = await importer({ playlistUrl: 'https://new-provider.example/list.m3u' });
  assert.equal(result.items.length, 1);
  assert.deepEqual(requestedHosts, ['new-provider.example', 'dynamic-cdn.example']);
  assert.ok(resolvedHosts.includes('new-provider.example'));
  assert.ok(resolvedHosts.includes('dynamic-cdn.example'));
});

test('legacy deployment host allowlists do not block customer-authorized public playlist and CDN hosts', async () => {
  const requestedHosts = [];
  const importer = createRemotePlaylistImporter({
    hostAllowlist: ['operator-only.example'],
    lookup: publicLookup,
    fetchImpl: async (url) => {
      requestedHosts.push(new URL(url).hostname);
      if (new URL(url).hostname === 'customer-provider.example') {
        return new Response('', { status: 302, headers: { location: 'https://customer-cdn.example/playlist.m3u' } });
      }
      return new Response(m3u);
    },
  });
  const result = await importer({ playlistUrl: 'https://customer-provider.example/list.m3u' });
  assert.equal(result.items.length, 1);
  assert.deepEqual(requestedHosts, ['customer-provider.example', 'customer-cdn.example']);
});

test('imports an explicitly approved HTTP playlist only when HTTP compatibility is enabled', async () => {
  let fetches = 0;
  const approved = createRemotePlaylistImporter({
    allowHttp: true,
    hostAllowlist: ['playlist.example'],
    lookup: publicLookup,
    fetchImpl: async () => { fetches += 1; return new Response(m3u); },
  });
  const result = await approved({ playlistUrl: 'http://playlist.example/list.m3u8' });
  assert.equal(result.items.length, 1);
  assert.equal(fetches, 1);

  const disabled = createRemotePlaylistImporter({
    allowHttp: false,
    hostAllowlist: ['playlist.example'],
    lookup: publicLookup,
    fetchImpl: async () => { throw new Error('HTTP-disabled imports must not fetch'); },
  });
  await assert.rejects(() => disabled({ playlistUrl: 'http://playlist.example/list.m3u8' }), (error) => error instanceof ConnectorError && error.code === 'http_not_allowed');
});

test('rejects an HTTP playlist redirect to an IP literal before fetching it', async () => {
  let fetches = 0;
  const importer = createRemotePlaylistImporter({
    allowHttp: true,
    hostAllowlist: ['playlist.example'],
    lookup: publicLookup,
    fetchImpl: async () => {
      fetches += 1;
      return new Response('', { status: 302, headers: { location: 'http://203.0.113.42/list.m3u8?token=secret' } });
    },
  });
  await assert.rejects(() => importer({ playlistUrl: 'http://playlist.example/list.m3u8' }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
  assert.equal(fetches, 1);
});

test('applies URL scheme, DNS, redirect, timeout, size, entry, and malformed-playlist protections to remote imports', async () => {
  const strict = createRemotePlaylistImporter({ lookup: publicLookup, fetchImpl: async () => new Response(m3u) });
  const httpResult = await strict({ playlistUrl: 'http://provider.example/list.m3u' });
  assert.equal(httpResult.items.length, 1);
  await assert.rejects(() => strict({ playlistUrl: 'https://203.0.113.42/list.m3u' }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
  const arbitraryPublicHost = createRemotePlaylistImporter({ lookup: publicLookup, hostAllowlist: ['allowed.example'], fetchImpl: async () => new Response(m3u) });
  assert.equal((await arbitraryPublicHost({ playlistUrl: 'https://provider.example/list.m3u' })).items.length, 1);
  const privateDns = createRemotePlaylistImporter({ lookup: async () => [{ address: '127.0.0.1', family: 4 }], fetchImpl: async () => new Response(m3u) });
  await assert.rejects(() => privateDns({ playlistUrl: 'https://provider.example/list.m3u' }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');

  const validatedHosts = [];
  let redirects = 0;
  const redirecting = createRemotePlaylistImporter({
    lookup: async (hostname) => { validatedHosts.push(hostname); return publicLookup(); },
    fetchImpl: async () => redirects++ === 0 ? new Response('', { status: 302, headers: { location: 'https://redirect.example/list.m3u' } }) : new Response(m3u),
  });
  await redirecting({ playlistUrl: 'https://provider.example/list.m3u' });
  assert.equal(validatedHosts.includes('redirect.example'), true);

  let blockedRedirectFetches = 0;
  const blockedRedirect = createRemotePlaylistImporter({
    lookup: publicLookup,
    hostAllowlist: ['provider.example'],
    fetchImpl: async () => { blockedRedirectFetches += 1; return new Response('', { status: 302, headers: { location: 'https://redirect.example/list.m3u' } }); },
  });
  await assert.rejects(() => blockedRedirect({ playlistUrl: 'https://provider.example/list.m3u' }), (error) => error instanceof ConnectorError && error.code === 'unsupported_response');
  assert.ok(blockedRedirectFetches >= 2);

  const tooManyRedirects = createRemotePlaylistImporter({ lookup: publicLookup, fetchImpl: async () => new Response('', { status: 302, headers: { location: 'https://provider.example/again.m3u' } }) });
  await assert.rejects(() => tooManyRedirects({ playlistUrl: 'https://provider.example/list.m3u' }), (error) => error instanceof ConnectorError && error.code === 'unsupported_response');

  const timeout = createRemotePlaylistImporter({ lookup: publicLookup, fetchImpl: async () => { const error = new Error('timeout'); error.name = 'TimeoutError'; throw error; } });
  await assert.rejects(() => timeout({ playlistUrl: 'https://provider.example/list.m3u' }), (error) => error instanceof ConnectorError && error.code === 'provider_timeout');
  const oversized = createRemotePlaylistImporter({ lookup: publicLookup, maxBytes: 8, fetchImpl: async () => new Response(m3u, { headers: { 'content-length': '999' } }) });
  await assert.rejects(() => oversized({ playlistUrl: 'https://provider.example/list.m3u' }), (error) => error instanceof ConnectorError && error.code === 'playlist_too_large');
  const capped = createRemotePlaylistImporter({ lookup: publicLookup, maxEntries: 1, fetchImpl: async () => new Response(`${m3u}\n#EXTINF:-1,Another\nhttps://media.example/two.m3u8`) });
  const cappedResult = await capped({ playlistUrl: 'https://provider.example/list.m3u' });
  assert.equal(cappedResult.items.length, 1);
  assert.equal(cappedResult.entryLimitReached, true);
  const malformed = createRemotePlaylistImporter({ lookup: publicLookup, fetchImpl: async () => new Response('#EXTM3U\n#EXTINF:-1,Missing\nnot-a-url') });
  await assert.rejects(() => malformed({ playlistUrl: 'https://provider.example/list.m3u' }), (error) => error instanceof ConnectorError && error.code === 'playlist_invalid');
});

test('imports validated M3U metadata for common and generic provider content types without returning stream URLs', async () => {
  for (const contentType of ['application/vnd.apple.mpegurl', 'application/x-mpegURL; charset=utf-8', 'text/plain', 'application/octet-stream', '']) {
    const connector = createConnector({ lookup: publicLookup, fetchImpl: async () => new Response(m3u, { headers: contentType ? { 'content-type': contentType } : {} }) });
    const result = await connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' });
    assert.equal(result.items.length, 1, contentType || 'missing content type');
    assert.deepEqual(result.items[0], { id: 'provider-0', name: 'Example News', group: 'News', kind: 'live', playbackBlocked: true });
    assert.match(result.playbackNotice, /session-bound playback/i);
  }
});

test('preserves comma titles, aliases, safe EXTINF metadata, EXTGRP, VLCOPT and KODIPROP in remote playlists', async () => {
  const source = `#EXTM3U
#EXTGRP:Documentaries
#EXTINF:-1 tvg_id='doc.1' tvg_logo='https://images.example/doc.png' custom-attr='custom' password='must-not-leak',Wildlife, Planet Earth
#EXTVLCOPT:http-user-agent=ExamplePlayer/1.0
#KODIPROP:inputstream.adaptive.manifest_type=hls
https://media.example/doc.m3u8`;
  const importer = createRemotePlaylistImporter({
    allowHttp: true, hostAllowlist: ['provider.example'], lookup: publicLookup,
    fetchImpl: async () => new Response(source, { headers: { 'content-type': 'audio/x-mpegurl' } }),
  });
  const result = await importer({ playlistUrl: 'http://provider.example/list.m3u' });
  assert.deepEqual(result.items, [{
    id: 'provider-0', name: 'Wildlife, Planet Earth', group: 'Documentaries',
    logo: 'https://images.example/doc.png', tvgId: 'doc.1',
    metadata: {
      'extinf.custom-attr': 'custom',
      'vlc.http-user-agent': 'ExamplePlayer/1.0',
      'kodi.inputstream.adaptive.manifest_type': 'hls',
    },
    kind: 'live', playbackBlocked: true,
  }]);
  assert.equal(JSON.stringify(result).includes('must-not-leak'), false);
});

test('fails safely when a provider returns an error', async () => {
  const connector = createConnector({ lookup: publicLookup, fetchImpl: async () => new Response('', { status: 401 }) });
  await assert.rejects(() => connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error instanceof ConnectorError && error.status === 502 && error.code === 'provider_http_error' && error.diagnostic.providerStatus === 401 && !error.message.includes('secret'));
});

test('classifies HTML and JSON provider responses without returning their bodies', async () => {
  const htmlConnector = createConnector({ lookup: publicLookup, fetchImpl: async () => new Response('<html>provider error</html>', { headers: { 'content-type': 'text/html' } }) });
  await assert.rejects(() => htmlConnector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error.code === 'provider_response_html' && error.diagnostic.responseCategory === 'html' && !error.message.includes('provider error'));
  const jsonConnector = createConnector({ lookup: publicLookup, fetchImpl: async () => new Response('{"error":"provider details"}', { headers: { 'content-type': 'application/json' } }) });
  await assert.rejects(() => jsonConnector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error.code === 'provider_response_json' && error.diagnostic.responseCategory === 'json' && !error.message.includes('provider details'));
});

test('rejects non-M3U content even when it has a playlist-like content type', async () => {
  const connector = createConnector({ lookup: publicLookup, fetchImpl: async () => new Response('<html>provider error</html>', { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }) });
  await assert.rejects(() => connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error.code === 'provider_response_html' && error.diagnostic.responseCategory === 'html');
});

test('rejects private and loopback destinations before fetch', async () => {
  let called = false;
  const connector = createConnector({ hostAllowlist: ['internal.example'], lookup: async () => [{ address: '127.0.0.1', family: 4 }], fetchImpl: async () => { called = true; return new Response(); } });
  await assert.rejects(() => connector({ serverUrl: 'https://internal.example', username: 'user', password: 'secret' }), /not permitted/);
  assert.equal(called, false);
});

test('accepts globally routable provider IP literals and rejects private IP literals before fetch', async () => {
  let called = 0;
  const publicIpConnector = createConnector({ fetchImpl: async () => { called += 1; return new Response(m3u); } });
  const result = await publicIpConnector({ serverUrl: 'https://93.184.216.34/list.m3u', username: 'user', password: 'secret' });
  assert.equal(result.items.length, 1);
  const privateIpConnector = createConnector({ fetchImpl: async () => { called += 1; return new Response(m3u); } });
  await assert.rejects(() => privateIpConnector({ serverUrl: 'http://192.168.1.10/list.m3u', username: 'user', password: 'secret' }), (error) => error.code === 'destination_not_allowed' && error.localDiagnostic.destinationRejection === 'resolved_address_not_allowed');
  const dnsConnector = createConnector({ lookup: async () => { throw new Error('resolver internals'); }, fetchImpl: async () => { called += 1; return new Response(); } });
  await assert.rejects(() => dnsConnector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error.code === 'destination_not_allowed' && error.localDiagnostic.destinationRejection === 'dns_resolution_failed' && !error.message.includes('resolver internals'));
  assert.equal(called, 1);
});

test('revalidates redirect destinations before following them', async () => {
  let calls = 0;
  const connector = createConnector({
    hostAllowlist: ['provider.example', 'internal.example'],
    lookup: async (host) => [{ address: host === 'internal.example' ? '10.0.0.8' : '93.184.216.34', family: 4 }],
    fetchImpl: async () => { calls += 1; return new Response('', { status: 302, headers: { location: 'https://internal.example/playlist.m3u' } }); },
  });
  await assert.rejects(() => connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), /not permitted/);
  assert.equal(calls, 1);
});

test('accepts HTTP and HTTPS providers automatically while preserving explicit policy overrides', async () => {
  const fetchImpl = async () => new Response(m3u, { headers: { 'content-type': 'application/x-mpegurl' } });
  const automaticConnector = createConnector({ hostAllowlist: ['provider.example'], lookup: publicLookup, fetchImpl });
  await assert.doesNotReject(() => automaticConnector({ serverUrl: 'http://provider.example', username: 'user', password: 'secret' }));
  await assert.doesNotReject(() => automaticConnector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }));
  const explicitlyDisabled = createConnector({ allowHttp: false, hostAllowlist: ['provider.example'], lookup: publicLookup, fetchImpl });
  await assert.rejects(() => explicitlyDisabled({ serverUrl: 'http://provider.example', username: 'user', password: 'secret' }), (error) => error.code === 'http_not_allowed');
});

test('reports timeouts without leaking credentials', async () => {
  const connector = createConnector({ lookup: publicLookup, fetchImpl: async () => { const error = new Error('network'); error.name = 'TimeoutError'; throw error; } });
  await assert.rejects(() => connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error.status === 504 && !error.message.includes('secret'));
});

test('bounds configurable request timeouts and identifies a network timeout', async () => {
  assert.equal(providerRequestTimeoutMs(), 20_000);
  assert.equal(providerRequestTimeoutMs('5000'), 5_000);
  assert.equal(providerRequestTimeoutMs('60000'), 60_000);
  assert.equal(providerRequestTimeoutMs('1'), 20_000);
  assert.equal(providerRequestTimeoutMs('unbounded'), 20_000);
  let aborted = false;
  const connector = createConnector({
    lookup: publicLookup,
    timeoutMs: 5,
    fetchImpl: async (_url, { signal }) => new Promise((_resolve, reject) => signal.addEventListener('abort', () => {
      aborted = true;
      const error = new Error('network timeout'); error.name = 'TimeoutError'; reject(error);
    }, { once: true })),
  });
  await assert.rejects(() => connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error.code === 'provider_timeout' && error.diagnostic.importStage === 'network');
  assert.equal(aborted, true);
});

test('classifies a slow or aborted playlist body separately from the network request', async () => {
  const body = new ReadableStream({
    start(controller) {
      const error = new Error('body timeout'); error.name = 'AbortError'; controller.error(error);
    },
  });
  const connector = createConnector({ lookup: publicLookup, fetchImpl: async () => new Response(body) });
  await assert.rejects(() => connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error.code === 'provider_timeout' && error.diagnostic.importStage === 'playlist_stream' && !error.message.includes('body timeout'));
});

test('rejects malformed playlists with no playable entries', async () => {
  const connector = createConnector({ lookup: publicLookup, fetchImpl: async () => new Response('#EXTM3U\n#EXTINF:-1,Missing URL\nnot-a-url\n') });
  await assert.rejects(() => connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error.code === 'playlist_invalid');
});

test('preserves an explicitly supplied HTTPS port and distinguishes a connection failure from an HTTP provider error', async () => {
  let requestedUrl;
  const connector = createConnector({
    lookup: publicLookup,
    fetchImpl: async (url) => { requestedUrl = url; throw new TypeError('network connection failed'); },
  });
  await assert.rejects(() => connector({ serverUrl: 'https://provider.example:8443', username: 'user', password: 'secret' }), (error) => error.code === 'provider_unreachable' && error.status === 502 && !error.message.includes('secret'));
  assert.equal(requestedUrl.protocol, 'https:');
  assert.equal(requestedUrl.port, '8443');
  assert.equal(requestedUrl.pathname, '/get.php');
});

test('rejects oversized playlist responses', async () => {
  const connector = createConnector({ lookup: publicLookup, maxBytes: 8, fetchImpl: async () => new Response(m3u, { headers: { 'content-type': 'text/plain', 'content-length': '999' } }) });
  await assert.rejects(() => connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error.status === 413);
});

test('preserves the explicit size error when an unannounced streaming response crosses the limit', async () => {
  const body = new ReadableStream({
    start(controller) {
      controller.enqueue(new TextEncoder().encode('#EXTM3U\n#EXTINF:-1,Channel\nhttps://media.example/live.m3u8\n'));
      controller.close();
    },
  });
  const connector = createConnector({ lookup: publicLookup, maxBytes: 16, fetchImpl: async () => new Response(body) });
  await assert.rejects(() => connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' }), (error) => error.code === 'playlist_too_large' && error.status === 413);
});

test('streams a playlist larger than the former 3 MiB buffer and stops at the entry cap', async () => {
  const padding = 'x'.repeat(700);
  const rows = ['#EXTM3U\n'];
  for (let index = 0; index < 20_001; index += 1) rows.push(`#EXTINF:-1 group-title="News",Channel ${index}\nhttps://media.example/${index}/${padding}.m3u8\n`);
  const chunks = [];
  for (let index = 0; index < rows.length; index += 100) chunks.push(rows.slice(index, index + 100).join(''));
  let chunkIndex = 0;
  const body = new ReadableStream({
    pull(controller) {
      if (chunkIndex === chunks.length) controller.close();
      else controller.enqueue(new TextEncoder().encode(chunks[chunkIndex++]));
    },
  });
  const connector = createConnector({
    lookup: publicLookup,
    maxBytes: 40 * 1024 * 1024,
    fetchImpl: async () => new Response(body, { headers: { 'content-type': 'text/plain' } }),
  });
  const result = await connector({ serverUrl: 'https://provider.example', username: 'user', password: 'secret' });
  assert.equal(result.items.length, 20_000);
  assert.equal(result.entryLimitReached, true);
  assert.match(result.playbackNotice, /20000-entry import cap was reached/i);
  assert.equal(JSON.stringify(result.items).includes(padding), false);
});

test('redacts URL-style and query-string credentials', () => {
  const redacted = redactSecrets('https://alice:secret@example.test/get.php?username=alice&password=secret&token=abc');
  assert.equal(redacted.includes('secret'), false);
  assert.equal(redacted.includes('abc'), false);
});

test('classifies common M3U season and episode labels as series entries', async () => {
  const source = `#EXTM3U\n#EXTINF:-1 group-title="Entertainment",Example Show S01E02 - The Arrival\nhttps://media.example/episode-102.mp4\n#EXTINF:-1 group-title="TV",Another Show 2x03\nhttps://media.example/episode-203.mp4`;
  const importer = createRemotePlaylistImporter({
    allowHttp: true, hostAllowlist: ['provider.example'], lookup: publicLookup,
    fetchImpl: async () => new Response(source, { headers: { 'content-type': 'audio/x-mpegurl' } }),
  });
  const result = await importer({ playlistUrl: 'http://provider.example/series.m3u' });
  assert.deepEqual(result.items.map((item) => item.kind), ['series', 'series']);
});
