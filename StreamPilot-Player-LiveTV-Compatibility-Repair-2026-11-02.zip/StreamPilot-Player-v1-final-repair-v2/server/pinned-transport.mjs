import net from 'node:net';
import tls from 'node:tls';
import { Agent } from 'undici';
import { ConnectorError, isForbiddenAddress, resolveDestination } from './connector.mjs';

const TRANSPORT_ERROR_CODES = new Set(['ENOTFOUND', 'EAI_AGAIN', 'ECONNREFUSED', 'ETIMEDOUT', 'ECONNRESET', 'UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT', 'UND_ERR_SOCKET', 'ERR_TLS_CERT_ALTNAME_INVALID', 'DEPTH_ZERO_SELF_SIGNED_CERT', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE', 'CERT_HAS_EXPIRED']);
const LOCAL_DIAGNOSTIC_TOKEN = /^[A-Za-z0-9_.-]{1,40}$/;

function localDiagnosticToken(value) {
  return typeof value === 'string' && LOCAL_DIAGNOSTIC_TOKEN.test(value) ? value : 'other';
}

function transportCode(error) {
  const code = typeof error?.code === 'string' ? error.code : undefined;
  return code && TRANSPORT_ERROR_CODES.has(code) ? code : undefined;
}

function connectionError(message = 'The provider connection could not be established safely.', cause) {
  const error = new ConnectorError(message, 502, 'provider_unreachable');
  const code = transportCode(cause);
  if (code) error.transportCode = code;
  // These fixed-format fields are only consumed by playback's development
  // diagnostic path. They do not participate in public error classification.
  error.localDiagnosticName = localDiagnosticToken(cause?.name);
  error.localDiagnosticCode = localDiagnosticToken(cause?.code);
  error.localDiagnosticCauseCode = localDiagnosticToken(cause?.cause?.code);
  error.localDiagnosticCauseCauseCode = localDiagnosticToken(cause?.cause?.cause?.code);
  return error;
}

function destinationError() {
  return new ConnectorError('The provider destination is not permitted.', 403, 'destination_not_allowed');
}

function canonicalIp(value) {
  const hostname = typeof value === 'string' ? value.replace(/^\[|\]$/g, '').toLowerCase() : '';
  return net.isIP(hostname) ? hostname : undefined;
}

function originUrl({ protocol, hostname, port }, ipLiteralAllowlist) {
  const literal = canonicalIp(hostname);
  if (!['http:', 'https:'].includes(protocol) || !hostname || (literal && !ipLiteralAllowlist.has(literal))) {
    throw connectionError();
  }
  const authority = literal?.includes(':') ? `[${literal}]` : hostname;
  return new URL(`${protocol}//${authority}${port ? `:${port}` : ''}/`);
}

function selectPinnedAddress(records) {
  const selected = records[0];
  const family = selected?.family === 4 || selected?.family === 6 ? selected.family : net.isIP(selected?.address);
  if (!selected || !selected.address || !family) throw connectionError();
  return { address: selected.address, family };
}

// Creates an Undici-compatible connector. It resolves each new TCP/TLS
// connection through the injected resolver, validates every answer, and then
// dials the selected literal IP. It intentionally does not use DNS in
// net.connect/tls.connect, which closes the validation-to-connect rebinding
// gap for newly created sockets. Existing pooled sockets were already pinned
// when created; callers should still validate every request/redirect.
export function createPinnedTransport({ lookup, allowHttp = true, hostAllowlist = [], ipLiteralAllowlist = [], tcpConnect = net.connect, tlsConnect = tls.connect, selectAddress = selectPinnedAddress } = {}) {
  const allowedIpLiterals = new Set(ipLiteralAllowlist.map(canonicalIp).filter(Boolean));
  const connect = (options, callback) => {
    let settled = false;
    const done = (error, socket = null) => {
      if (settled) return;
      settled = true;
      callback(error, socket);
    };
    Promise.resolve().then(async () => {
      const url = originUrl(options, allowedIpLiterals);
      if (options.servername && options.servername.toLowerCase() !== url.hostname.toLowerCase()) throw connectionError();
      const literal = canonicalIp(url.hostname);
      if (url.protocol === 'http:' && !allowHttp) throw new ConnectorError('This connector requires HTTPS because an HTTP-only provider cannot protect credentials in transit. Ask the provider for HTTPS support.', 400, 'http_not_allowed');
      if (literal && isForbiddenAddress(literal)) throw destinationError();
      const records = literal
        ? [{ address: literal, family: net.isIP(literal) }]
        : (await resolveDestination(url.toString(), { lookup, allowHttp, hostAllowlist })).records;
      const { address, family } = selectAddress(records);
      const port = Number(options.port) || (url.protocol === 'https:' ? 443 : 80);
      const socketOptions = { host: address, port, family, localAddress: options.localAddress };
      // Supplying the hostname here retains SNI and Node's default hostname
      // certificate verification while the TCP connection remains pinned to IP.
      const socket = url.protocol === 'https:'
        ? tlsConnect({ ...socketOptions, servername: url.hostname, rejectUnauthorized: true, ALPNProtocols: ['http/1.1'] })
        : tcpConnect(socketOptions);
      socket.setNoDelay?.(true);
      socket.setKeepAlive?.(true, 60_000);
      const readyEvent = url.protocol === 'https:' ? 'secureConnect' : 'connect';
      socket.once(readyEvent, () => done(null, socket));
      socket.once('error', (error) => done(connectionError(undefined, error)));
    }).catch((error) => done(error instanceof ConnectorError ? error : connectionError(undefined, error)));
  };
  return { connect };
}

// Convenience construction for explicitly approved playback integrations.
// Callers must still validate every URL and redirect before selecting a dispatcher.
export function createPinnedDispatcher(options = {}) {
  const { transport = createPinnedTransport(options), ...agentOptions } = options;
  return { transport, dispatcher: new Agent({ ...agentOptions, connect: transport.connect }) };
}
