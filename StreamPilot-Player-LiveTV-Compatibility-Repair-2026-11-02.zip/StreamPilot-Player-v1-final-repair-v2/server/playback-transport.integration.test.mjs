import './test-env.mjs';
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { once } from 'node:events';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import http from 'node:http';
import https from 'node:https';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import tls from 'node:tls';
import { promisify } from 'node:util';
import { fetch as undiciFetch } from 'undici';
import { ConnectorError } from './connector.mjs';
import { createPinnedDispatcher } from './pinned-transport.mjs';
import { PlaybackSessions, handlePlaybackRequest } from './playback.mjs';

const publicAnswer = [{ address: '93.184.216.34', family: 4 }];
const execFileAsync = promisify(execFile);

function response() {
  return {
    status: 0, headers: {}, body: '',
    writeHead(status, headers) { this.status = status; this.headers = headers; return this; },
    write(chunk) { this.body += Buffer.from(chunk).toString('utf8'); return true; },
    end(chunk = '') { this.body += Buffer.from(chunk).toString('utf8'); },
    once() {}, destroy() { this.destroyed = true; },
  };
}

function request(path, sessionId) { return { method: 'GET', url: path, headers: { cookie: `sp_playback_session=${sessionId}` } }; }

async function fixture(handler) {
  const server = http.createServer(handler);
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const { port } = server.address();
  return {
    port,
    async close() { server.close(); await once(server, 'close'); },
  };
}

async function tlsFixture(options, handler) {
  const server = https.createServer(options, handler);
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const { port } = server.address();
  return {
    server,
    port,
    async close() { server.close(); await once(server, 'close'); },
  };
}

function pemFromDer(der) {
  const encoded = der.toString('base64').match(/.{1,64}/g).join('\n');
  return `-----BEGIN CERTIFICATE-----\n${encoded}\n-----END CERTIFICATE-----\n`;
}

async function windowsTestCertificate() {
  const directory = await mkdtemp(path.join(os.tmpdir(), 'streampilot-tls-'));
  const pfxPath = path.join(directory, 'fixture.pfx');
  const certificatePath = path.join(directory, 'fixture.cer');
  const passphrase = 'StreamPilot-Test-Fixture-Only';
  const script = "$cert = New-SelfSignedCertificate -Type Custom -Subject 'CN=media.example' -DnsName 'media.example' -CertStoreLocation 'Cert:\\CurrentUser\\My' -KeyExportPolicy Exportable -KeySpec Signature -HashAlgorithm SHA256 -NotAfter (Get-Date).AddDays(2); try { Export-PfxCertificate -Cert $cert -FilePath $env:SP_TLS_PFX -Password (ConvertTo-SecureString $env:SP_TLS_PASS -AsPlainText -Force) | Out-Null; Export-Certificate -Cert $cert -FilePath $env:SP_TLS_CERT | Out-Null } finally { Remove-Item -LiteralPath ('Cert:\\CurrentUser\\My\\' + $cert.Thumbprint) -Force }";
  try {
    await execFileAsync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], {
      env: { ...process.env, SP_TLS_PFX: pfxPath, SP_TLS_CERT: certificatePath, SP_TLS_PASS: passphrase },
    });
    return { pfx: await readFile(pfxPath), passphrase, ca: pemFromDer(await readFile(certificatePath)), async cleanup() { await rm(directory, { recursive: true, force: true }); } };
  } catch (error) {
    await rm(directory, { recursive: true, force: true });
    throw error;
  }
}

async function hasWindowsCertificateFixtureSupport() {
  if (process.platform !== 'win32') return false;
  try {
    const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "Import-Module Microsoft.PowerShell.Security -ErrorAction Stop; Import-Module PKI -ErrorAction Stop; [bool](Get-PSDrive -Name Cert -ErrorAction SilentlyContinue)"], { env: process.env });
    return stdout.trim() === 'True';
  } catch { return false; }
}

function dispatcherForFixture({ lookup, hostAllowlist, dials }) {
  // The bridge exists only in this local fixture: it proves Undici receives a
  // pinned public address while routing that test-only socket to loopback.
  // Production transport never rewrites a validated address this way.
  return createPinnedDispatcher({
    lookup,
    allowHttp: true,
    hostAllowlist,
    connections: 1,
    tcpConnect: (options) => {
      dials.push({ ...options });
      return net.connect({ ...options, host: '127.0.0.1' });
    },
  }).dispatcher;
}

function dispatcherForBoundIpFixture({ address, dials }) {
  return createPinnedDispatcher({
    allowHttp: true,
    ipLiteralAllowlist: [address],
    connections: 1,
    tcpConnect: (options) => {
      dials.push({ ...options });
      return net.connect({ ...options, host: '127.0.0.1' });
    },
  }).dispatcher;
}

function dispatcherForTlsFixture({ lookup, hostAllowlist, dials, ca }) {
  return createPinnedDispatcher({
    lookup,
    hostAllowlist,
    connections: 1,
    tlsConnect: (options) => {
      dials.push({ ...options });
      // The local bridge changes only the test socket destination. It retains
      // the original SNI, strict verification setting, and trusted test CA.
      return tls.connect({ ...options, host: '127.0.0.1', ...(ca ? { ca } : {}) });
    },
  }).dispatcher;
}

function grantedRequest(sessions, upstreamUrl) {
  const sessionId = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl }]);
  const grant = sessions.createGrant(sessionId, 'live-1');
  return { sessionId, path: `/api/playback/${grant}/manifest.m3u8` };
}

test('optional dispatcher uses an actual Undici request with the original Host header and a pinned address', async () => {
  const seenHosts = [];
  const local = await fixture((req, res) => {
    seenHosts.push(req.headers.host);
    res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl' });
    res.end('#EXTM3U\n#EXTINF:-1,Fixture\nsegment.ts\n');
  });
  const dials = [];
  const dispatcher = dispatcherForFixture({ lookup: async () => publicAnswer, hostAllowlist: ['media.example'], dials });
  try {
    const sessions = new PlaybackSessions();
    const { sessionId, path } = grantedRequest(sessions, `http://media.example:${local.port}/master.m3u8`);
    const result = response();
    await handlePlaybackRequest(request(path, sessionId), result, { sessions, fetchImpl: undiciFetch, dispatcher, lookup: async () => publicAnswer, allowHttp: true, hostAllowlist: ['media.example'] });
    assert.equal(result.status, 200);
    assert.match(result.body, /asset\//);
    assert.deepEqual(seenHosts, [`media.example:${local.port}`]);
    assert.deepEqual(dials.map(({ host, family }) => ({ host, family })), [{ host: '93.184.216.34', family: 4 }]);
  } finally {
    await dispatcher.close();
    await local.close();
  }
});

test('an exact bound HTTP IP redirect uses the literal Host header and a direct pinned dial', async () => {
  const seenHosts = [];
  const local = await fixture((req, res) => {
    seenHosts.push(req.headers.host);
    if (req.headers.host?.startsWith('media.example:')) {
      res.writeHead(302, { location: `http://93.184.216.34:${local.port}/master.m3u8` });
      res.end();
      return;
    }
    res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl' });
    res.end('#EXTM3U\n#EXTINF:-1,Fixture\nsegment.ts\n');
  });
  const sourceDials = []; const literalDials = [];
  const sourceDispatcher = dispatcherForFixture({ lookup: async () => publicAnswer, hostAllowlist: ['media.example'], dials: sourceDials });
  const literalDispatcher = dispatcherForBoundIpFixture({ address: '93.184.216.34', dials: literalDials });
  try {
    const sessions = new PlaybackSessions();
    const { sessionId, path } = grantedRequest(sessions, `http://media.example:${local.port}/master.m3u8`);
    const result = response();
    await handlePlaybackRequest(request(path, sessionId), result, {
      sessions,
      fetchImpl: undiciFetch,
      dispatcher: sourceDispatcher,
      boundIpRedirectDispatcherFactory: ({ destinationIp }) => {
        assert.equal(destinationIp, '93.184.216.34');
        return literalDispatcher;
      },
      lookup: async () => publicAnswer,
      allowHttp: true,
      hostAllowlist: ['media.example'],
      httpIpRedirectBinding: { sourceHostname: 'media.example', destinationIp: '93.184.216.34' },
    });
    assert.equal(result.status, 200);
    assert.deepEqual(seenHosts, [`media.example:${local.port}`, `93.184.216.34:${local.port}`]);
    assert.deepEqual(sourceDials.map(({ host, family }) => ({ host, family })), [{ host: '93.184.216.34', family: 4 }]);
    assert.deepEqual(literalDials.map(({ host, family }) => ({ host, family })), [{ host: '93.184.216.34', family: 4 }]);
  } finally {
    await sourceDispatcher.close();
    await literalDispatcher.close().catch(() => {});
    await local.close();
  }
});

test('default playback fetch uses the installed Undici implementation with a bound literal dispatcher', async (t) => {
  const local = await fixture((req, res) => {
    if (req.headers.host?.startsWith('media.example:')) {
      res.writeHead(302, { location: `http://93.184.216.34:${local.port}/master.m3u8` });
      res.end();
      return;
    }
    res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl' });
    res.end('#EXTM3U\n#EXTINF:-1,Fixture\nsegment.ts\n');
  });
  let socketErrorCode;
  const sourceDispatcher = createPinnedDispatcher({
    lookup: async () => publicAnswer, allowHttp: true, hostAllowlist: ['media.example'], connections: 1,
    tcpConnect: (options) => {
      const socket = net.connect({ ...options, host: '127.0.0.1' });
      socket.once('error', (error) => { socketErrorCode = error.code; });
      return socket;
    },
  }).dispatcher;
  const literalDispatcher = createPinnedDispatcher({
    allowHttp: true, ipLiteralAllowlist: ['93.184.216.34'], connections: 1,
    tcpConnect: (options) => {
      const socket = net.connect({ ...options, host: '127.0.0.1' });
      socket.once('error', (error) => { socketErrorCode = error.code; });
      return socket;
    },
  }).dispatcher;
  try {
    const sessions = new PlaybackSessions();
    const { sessionId, path } = grantedRequest(sessions, `http://media.example:${local.port}/master.m3u8`);
    const result = response();
    await handlePlaybackRequest(request(path, sessionId), result, {
      sessions,
      dispatcher: sourceDispatcher,
      boundIpRedirectDispatcherFactory: () => literalDispatcher,
      lookup: async () => publicAnswer,
      allowHttp: true,
      hostAllowlist: ['media.example'],
      httpIpRedirectBinding: { sourceHostname: 'media.example', destinationIp: '93.184.216.34' },
    });
    assert.equal(result.status, 200);
  } catch (error) {
    if (socketErrorCode === 'EACCES') {
      t.skip('Local sockets are denied by this execution environment.');
      return;
    }
    throw error;
  } finally {
    await sourceDispatcher.close();
    await literalDispatcher.close().catch(() => {});
    await local.close();
  }
});

test('actual Undici redirects are separately revalidated and the redirect body is cancelled', async () => {
  const seenHosts = []; let redirectClosed = false;
  const local = await fixture((req, res) => {
    seenHosts.push(req.headers.host);
    if (req.headers.host?.startsWith('media.example:')) {
      res.writeHead(302, { location: `http://redirect.example:${local.port}/master.m3u8` });
      res.write('discard-me');
      const interval = setInterval(() => res.write('x'), 2);
      res.on('close', () => { redirectClosed = true; clearInterval(interval); });
      return;
    }
    res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl' });
    res.end('#EXTM3U\n#EXTINF:-1,Fixture\nsegment.ts\n');
  });
  const dials = [];
  const dispatcher = dispatcherForFixture({ lookup: async () => publicAnswer, hostAllowlist: ['media.example', 'redirect.example'], dials });
  try {
    const sessions = new PlaybackSessions();
    const { sessionId, path } = grantedRequest(sessions, `http://media.example:${local.port}/master.m3u8`);
    await handlePlaybackRequest(request(path, sessionId), response(), {
      sessions, fetchImpl: undiciFetch, dispatcher, lookup: async () => publicAnswer, allowHttp: true,
      hostAllowlist: ['media.example', 'redirect.example'],
      boundDomainRedirectDispatcherFactory: () => dispatcherForFixture({ lookup: async () => publicAnswer, hostAllowlist: ['redirect.example'], dials }),
    });
    await new Promise((resolve) => setTimeout(resolve, 10));
    assert.deepEqual(seenHosts, [`media.example:${local.port}`, `redirect.example:${local.port}`]);
    assert.equal(redirectClosed, true);
    assert.equal(dials.length, 2);
    assert.equal(dials.every((dial) => dial.host === '93.184.216.34'), true);
  } finally {
    await dispatcher.close();
    await local.close();
  }
});

test('an unapproved redirect never reaches the dispatcher or local fixture a second time', async () => {
  let requests = 0;
  const local = await fixture((_req, res) => {
    requests += 1;
    res.writeHead(302, { location: `http://unapproved.example:${local.port}/master.m3u8` });
    res.end();
  });
  const dials = [];
  const dispatcher = dispatcherForFixture({ lookup: async () => publicAnswer, hostAllowlist: ['media.example'], dials });
  try {
    const sessions = new PlaybackSessions();
    const { sessionId, path } = grantedRequest(sessions, `http://media.example:${local.port}/master.m3u8`);
    await assert.rejects(() => handlePlaybackRequest(request(path, sessionId), response(), { sessions, fetchImpl: undiciFetch, dispatcher, lookup: async (hostname) => hostname === 'unapproved.example' ? [{ address: '10.0.0.8', family: 4 }] : publicAnswer, allowHttp: true, hostAllowlist: ['media.example'] }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    assert.equal(requests, 1);
    assert.equal(dials.length, 1);
  } finally {
    await dispatcher.close();
    await local.close();
  }
});

test('a reused pooled socket cannot skip validation for a later playback grant', async () => {
  let requests = 0;
  const local = await fixture((_req, res) => {
    requests += 1;
    res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl' });
    res.end('#EXTM3U\n#EXTINF:-1,Fixture\nsegment.ts\n');
  });
  const dials = []; let safe = true;
  const lookup = async () => safe ? publicAnswer : [{ address: '10.0.0.8', family: 4 }];
  const dispatcher = dispatcherForFixture({ lookup, hostAllowlist: ['media.example'], dials });
  try {
    const sessions = new PlaybackSessions();
    const upstreamUrl = `http://media.example:${local.port}/master.m3u8`;
    const first = grantedRequest(sessions, upstreamUrl);
    const second = grantedRequest(sessions, upstreamUrl);
    await handlePlaybackRequest(request(first.path, first.sessionId), response(), { sessions, fetchImpl: undiciFetch, dispatcher, lookup, allowHttp: true, hostAllowlist: ['media.example'] });
    await handlePlaybackRequest(request(second.path, second.sessionId), response(), { sessions, fetchImpl: undiciFetch, dispatcher, lookup, allowHttp: true, hostAllowlist: ['media.example'] });
    assert.equal(requests, 2);
    assert.equal(dials.length, 1);
    safe = false;
    const rejected = grantedRequest(sessions, upstreamUrl);
    await assert.rejects(() => handlePlaybackRequest(request(rejected.path, rejected.sessionId), response(), { sessions, fetchImpl: undiciFetch, dispatcher, lookup, allowHttp: true, hostAllowlist: ['media.example'] }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    assert.equal(requests, 2);
    assert.equal(dials.length, 1);
  } finally {
    await dispatcher.close();
    await local.close();
  }
});

test('a pooled socket does not bypass the next request validation and aborts slow responses', async () => {
  let requests = 0; let closed = false;
  const local = await fixture((req, res) => {
    requests += 1;
    req.on('close', () => { closed = true; });
    setTimeout(() => { if (!res.destroyed) res.end('#EXTM3U\n'); }, 100);
  });
  const dials = []; let safe = true;
  const lookup = async () => safe ? publicAnswer : [{ address: '10.0.0.8', family: 4 }];
  const dispatcher = dispatcherForFixture({ lookup, hostAllowlist: ['media.example'], dials });
  try {
    const sessions = new PlaybackSessions();
    const first = grantedRequest(sessions, `http://media.example:${local.port}/master.m3u8`);
    await assert.rejects(() => handlePlaybackRequest(request(first.path, first.sessionId), response(), { sessions, fetchImpl: undiciFetch, dispatcher, lookup, allowHttp: true, hostAllowlist: ['media.example'], timeoutMs: 20 }), (error) => error instanceof ConnectorError && error.code === 'provider_timeout');
    await new Promise((resolve) => setTimeout(resolve, 10));
    assert.equal(closed, true);
    assert.equal(requests, 1);
    safe = false;
    const second = grantedRequest(sessions, `http://media.example:${local.port}/master.m3u8`);
    await assert.rejects(() => handlePlaybackRequest(request(second.path, second.sessionId), response(), { sessions, fetchImpl: undiciFetch, dispatcher, lookup, allowHttp: true, hostAllowlist: ['media.example'] }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    assert.equal(requests, 1);
    assert.equal(dials.length, 1);
  } finally {
    await dispatcher.close();
    await local.close();
  }
});

test('actual Undici TLS preserves SNI and rejects untrusted or wrong-host certificates', async (t) => {
  if (!await hasWindowsCertificateFixtureSupport()) {
    t.skip('A local X.509 certificate fixture is unavailable in this environment.');
    return;
  }
  const material = await windowsTestCertificate();
  let sni; let tlsClientErrors = 0; const seenHosts = [];
  const local = await tlsFixture({ pfx: material.pfx, passphrase: material.passphrase }, (req, res) => {
    seenHosts.push(req.headers.host);
    res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl' });
    res.end('#EXTM3U\n#EXTINF:-1,Fixture\nsegment.ts\n');
  });
  local.server.on('secureConnection', (socket) => { sni = socket.servername; });
  local.server.on('tlsClientError', () => { tlsClientErrors += 1; });
  const lookup = async () => publicAnswer;
  const trustedDials = [];
  const trusted = dispatcherForTlsFixture({ lookup, hostAllowlist: ['media.example'], dials: trustedDials, ca: material.ca });
  const untrusted = dispatcherForTlsFixture({ lookup, hostAllowlist: ['media.example'], dials: [], ca: undefined });
  const wrongHost = dispatcherForTlsFixture({ lookup, hostAllowlist: ['wrong.example'], dials: [], ca: material.ca });
  try {
    const successSessions = new PlaybackSessions();
    const success = grantedRequest(successSessions, `https://media.example:${local.port}/master.m3u8`);
    await handlePlaybackRequest(request(success.path, success.sessionId), response(), { sessions: successSessions, fetchImpl: undiciFetch, dispatcher: trusted, lookup, hostAllowlist: ['media.example'] });
    assert.equal(sni, 'media.example');
    assert.deepEqual(seenHosts, [`media.example:${local.port}`]);
    assert.equal(trustedDials[0].host, '93.184.216.34');
    assert.equal(trustedDials[0].servername, 'media.example');
    assert.equal(trustedDials[0].rejectUnauthorized, true);

    const untrustedSessions = new PlaybackSessions();
    const untrustedRequest = grantedRequest(untrustedSessions, `https://media.example:${local.port}/master.m3u8`);
    await assert.rejects(() => handlePlaybackRequest(request(untrustedRequest.path, untrustedRequest.sessionId), response(), { sessions: untrustedSessions, fetchImpl: undiciFetch, dispatcher: untrusted, lookup, hostAllowlist: ['media.example'] }), (error) => error instanceof ConnectorError && error.code === 'provider_unreachable' && !error.message.includes('CERT'));

    const wrongSessions = new PlaybackSessions();
    const wrongRequest = grantedRequest(wrongSessions, `https://wrong.example:${local.port}/master.m3u8`);
    await assert.rejects(() => handlePlaybackRequest(request(wrongRequest.path, wrongRequest.sessionId), response(), { sessions: wrongSessions, fetchImpl: undiciFetch, dispatcher: wrongHost, lookup, hostAllowlist: ['wrong.example'] }), (error) => error instanceof ConnectorError && error.code === 'provider_unreachable' && !error.message.includes('ERR_TLS'));
    await new Promise((resolve) => setTimeout(resolve, 10));
    assert.ok(tlsClientErrors >= 2);
  } finally {
    await Promise.allSettled([trusted.close(), untrusted.close(), wrongHost.close()]);
    await local.close();
    await material.cleanup();
  }
});
