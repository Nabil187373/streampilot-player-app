import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { EventEmitter } from 'node:events';
import test from 'node:test';
import { MediaToolError, createMediaToolRunner, mediaTools } from './ffmpeg.mjs';

// ---------- helpers ----------

function fakeChild({ pid = 4242, closeOn = ['SIGTERM', 'SIGKILL'] } = {}) {
  const child = new EventEmitter();
  child.pid = pid;
  child.stdout = new EventEmitter();
  child.stderr = new EventEmitter();
  child.killSignals = [];
  child.kill = (signal = 'SIGTERM') => {
    child.killSignals.push(signal);
    if (closeOn.includes(signal)) setImmediate(() => child.emit('close', null, signal));
    return true;
  };
  return child;
}

function recordingSpawn(makeChild) {
  const calls = [];
  const spawnImpl = (command, args, options) => {
    const child = makeChild(command, args, options);
    calls.push({ command, args, options, child });
    return child;
  };
  return { spawnImpl, calls };
}

// Runs the real Node executable as a stand-in for ffmpeg/ffprobe, so the tests
// exercise genuine process spawning without needing FFmpeg installed.
function realRunner(extra = {}) {
  const children = [];
  const spawnImpl = (...args) => {
    const child = spawn(...args);
    children.push(child);
    return child;
  };
  const runner = createMediaToolRunner({
    spawnImpl,
    ffmpegPath: process.execPath,
    ffprobePath: process.execPath,
    killGraceMs: 200,
    ...extra,
  });
  return { runner, children };
}

async function assertCode(promise, code) {
  await assert.rejects(promise, (error) => {
    assert.ok(error instanceof MediaToolError, 'expected a MediaToolError');
    assert.equal(error.code, code);
    return true;
  });
}

const processIsDone = (child) => child.exitCode !== null || child.signalCode !== null;

// ---------- 1. FFmpeg success ----------

test('runs ffmpeg with shell disabled, an argument array and the configured path', async () => {
  const { spawnImpl, calls } = recordingSpawn(() => {
    const child = fakeChild();
    setImmediate(() => {
      child.stdout.emit('data', Buffer.from('frame=1 '));
      child.stderr.emit('data', Buffer.from('ffmpeg version test'));
      child.emit('close', 0, null);
    });
    return child;
  });
  const runner = createMediaToolRunner({ spawnImpl, ffmpegPath: 'C:\\tools\\ffmpeg.exe', env: {} });
  const args = ['-i', 'input.mkv', '-c:v', 'copy', 'out.mp4'];
  const result = await runner.runFfmpeg(args);

  assert.equal(result.exitCode, 0);
  assert.equal(result.stdout, 'frame=1 ');
  assert.equal(result.stderr, 'ffmpeg version test');
  assert.equal(calls.length, 1);
  assert.equal(calls[0].command, 'C:\\tools\\ffmpeg.exe');
  assert.deepEqual(calls[0].args, args);
  assert.notEqual(calls[0].args, args, 'arguments must be copied, not shared');
  assert.equal(calls[0].options.shell, false);
  assert.equal(calls[0].options.windowsHide, true);
  assert.deepEqual(calls[0].options.stdio, ['ignore', 'pipe', 'pipe']);
});

test('real process: a successful run returns stdout and exit code 0', async () => {
  const { runner } = realRunner();
  const result = await runner.runFfmpeg(['-e', 'process.stdout.write("hello")']);
  assert.equal(result.exitCode, 0);
  assert.equal(result.stdout, 'hello');
});

// ---------- 2. FFprobe success ----------

test('runs ffprobe with its own configured path and returns JSON output', async () => {
  const { spawnImpl, calls } = recordingSpawn(() => {
    const child = fakeChild();
    setImmediate(() => {
      child.stdout.emit('data', Buffer.from('{"streams":[{"codec_name":"ac3"}]}'));
      child.emit('close', 0, null);
    });
    return child;
  });
  const runner = createMediaToolRunner({ spawnImpl, ffprobePath: '/opt/ffprobe', env: {} });
  const result = await runner.runFfprobe(['-v', 'error', '-print_format', 'json', '-show_streams', 'sample.mkv']);
  assert.equal(calls[0].command, '/opt/ffprobe');
  assert.equal(JSON.parse(result.stdout).streams[0].codec_name, 'ac3');
});

test('reads FFMPEG_PATH and FFPROBE_PATH from the environment, and defaults to bare names', async () => {
  const seen = [];
  const spawnImpl = (command) => {
    seen.push(command);
    const child = fakeChild();
    setImmediate(() => child.emit('close', 0, null));
    return child;
  };
  const withEnv = createMediaToolRunner({
    spawnImpl,
    env: { FFMPEG_PATH: ' C:\\ff\\ffmpeg.exe ', FFPROBE_PATH: 'C:\\ff\\ffprobe.exe' },
  });
  assert.equal(withEnv.ffmpegPath, 'C:\\ff\\ffmpeg.exe');
  await withEnv.runFfmpeg(['-version']);
  await withEnv.runFfprobe(['-version']);
  assert.deepEqual(seen, ['C:\\ff\\ffmpeg.exe', 'C:\\ff\\ffprobe.exe']);

  const defaults = createMediaToolRunner({ spawnImpl, env: { FFMPEG_PATH: '   ' } });
  assert.equal(defaults.ffmpegPath, 'ffmpeg');
  assert.equal(defaults.ffprobePath, 'ffprobe');
});

// ---------- 3. Non-zero exit and stderr capture ----------

test('non-zero exit rejects with the exit code and redacted stderr', async () => {
  const { spawnImpl } = recordingSpawn(() => {
    const child = fakeChild();
    setImmediate(() => {
      child.stderr.emit('data', Buffer.from(
        'Error opening input http://user:pass@provider.example/live/abc/1.mkv?token=SECRET123: Server returned 403 Forbidden\n'
        + 'retry with password=hunter2 failed',
      ));
      child.emit('close', 1, null);
    });
    return child;
  });
  const runner = createMediaToolRunner({ spawnImpl, env: {} });

  await assert.rejects(runner.runFfmpeg(['-i', 'http://user:pass@provider.example/live/abc/1.mkv?token=SECRET123', 'o.mp4']), (error) => {
    assert.equal(error.code, 'nonzero_exit');
    assert.equal(error.exitCode, 1);
    assert.match(error.stderr, /Server returned 403 Forbidden/);
    assert.match(error.stderr, /\[redacted-url\]/);
    for (const secret of ['user:pass', 'provider.example', 'SECRET123', 'hunter2']) {
      assert.ok(!error.stderr.includes(secret), `stderr leaked ${secret}`);
      assert.ok(!error.message.includes(secret), `message leaked ${secret}`);
      assert.ok(!JSON.stringify(error).includes(secret), `serialized error leaked ${secret}`);
      assert.ok(!String(error.stack).includes(secret), `stack leaked ${secret}`);
    }
    return true;
  });
});

test('stderr is truncated to its tail after redaction', async () => {
  const { spawnImpl } = recordingSpawn(() => {
    const child = fakeChild();
    setImmediate(() => {
      child.stderr.emit('data', Buffer.from(`${'a'.repeat(10_000)}END`));
      child.emit('close', 2, null);
    });
    return child;
  });
  const runner = createMediaToolRunner({ spawnImpl, env: {} });
  await assert.rejects(runner.runFfmpeg(['-version']), (error) => {
    assert.equal(error.stderr.length, 4096);
    assert.ok(error.stderr.endsWith('END'));
    return true;
  });
});

test('real process: non-zero exit is reported with captured stderr', async () => {
  const { runner } = realRunner();
  await assert.rejects(
    runner.runFfmpeg(['-e', 'process.stderr.write("boom happened"); process.exit(3)']),
    (error) => {
      assert.equal(error.code, 'nonzero_exit');
      assert.equal(error.exitCode, 3);
      assert.equal(error.stderr, 'boom happened');
      return true;
    },
  );
});

// ---------- 4. Timeout and process termination ----------

test('timeout terminates the process, escalating to SIGKILL when SIGTERM is ignored', async () => {
  const child = fakeChild({ closeOn: ['SIGKILL'] }); // ignores SIGTERM
  const runner = createMediaToolRunner({
    spawnImpl: () => child,
    timeoutMs: 20,
    killGraceMs: 20,
    env: {},
  });
  await assertCode(runner.runFfmpeg(['-version']), 'timeout');
  assert.deepEqual(child.killSignals, ['SIGTERM', 'SIGKILL']);
});

test('a process that never closes cannot hang the caller forever', async () => {
  const child = fakeChild({ closeOn: [] }); // ignores everything
  const runner = createMediaToolRunner({
    spawnImpl: () => child,
    timeoutMs: 20,
    killGraceMs: 20,
    env: {},
  });
  const started = Date.now();
  await assertCode(runner.runFfmpeg(['-version']), 'timeout');
  assert.ok(Date.now() - started < 2_000);
  assert.ok(child.killSignals.includes('SIGKILL'));
});

test('real process: a hanging process is killed and no process is left running', async () => {
  const { runner, children } = realRunner();
  await assertCode(
    runner.runFfmpeg(['-e', 'setInterval(() => {}, 1000)'], { timeoutMs: 300 }),
    'timeout',
  );
  assert.equal(children.length, 1);
  assert.ok(processIsDone(children[0]), 'the child process must be dead after the rejection');
});

test('an abort signal cancels the run and terminates the process', async () => {
  const child = fakeChild();
  const runner = createMediaToolRunner({ spawnImpl: () => child, killGraceMs: 20, env: {} });
  const controller = new AbortController();
  const pending = runner.runFfmpeg(['-version'], { signal: controller.signal });
  setImmediate(() => controller.abort());
  await assertCode(pending, 'aborted');
  assert.equal(child.killSignals[0], 'SIGTERM');

  // An already-aborted signal never spawns anything.
  let spawned = 0;
  const idle = createMediaToolRunner({ spawnImpl: () => { spawned += 1; return fakeChild(); }, env: {} });
  const done = new AbortController();
  done.abort();
  await assertCode(idle.runFfmpeg(['-version'], { signal: done.signal }), 'aborted');
  assert.equal(spawned, 0);
});

// ---------- 5. Output limit ----------

test('combined stdout and stderr over the limit terminates the process', async () => {
  const child = fakeChild();
  const runner = createMediaToolRunner({
    spawnImpl: () => child,
    maxOutputBytes: 100,
    killGraceMs: 20,
    env: {},
  });
  const pending = runner.runFfmpeg(['-version']);
  setImmediate(() => {
    child.stdout.emit('data', Buffer.alloc(60, 'x'));
    child.stderr.emit('data', Buffer.alloc(60, 'y')); // 120 combined bytes
  });
  await assertCode(pending, 'output_limit_exceeded');
  assert.equal(child.killSignals[0], 'SIGTERM');
});

test('output exactly at the limit is accepted', async () => {
  const { spawnImpl } = recordingSpawn(() => {
    const child = fakeChild();
    setImmediate(() => {
      child.stdout.emit('data', Buffer.alloc(50, 'x'));
      child.stderr.emit('data', Buffer.alloc(50, 'y'));
      child.emit('close', 0, null);
    });
    return child;
  });
  const runner = createMediaToolRunner({ spawnImpl, maxOutputBytes: 100, env: {} });
  const result = await runner.runFfmpeg(['-version']);
  assert.equal(result.stdout.length + result.stderr.length, 100);
});

test('real process: runaway output is cut off and the process is terminated', async () => {
  const { runner, children } = realRunner();
  await assertCode(
    runner.runFfmpeg(
      ['-e', 'const b = Buffer.alloc(65536, 120); const t = setInterval(() => process.stdout.write(b), 1);'],
      { maxOutputBytes: 200_000, timeoutMs: 10_000 },
    ),
    'output_limit_exceeded',
  );
  assert.ok(processIsDone(children[0]));
});

// ---------- 6. Missing executable ----------

test('real process: a missing executable is reported as executable_not_found', async () => {
  const runner = createMediaToolRunner({
    ffmpegPath: 'definitely-not-a-real-binary-streampilot',
    env: {},
  });
  await assertCode(runner.runFfmpeg(['-version']), 'executable_not_found');
});

test('spawn errors are classified without exposing details', async () => {
  const cases = [
    [Object.assign(new Error('x'), { code: 'ENOENT' }), 'executable_not_found'],
    [Object.assign(new Error('x'), { code: 'EACCES' }), 'executable_not_executable'],
    [Object.assign(new Error('x'), { code: 'EPERM' }), 'executable_not_executable'],
    [Object.assign(new Error('C:\\secret\\path'), { code: 'EWHATEVER' }), 'spawn_failed'],
  ];
  for (const [error, expected] of cases) {
    // asynchronous failure: an 'error' event on a child that never got a pid
    const asyncRunner = createMediaToolRunner({
      spawnImpl: () => {
        const child = new EventEmitter();
        child.stdout = new EventEmitter();
        child.stderr = new EventEmitter();
        child.kill = () => true;
        setImmediate(() => child.emit('error', error));
        return child;
      },
      env: {},
    });
    await assert.rejects(asyncRunner.runFfmpeg(['-version']), (caught) => {
      assert.equal(caught.code, expected);
      assert.ok(!caught.message.includes('secret'));
      return true;
    });

    // synchronous failure: spawn itself throws
    const syncRunner = createMediaToolRunner({
      spawnImpl: () => { throw error; },
      env: {},
    });
    await assertCode(syncRunner.runFfprobe(['-version']), expected);
  }
});

// ---------- 7. Invalid arguments ----------

test('invalid argument arrays are rejected before anything is spawned', async () => {
  let spawned = 0;
  const runner = createMediaToolRunner({
    spawnImpl: () => { spawned += 1; return fakeChild(); },
    env: {},
  });
  const bad = [
    undefined,
    null,
    'ffmpeg -i x y',
    [],
    ['-i', 42],
    ['-i', null],
    ['-i', undefined],
    ['-i', ''],
    ['-i', 'bad\0arg'],
    ['-i', 'x'.repeat(8_193)],
    Array.from({ length: 257 }, () => '-y'),
  ];
  for (const args of bad) {
    await assertCode(runner.runFfmpeg(args), 'invalid_arguments');
    await assertCode(runner.runFfprobe(args), 'invalid_arguments');
  }
  assert.equal(spawned, 0);
});

test('arguments are passed through verbatim, so shell metacharacters stay inert', async () => {
  const { spawnImpl, calls } = recordingSpawn(() => {
    const child = fakeChild();
    setImmediate(() => child.emit('close', 0, null));
    return child;
  });
  const runner = createMediaToolRunner({ spawnImpl, env: {} });
  const args = ['-i', 'a b; rm -rf / && echo $(whoami) | `id`', 'out.mp4'];
  await runner.runFfmpeg(args);
  assert.deepEqual(calls[0].args, args);
  assert.equal(calls[0].options.shell, false);
});

// ---------- 8. Invalid timeout / output-limit / path configuration ----------

test('invalid configuration is rejected with invalid_config', () => {
  const badNumbers = [0, -1, 1.5, Number.NaN, Infinity, '5', null, 10 * 60_000 + 1];
  for (const value of badNumbers) {
    assert.throws(() => createMediaToolRunner({ timeoutMs: value, env: {} }), (e) => e.code === 'invalid_config', `timeoutMs ${String(value)}`);
    assert.throws(() => createMediaToolRunner({ killGraceMs: value, env: {} }), (e) => e.code === 'invalid_config', `killGraceMs ${String(value)}`);
  }
  for (const value of [0, -5, 2.5, Number.NaN, '1024', null, 64 * 1024 * 1024 + 1]) {
    assert.throws(() => createMediaToolRunner({ maxOutputBytes: value, env: {} }), (e) => e.code === 'invalid_config', `maxOutputBytes ${String(value)}`);
  }
  for (const value of ['', 5, null, 'bad\npath', 'bad\0path', 'x'.repeat(4_097)]) {
    assert.throws(() => createMediaToolRunner({ ffmpegPath: value, env: {} }), (e) => e.code === 'invalid_config', `ffmpegPath ${String(value)}`);
    assert.throws(() => createMediaToolRunner({ ffprobePath: value, env: {} }), (e) => e.code === 'invalid_config', `ffprobePath ${String(value)}`);
  }
  assert.throws(() => createMediaToolRunner({ env: { FFMPEG_PATH: 'bad\npath' } }), (e) => e.code === 'invalid_config');
  assert.throws(() => createMediaToolRunner({ spawnImpl: 'nope', env: {} }), (e) => e.code === 'invalid_config');
});

test('invalid per-call limits are rejected before spawning', async () => {
  let spawned = 0;
  const runner = createMediaToolRunner({
    spawnImpl: () => { spawned += 1; return fakeChild(); },
    env: {},
  });
  await assertCode(runner.runFfmpeg(['-version'], { timeoutMs: 0 }), 'invalid_config');
  await assertCode(runner.runFfmpeg(['-version'], { timeoutMs: 1.5 }), 'invalid_config');
  await assertCode(runner.runFfprobe(['-version'], { maxOutputBytes: -1 }), 'invalid_config');
  assert.equal(spawned, 0);
});

// ---------- extras: error safety and the default runner ----------

test('MediaToolError uses fixed messages and never echoes arguments', async () => {
  const secretArg = 'http://user:pass@provider.example/movie/u/p/1.mkv';
  const runner = createMediaToolRunner({
    spawnImpl: () => { throw Object.assign(new Error(`failed for ${secretArg}`), { code: 'ENOENT' }); },
    env: {},
  });
  await assert.rejects(runner.runFfmpeg(['-i', secretArg, 'o.mp4']), (error) => {
    assert.equal(error.name, 'MediaToolError');
    assert.ok(!error.message.includes('provider.example'));
    assert.ok(!JSON.stringify(error).includes('provider.example'));
    assert.ok(!String(error.stack).includes('provider.example'));
    return true;
  });
  assert.equal(new MediaToolError('not-a-real-code').code, 'spawn_failed');
});

test('the default mediaTools runner is lazy and exposes both operations', async () => {
  assert.equal(typeof mediaTools.runFfmpeg, 'function');
  assert.equal(typeof mediaTools.runFfprobe, 'function');
  // Invalid arguments are rejected before the default runner could spawn anything.
  await assertCode(mediaTools.runFfmpeg([]), 'invalid_arguments');
  await assertCode(mediaTools.runFfprobe('nope'), 'invalid_arguments');
});
