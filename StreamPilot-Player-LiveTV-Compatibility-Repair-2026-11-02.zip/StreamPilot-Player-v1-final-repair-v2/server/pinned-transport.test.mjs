import './test-env.mjs';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import test from 'node:test';
import { isForbiddenAddress } from './connector.mjs';
import { createPinnedTransport } from './pinned-transport.mjs';

class FakeSocket extends EventEmitter {
  setNoDelay() {}
  setKeepAlive() {}
}

function connectWith(transport, options) {
  return new Promise((resolve, reject) => transport.connect(options, (error, socket) => error ? reject(error) : resolve(socket)));
}

test('rejects special IPv4, IPv6, mapped IPv6, and unusual URL-normalized address forms', () => {
  for (const address of ['0.0.0.0', '127.0.0.1', '10.1.2.3', '100.64.0.1', '169.254.1.1', '172.16.0.1', '192.0.2.1', '192.168.1.1', '198.51.100.1', '203.0.113.1', '224.0.0.1', '::', '::1', '::ffff:127.0.0.1', '0:0:0:0:0:ffff:7f00:1', 'fc00::1', 'fe80::1', 'ff02::1', '64:ff9b:1::1', '100::1', '2001:db8::1', '3fff::1']) {
    assert.equal(isForbiddenAddress(address), true, address);
  }
  assert.equal(isForbiddenAddress('93.184.216.34'), false);
  assert.equal(isForbiddenAddress('2606:2800:220:1:248:1893:25c8:1946'), false);
});

test('pins a TLS socket to the validated address while retaining SNI and strict certificate verification', async () => {
  let dial;
  const transport = createPinnedTransport({
    allowHttp: true,
    lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    hostAllowlist: ['media.example'],
    tlsConnect: (options) => { dial = options; const socket = new FakeSocket(); queueMicrotask(() => socket.emit('secureConnect')); return socket; },
  });
  await connectWith(transport, { protocol: 'https:', hostname: 'media.example', port: '443', servername: 'media.example' });
  assert.deepEqual(dial, { host: '93.184.216.34', port: 443, family: 4, localAddress: undefined, servername: 'media.example', rejectUnauthorized: true, ALPNProtocols: ['http/1.1'] });
});

test('pins the sole validated DNS answer and never performs a second implicit lookup before dialing', async () => {
  let calls = 0; let dialed = false; let lookupOptions;
  const transport = createPinnedTransport({
    allowHttp: true,
    lookup: async (_hostname, options) => {
      calls += 1;
      lookupOptions = options;
      return calls === 1 ? [{ address: '93.184.216.34', family: 4 }] : [{ address: '10.0.0.8', family: 4 }];
    },
    hostAllowlist: ['media.example'],
    tcpConnect: (options) => { dialed = options; const socket = new FakeSocket(); queueMicrotask(() => socket.emit('connect')); return socket; },
  });
  // A second resolver answer could be hostile; the socket is instead pinned to
  // the single public answer that passed validation.
  await connectWith(transport, { protocol: 'http:', hostname: 'media.example', port: '80' });
  assert.equal(calls, 1);
  // This is the promise-based resolver call made before connecting. The
  // transport deliberately does not pass a Node callback-style `lookup` to
  // net.connect/tls.connect, so there is no separate `{ all: true }` callback
  // result shape to handle at socket connection time.
  assert.deepEqual(lookupOptions, { all: true, verbatim: true });
  assert.equal(dialed.host, '93.184.216.34');
});

test('dials an explicitly bound public IP literal directly without DNS lookup', async () => {
  let lookupCalls = 0; let dial;
  const transport = createPinnedTransport({
    allowHttp: true,
    ipLiteralAllowlist: ['93.184.216.34'],
    lookup: async () => { lookupCalls += 1; return [{ address: '10.0.0.8', family: 4 }]; },
    tcpConnect: (options) => { dial = options; const socket = new FakeSocket(); queueMicrotask(() => socket.emit('connect')); return socket; },
  });
  await connectWith(transport, { protocol: 'http:', hostname: '93.184.216.34', port: '8080' });
  assert.equal(lookupCalls, 0);
  assert.deepEqual(dial, { host: '93.184.216.34', port: 8080, family: 4, localAddress: undefined });
  await assert.rejects(() => connectWith(transport, { protocol: 'http:', hostname: '93.184.216.35', port: '80' }), (error) => error.code === 'provider_unreachable');
});

test('rejects private or reserved IP literals even if erroneously configured', async () => {
  for (const address of ['127.0.0.1', '10.0.0.8', '169.254.169.254', '203.0.113.42']) {
    const transport = createPinnedTransport({ allowHttp: true, ipLiteralAllowlist: [address] });
    await assert.rejects(() => connectWith(transport, { protocol: 'http:', hostname: address, port: '80' }), (error) => error.code === 'destination_not_allowed');
  }
});

test('rejects private mixed DNS answers, raw IPs, unapproved redirect hosts, and HTTP without opt-in before dialing', async () => {
  for (const options of [
    { lookup: async () => [{ address: '93.184.216.34', family: 4 }, { address: '10.0.0.8', family: 4 }], hostAllowlist: ['media.example'], destination: { protocol: 'https:', hostname: 'media.example', port: '443' } },
    { allowHttp: false, lookup: async () => [{ address: '93.184.216.34', family: 4 }], hostAllowlist: ['media.example'], destination: { protocol: 'http:', hostname: 'media.example', port: '80' } },
    { lookup: async () => [{ address: '93.184.216.34', family: 4 }], hostAllowlist: ['media.example'], destination: { protocol: 'https:', hostname: '203.0.113.7', port: '443' } },
  ]) {
    let dialed = false;
    const transport = createPinnedTransport({ ...options, tcpConnect: () => { dialed = true; return new FakeSocket(); }, tlsConnect: () => { dialed = true; return new FakeSocket(); } });
    await assert.rejects(() => connectWith(transport, options.destination), (error) => ['destination_not_allowed', 'provider_unreachable', 'http_not_allowed'].includes(error.code));
    assert.equal(dialed, false);
  }
});

test('allows a user-supplied public provider hostname without a deployment allowlist and pins its DNS answer', async () => {
  let dial;
  const transport = createPinnedTransport({
    lookup: async (hostname) => {
      assert.equal(hostname, 'other.example');
      return [{ address: '93.184.216.34', family: 4 }];
    },
    // No deployment-wide host allowlist: public user-supplied provider
    // hostnames are permitted after DNS/IP validation and pinned dialing.
    hostAllowlist: [],
    tlsConnect: (options) => {
      dial = options;
      const socket = new FakeSocket();
      queueMicrotask(() => socket.emit('secureConnect'));
      return socket;
    },
  });
  await connectWith(transport, { protocol: 'https:', hostname: 'other.example', port: '443' });
  assert.equal(dial.host, '93.184.216.34');
  assert.equal(dial.port, 443);
});

test('requires a separately approved public address for each redirect connection', async () => {
  const dialed = [];
  const transport = createPinnedTransport({
    lookup: async (host) => host === 'origin.example'
      ? [{ address: '93.184.216.34', family: 4 }]
      : [{ address: '10.0.0.8', family: 4 }],
    hostAllowlist: ['origin.example', 'redirect.example'],
    tlsConnect: (options) => { dialed.push(options.host); const socket = new FakeSocket(); queueMicrotask(() => socket.emit('secureConnect')); return socket; },
  });
  await connectWith(transport, { protocol: 'https:', hostname: 'origin.example', port: '443' });
  await assert.rejects(() => connectWith(transport, { protocol: 'https:', hostname: 'redirect.example', port: '443' }), (error) => error.code === 'destination_not_allowed');
  assert.deepEqual(dialed, ['93.184.216.34']);
});

test('allows an explicit HTTP opt-in, pins IPv6, and reports connection errors without transport details', async () => {
  let dial;
  const transport = createPinnedTransport({
    allowHttp: true,
    lookup: async () => [{ address: '2606:2800:220:1:248:1893:25c8:1946', family: 6 }],
    hostAllowlist: ['media.example'],
    tcpConnect: (options) => { dial = options; const socket = new FakeSocket(); queueMicrotask(() => socket.emit('connect')); return socket; },
  });
  await connectWith(transport, { protocol: 'http:', hostname: 'media.example', port: '2086' });
  assert.equal(dial.host, '2606:2800:220:1:248:1893:25c8:1946');
  assert.equal(dial.family, 6);
});

test('resolver and socket cancellation errors never expose transport details', async () => {
  const transport = createPinnedTransport({
    lookup: async () => { throw new Error('sensitive resolver result'); },
    hostAllowlist: ['media.example'],
  });
  await assert.rejects(() => connectWith(transport, { protocol: 'https:', hostname: 'media.example', port: '443' }), (error) => error.code === 'destination_not_allowed' && !error.message.includes('sensitive'));
  const cancelled = createPinnedTransport({
    lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    hostAllowlist: ['media.example'],
    tlsConnect: () => { const socket = new FakeSocket(); queueMicrotask(() => socket.emit('error', new Error('cancelled with sensitive target'))); return socket; },
  });
  await assert.rejects(() => connectWith(cancelled, { protocol: 'https:', hostname: 'media.example', port: '443' }), (error) => error.code === 'provider_unreachable' && !error.message.includes('sensitive'));
});

test('retains only fixed-format unknown socket metadata for playback local diagnostics', async () => {
  const transport = createPinnedTransport({
    lookup: async () => [{ address: '93.184.216.34', family: 4 }],
    hostAllowlist: ['media.example'],
    tlsConnect: () => {
      const socket = new FakeSocket();
      queueMicrotask(() => {
        const error = new Error('sensitive transport message');
        error.name = 'SocketError'; error.code = 'UNMAPPED_SOCKET';
        error.cause = { code: 'CAUSE_ONE', cause: { code: 'CAUSE_TWO' } };
        socket.emit('error', error);
      });
      return socket;
    },
  });
  await assert.rejects(() => connectWith(transport, { protocol: 'https:', hostname: 'media.example', port: '443' }), (error) => {
    assert.equal(error.code, 'provider_unreachable');
    assert.equal(error.localDiagnosticName, 'SocketError');
    assert.equal(error.localDiagnosticCode, 'UNMAPPED_SOCKET');
    assert.equal(error.localDiagnosticCauseCode, 'CAUSE_ONE');
    assert.equal(error.localDiagnosticCauseCauseCode, 'CAUSE_TWO');
    assert.equal(error.message.includes('sensitive'), false);
    return true;
  });
});
