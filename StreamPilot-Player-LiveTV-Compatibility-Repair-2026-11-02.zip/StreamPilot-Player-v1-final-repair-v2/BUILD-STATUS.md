# Build status — 2026-10-31

## Source review
- The repository contains a React/Vite/TypeScript browser prototype and a Node server.
- Server routes implement M3U/Xtream live metadata import, Xtream VOD category/item catalogue access, live HLS proxy playback, and a separate Xtream movie-media proxy route.
- Complete series browsing/episode playback, production activation/licensing, durable customer accounts, native packaging, and platform certification are not implemented.
- Phase 1 hardening work is in progress in an isolated working copy; this document records no production deployment or live-provider certification.

## Automated verification status
- Current playback hardening: 102 backend Node tests passed; 1 platform-specific TLS certificate fixture test skipped because the local X.509 fixture was unavailable.
- TypeScript `tsc --noEmit` passed.
- Vitest and Vite production build could not run in the packaging environment because the preinstalled dependency tree lacks the platform-specific Rolldown native binding. Re-run `npm.cmd test` and `npm.cmd run build` on Windows after `npm.cmd ci`.
- Browser playback against the user's provider remains to be verified.
- LG webOS, Samsung Tizen, Android TV/mobile, and iOS/iPadOS compatibility remain unverified.

## Environment
- Node.js >=22.19.0 is required by the package and its Undici dependency.
- `.env.example` documents the server-side configuration variables; keep real credentials and private configuration out of source control.


## Follow-up repair — 2026-10-31

- Enabled the exact `PLAYBACK_HTTP_IP_REDIRECT_BINDING=source-hostname=public-ip` operator approval in production. The wildcard same-port and provider-domain trust switches remain development-only.
- The exact binding still requires `ALLOW_HTTP_PROVIDER=1`, an exact source-hostname match to the already-validated redirect source, an exact public destination IP, validated redirect flow, and a pinned destination dispatcher. It does not require duplicating that source hostname in `PLAYBACK_HOST_ALLOWLIST`. Private/reserved destinations and arbitrary IP redirects remain rejected.
- Added a regression test for production exact-binding acceptance, pinned dispatch, and source-host mismatch rejection; updated `.env.example` and redirect documentation.
- Verification limitation: `node --check` passed for the modified server source and test file. Full playback tests could not execute in this environment: dependency installation did not complete, leaving the `undici` package incomplete. The available Node runtime is 22.16.0, below the project's declared Node >=22.19.0 requirement. No successful full test/build is claimed. Re-run `npm.cmd ci`, `npm.cmd test`, and `npm.cmd run build` on the Windows development machine with Node >=22.19.0.


## Universal compatibility upgrade — 2026-10-31

- Added a provider adapter registry for remote Xtream-export and generic M3U playlist imports. Authenticated Xtream API catalogues remain handled by the existing connector; Stalker/Ministra remains unsupported.
- Made provider and playback host allowlists optional additional restrictions. Empty lists now allow user-entered public DNS provider/CDN hosts after the existing destination validation; pinned transport and private/reserved-address protections remain in place.
- Moved the Live TV and VOD video elements into one persistent app-level dock so internal view navigation no longer unmounts the active media element.
- Added HLS.js audio-track enumeration/selection and an AAC/MP4A fallback when the default advertised codec is not supported by MediaSource. Added an explicit muted-autoplay sound action and an unsupported-audio-codec warning.
- Extended local and remote M3U metadata parsing for underscore aliases, EXTGRP, EXT-VLCOPT, KODIPROP and safe custom EXTINF attributes. Remote metadata excludes credential-like attributes and URL values.
- Added adapter-registry, M3U metadata, and no-deployment-allowlist regression tests. Included the FFmpeg utility tests in the main test command.
- Preserved the existing 40 MiB / 20,000-entry limits until durable catalogue storage and server-side pagination exist; increasing them in the current in-memory prototype would risk memory exhaustion.
- Validation performed in this packaging environment: all server `.mjs` files pass `node --check`; the provider registry test passes; `src/lib/m3u.ts` passes standalone TypeScript checking.
- Full `npm test` and production build are NOT verified here. Dependency installation timed out and left `vitest`/type packages incomplete; the available runtime is Node 22.16.0, below the repository requirement of Node 22.19+. Re-run `npm ci`, `npm test`, and `npm run build` on the Windows development machine with Node 24.22 as used in the project environment.
- Provider B audio compatibility still requires a real retest with its authorized stream. Browser-side audio track fallback cannot create AAC when the provider exposes only an unsupported codec; the existing FFmpeg runner is not yet wired into streaming playback.


## Final engineering pass started — 2026-10-31

### Source-level corrections
- Fixed the Live TV playback API wiring so `handlePlaybackRequest` receives the same provider-domain redirect trust, exact HTTP-IP binding/trust, and bound-domain dispatcher options that the API layer exposes to the movie/episode path.
- Added an explicit browser confirmation before connecting to HTTP-only Xtream or remote M3U endpoints. The warning states that credentials, playlists, and media traffic are unencrypted. HTTPS remains preferred.
- Corrected the Xtream UI security note: this revision's connector defaults currently accept HTTP and HTTPS; the earlier UI/README statement that HTTP was rejected by default did not match the source implementation.
- Rewrote stale agent guidance and corrected architecture documentation about the actual use of `hostAllowlist`. Provider entry hostnames are not required to be preconfigured in a global allowlist; destination validation and pinned transport remain active.

### Verification after these changes
- TypeScript `tsc --noEmit`: passed using the dependency files bundled in the archive.
- `node --check` for `server/api.mjs`, `server/playback.mjs`, and `server/connector.mjs`: passed.
- Focused backend tests: provider registry 1/1, connector 31/31, API 8/8, media 14/14 (54 passed).
- Full backend Node test run under the available Node 22.16.0 runtime: 116 passed, 12 failed, 5 cancelled, 1 skipped. The package requires Node >=22.19.0; pinned-transport tests were cancelled under the older runtime. Playback tests also contain expectations inconsistent with the current source policy and require individual review; they are not marked passed.
- Vitest and Vite build remain unverified because the ZIP's dependency tree is missing the platform-specific Rolldown native binding for this Linux environment. No full test-suite or production-build success is claimed.
- No live provider credentials were used; no external provider playback has been certified.


## Redirect binding regression repair — 2026-11-01

- Removed the redundant `PLAYBACK_HOST_ALLOWLIST` membership check from the exact production `PLAYBACK_HTTP_IP_REDIRECT_BINDING` path. The binding itself is an exact operator approval of one source hostname to one public IP; the initial provider hostname is still destination-validated, the redirect source must match exactly, HTTP must be enabled, and the redirect destination remains pinned to that one configured public IP.
- Kept the global allowlist checks on the separate development-only compatibility trust paths; no wildcard trust or broad IP redirect permission was added.
- Corrected the browser diagnostic so it recommends a public DNS redirect target only when the server explicitly reports `ip_literal_not_allowed`. A missing local diagnostic no longer gets misrepresented as proof that the provider returned an IP literal.
- Added regression coverage for an exact binding when the optional global host allowlist is empty, and for non-speculative browser diagnostics.
- Verification in this packaging environment: `node --check server/playback.mjs` passed. Full automated tests/build could not be run: `npm ci` timed out, the runtime is Node 22.16.0 (below the package's Node >=22.19.0 requirement), and dependencies are incomplete. This ZIP is a source repair candidate, not a fully test-certified release. Re-run `npm.cmd ci`, `npm.cmd test`, and `npm.cmd run build` on the user's Node 24.22 Windows environment.

## November 1, 2026 — redirect test correction

- Split the conflicting initial-host tests into two independent cases: a non-empty explicit allowlist still rejects an unlisted initial provider hostname, while an empty allowlist permits a public provider hostname after DNS/IP safety validation.
- Added a regression case proving the exact operator-configured public HTTP IP redirect binding works with an empty global host allowlist, while retaining the exact source-hostname/destination-IP match and pinned dispatcher requirement.
- `node --check` passed for the edited playback test and playback implementation. The runtime playback test could not execute in this environment because project dependencies (including `undici`) are not installed; the environment's Node is v22.16.0, below the project's declared `>=22.19.0` requirement.


## Provider public-IP redirect compatibility — 2026-11-02

- Implemented automatic support for validated public IPv4 and IPv6 redirect destinations in Live TV/HLS and VOD/media playback. No deployment-specific source-host-to-IP binding is required for ordinary public IP redirects.
- Public IP destinations preserve the provider-selected port and use an exact-IP pinned dispatcher. HTTP remains subject to the app's HTTP compatibility policy/confirmation; HTTPS retains strict certificate validation.
- Kept SSRF protections: private, loopback, link-local, reserved, and metadata destinations remain blocked; credentials/userinfo are rejected; redirect chains from IP literals are rejected; DNS hostnames are re-resolved, checked, and pinned; session/grant-bound HLS asset rewriting remains in place.
- Updated regression tests for public IPv4/IPv6 redirects, arbitrary public ports, private/reserved rejection, and redirect-chain rejection.
- Verification in this working environment: TypeScript `tsc --noEmit` passed; backend Node tests passed 139, failed 0, skipped 1. The frontend Vitest runner could not start because the bundled native Rolldown dependency is for a different platform. The user previously verified the frontend's 35 Vitest tests and Vite production build on Windows before this backend-only change; rerun `npm.cmd ci`, `npm.cmd test`, and `npm.cmd run build` on the Windows project after extracting this update.
- Real-provider browser playback is not yet certified. An upstream HTTP 403 is a separate provider authorization/policy issue and is not solved by accepting public IP redirects.

## Live provider compatibility and request-throttling repair — 2026-11-02

- Removed deployment-wide hostname allowlist gates from the normal Live TV initial-manifest, HLS redirect, and HLS asset paths. Customer-authorized provider/CDN hosts are accepted after scheme validation, complete DNS-answer checks, public-address filtering, bounded redirects, and pinned outbound connections. Optional development-only trust exceptions remain explicitly scoped and are not the normal compatibility path.
- Carried the narrow development-only provider-domain redirect binding through the redirect chain so a second unrelated hostname is not accidentally authorized; added regression coverage for the chained-redirect rejection.
- Fixed API throttling so the per-IP 10/minute bucket applies only to remote/Xtream playlist import endpoints. Authenticated catalogue and playback-grant operations now use their own session-scoped request limit and no longer consume the import bucket. Added regression tests proving 12 playback-grant operations from one local client are not blocked after an import and a customer playlist/CDN hostname is not rejected merely because it is absent from a legacy deployment allowlist.
- Improved server-side failure logs to identify the safe API route template, fixed error code, safe destination rejection category, and numeric upstream HTTP status when available. Opaque playback grant IDs, provider hostnames, URL paths/queries, and credentials are not logged.
- Corrected README compatibility policy and throttling descriptions to match the implementation.
- Verification in this environment: all modified server files pass `node --check`; backend test suite reports 142 passed, 0 failed, 1 skipped (143 total). The skipped test requires a local X.509 certificate fixture unavailable in this environment. The current environment is Node 22.16.0, below this project's declared Node >=22.19.0 requirement, so repeat `npm.cmd test` and `npm.cmd run build` on the user's Windows Node 24.22 environment after extracting this update.
- Real provider playback is not yet certified. The Xtream Live URL builder still assumes an `.m3u8` endpoint, and some providers may use incompatible transport URL formats or return upstream 403 responses. The next live test should inspect the new route/code/status diagnostics; a 403 requires provider-specific format/authorization investigation, not a blanket security bypass.
