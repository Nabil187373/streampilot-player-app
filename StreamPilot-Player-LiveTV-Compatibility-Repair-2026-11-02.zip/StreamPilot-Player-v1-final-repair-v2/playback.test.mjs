import assert from 'node:assert/strict';
import test from 'node:test';
import { ConnectorError } from './connector.mjs';
import { PlaybackSessions, handlePlaybackRequest, playbackFailureCategory, sessionCookie } from './playback.mjs';

function response() {
  return {
    status: 0, headers: {}, body: '',
    writeHead(status, headers) { this.status = status; this.headers = headers; return this; },
    write(chunk) { this.body += Buffer.from(chunk).toString('utf8'); return true; },
    end(chunk = '') { this.body += Buffer.from(chunk).toString('utf8'); },
    once() {}, destroy() { this.destroyed = true; },
  };
}
function request(path, sessionId) { return { method: 'GET', url: path, headers: { cookie: `sp_playback_session=${sessionId}` } }; }
function newSession(now = () => Date.now()) {
  const sessions = new PlaybackSessions({ now });
  const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://cdn.example/live/master.m3u8?token=private' }]);
  return { sessions, id };
}
const publicLookup = async () => [{ address: '93.184.216.34', family: 4 }];

test('sessions isolate playback grants, reject unknown items, and expire grants with their session', () => {
  let now = 0;
  const { sessions, id } = newSession(() => now);
  const other = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://cdn.example/live/other.m3u8' }]);
  const grant = sessions.createGrant(id, 'live-1');
  assert.throws(() => sessions.getGrant(other, grant), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
  assert.throws(() => sessions.createGrant(id, 'movie-1'), (error) => error instanceof ConnectorError && error.code === 'playback_item_not_found');
  now = 16 * 60_000;
  assert.throws(() => sessions.getGrant(id, grant), (error) => error instanceof ConnectorError && error.code === 'playback_unauthorized');
  assert.equal(sessions.createSession([{ id: 'movie-1', kind: 'movie', upstreamUrl: 'https://cdn.example/movie.mp4' }]), undefined);
});

test('HLS manifest rewriting hides upstream URLs and rewrites segment and key references', async () => {
  const { sessions, id } = newSession();
  const grant = sessions.createGrant(id, 'live-1');
  const res = response();
  const manifest = '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="keys/key.bin"\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nvariant.m3u8\n#EXTINF:6,\nsegments/one.ts\n';
  const handled = await handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), res, {
    sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'],
    fetchImpl: async () => new Response(manifest, { headers: { 'content-type': 'application/vnd.apple.mpegurl' } }),
  });
  assert.equal(handled, true);
  assert.equal(res.status, 200);
  assert.equal(res.headers['cache-control'], 'no-store');
  assert.match(res.body, /\/api\/playback\/[A-Za-z0-9_-]+\/asset\/[A-Za-z0-9_-]+/);
  assert.equal(res.body.includes('cdn.example'), false);
  assert.equal(res.body.includes('private'), false);
  assert.equal(res.body.includes('keys/key.bin'), false);
  assert.equal(res.body.includes('segments/one.ts'), false);
  const stages = [...sessions.getGrant(id, grant).grant.assets.values()].map((asset) => asset.playbackStage).sort();
  assert.deepEqual(stages, ['key', 'nested_playlist', 'segment']);
});

test('rejects a private playback destination before it is fetched', async () => {
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); let fetched = false;
  await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
    sessions, lookup: async () => [{ address: '127.0.0.1', family: 4 }], hostAllowlist: ['cdn.example'],
    fetchImpl: async () => { fetched = true; return new Response(); },
  }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
  assert.equal(fetched, false);
  const diagnostic = response();
  await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
  assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'host_not_allowed', stage: 'initial_live_stream' });
});

test('local host diagnostics expose only a rejected DNS hostname and fixed playback stage', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
  const previousNodeEnv = process.env.NODE_ENV;
  process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1';
  process.env.NODE_ENV = 'development';
  try {
    const sessions = new PlaybackSessions();
    const id = sessions.createSession([{ id: 'live-1', kind: 'live', upstreamUrl: 'https://blocked.example/live/master.m3u8?secret=value' }]);
    const grant = sessions.createGrant(id, 'live-1');
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, lookup: publicLookup, hostAllowlist: ['approved.example'], fetchImpl: async () => new Response(),
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    const diagnostic = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'host_not_allowed', stage: 'initial_live_stream', rejectedHostname: 'blocked.example', rejectedScheme: 'https' });
    assert.equal(diagnostic.body.includes('secret'), false);
    assert.equal(diagnostic.body.includes('https:'), false);
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
});

test('maps only fixed playback diagnostics and leaves unexpected errors generic', () => {
  assert.equal(playbackFailureCategory(new ConnectorError('safe', 401, 'playback_unauthorized')), 'session_expired');
  assert.equal(playbackFailureCategory(new ConnectorError('safe', 502, 'playback_redirect_rejected')), 'redirect_rejected');
  assert.equal(playbackFailureCategory(new ConnectorError('safe', 502, 'unsupported_response'), { phase: 'asset' }), 'asset_rejected');
  assert.equal(playbackFailureCategory(new Error('untrusted upstream text')), undefined);
});

test('revalidates playback redirects and rejects an unapproved redirected host', async () => {
  const previous = process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS; process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = '1';
  try {
    const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1'); let calls = 0;
    await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), {
      sessions, lookup: publicLookup, hostAllowlist: ['cdn.example'],
      fetchImpl: async () => { calls += 1; return new Response('', { status: 302, headers: { location: 'https://other.example/live.m3u8' } }); },
    }), (error) => error instanceof ConnectorError && error.code === 'destination_not_allowed');
    assert.equal(calls, 1);
    const diagnostic = response();
    await handlePlaybackRequest(request(`/api/playback/${grant}/diagnostic`, id), diagnostic, { sessions });
    assert.deepEqual(JSON.parse(diagnostic.body), { ok: true, category: 'host_not_allowed', stage: 'redirect', rejectedHostname: 'other.example', rejectedScheme: 'https' });
  } finally {
    if (previous === undefined) delete process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS;
    else process.env.PLAYBACK_LOCAL_HOST_DIAGNOSTICS = previous;
  }
});

test('requires an explicit playback-host allowlist and emits a strict HttpOnly session cookie', async () => {
  const { sessions, id } = newSession(); const grant = sessions.createGrant(id, 'live-1');
  await assert.rejects(() => handlePlaybackRequest(request(`/api/playback/${grant}/manifest.m3u8`, id), response(), { sessions, lookup: publicLookup, hostAllowlist: [] }), (error) => error instanceof ConnectorError && error.code === 'playback_not_configured');
  const cookie = sessionCookie('opaque-session', { secure: true });
  assert.match(cookie, /HttpOnly/); assert.match(cookie, /SameSite=Strict/); assert.match(cookie, /Secure/); assert.equal(cookie.includes('https://'), false);
});
