# iPhone + iPad client — not implemented yet

Proposed approach: universal iOS/iPadOS application using SwiftUI adaptive layouts and Apple's AVFoundation/AVKit playback APIs where appropriate.

Official starting point: https://developer.apple.com/ios/

Future work:
1. Create a separate Xcode project and confirm the minimum iOS/iPadOS version.
2. Implement adaptive phone/tablet navigation, playback, error states and accessibility.
3. Decide how playlist/provider credentials are stored securely; do not log secrets.
4. Design activation and purchase flows to comply with the then-current App Store rules.
5. Test on iPhone and iPad hardware across representative OS versions.
6. Prepare App Store Connect metadata, privacy disclosures, screenshots and reviewer instructions.
