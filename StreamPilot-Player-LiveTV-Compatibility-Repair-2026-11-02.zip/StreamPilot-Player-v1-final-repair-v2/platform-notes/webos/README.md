# LG webOS TV client — not implemented yet

Official starting point: https://webostv.developer.lge.com/develop/getting-started/developer-workflow

Future work:
1. Install webOS Studio/CLI and the simulator on a developer machine.
2. Package the built React UI as a webOS TV application and configure app metadata/ID.
3. Add TV remote key mapping and visible focus states; do not assume mouse/touch navigation is enough.
4. Implement a webOS-specific playback adapter using supported TV APIs and a real-TV capability matrix.
5. Test playback, suspend/resume, network loss, memory, and remote behavior in simulator and hardware.
6. Complete LG's self-checklist and Seller Lounge review only after the build is genuinely test-ready.

The browser prototype does not itself constitute an LG package or store submission.
