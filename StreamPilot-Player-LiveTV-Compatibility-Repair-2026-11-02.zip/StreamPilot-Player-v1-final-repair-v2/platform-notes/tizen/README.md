# Samsung Tizen TV client — not implemented yet

Official starting point: https://developer.samsung.com/smarttv/develop/tools/webapp/webapp-guide.html

Future work:
1. Install Tizen Studio and the TV extensions on a developer machine.
2. Create a TV Web application project and package the web client into it.
3. Configure the TV profile, application metadata, signing certificate and package assets.
4. Implement Tizen-compatible remote navigation and a tested playback adapter.
5. Test supported codecs/containers, lifecycle, playback recovery, focus order and memory on simulators and real TVs.
6. Complete Seller Office pretesting and certification after QA.

The browser prototype is not yet a signed Tizen application.
