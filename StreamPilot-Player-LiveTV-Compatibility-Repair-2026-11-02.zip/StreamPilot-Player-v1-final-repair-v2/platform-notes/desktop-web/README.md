# Desktop browser player

This is the first prototype target. It is intended to work across current desktop browser families, but stream compatibility depends on browser codecs, HLS/MSE support, media headers, CORS, provider policy and DRM.

Do not call the prototype a native Windows/macOS/Linux application. A browser player is the first delivery route; packaged desktop apps are a later decision based on customer demand.
