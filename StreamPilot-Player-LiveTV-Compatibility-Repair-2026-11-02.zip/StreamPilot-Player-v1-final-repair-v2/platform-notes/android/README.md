# Android TV + Android mobile — not implemented yet

Proposed approach: Kotlin + Jetpack Media3 for playback, with adaptive layouts for TV and mobile where a shared application design and store listing are suitable.

Official TV documentation: https://developer.android.com/training/tv
Media3 documentation: https://developer.android.com/media/media3
Publishing: https://developer.android.com/training/tv/publishing/distribute

Future work:
1. Create a new Android project separate from the browser prototype.
2. Set the supported Android version range and target form factors.
3. Use Media3 for playback and platform-backed secure storage for credentials/session tokens.
4. Build remote-friendly TV navigation and touch layouts for phones/tablets.
5. Validate codec/network behavior on representative Android TV and mobile devices.
6. Prepare an Android App Bundle and store metadata after policy and QA review.
