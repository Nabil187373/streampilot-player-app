# Movie media redirect: grant-scoped local compatibility

## What changed

The `/media/:grant` handler now derives its development-only public-IP redirect source from the hostname in that grant's server-held upstream movie/episode URL. The source hostname must also be present in `PLAYBACK_HOST_ALLOWLIST`. This removes the need to set one global `PLAYBACK_MEDIA_IP_REDIRECT_TRUST` hostname just to test a movie provider.

The exception remains deliberately narrow: development only; HTTP only; GET/HEAD only; a single redirect; a globally routable IP literal; same source/destination port (or destination port 80); and a pinned dispatcher for the destination connection. Private, loopback, link-local, reserved, and otherwise forbidden addresses remain rejected. Redirect destinations are not accepted as a permanent host allowlist.

## Important production boundary

This is a local development compatibility path, not the production multi-provider authorization design. `NODE_ENV=production` disables it. Production needs a provider/session-bound redirect authorization policy that records the provider origin and validated redirect relationship, with the same SSRF, DNS-rebinding, redirect-count, protocol, port, and socket-pinning protections. Do not deploy this development exception or enable HTTP with real credentials over an untrusted network.

## Verification

- Added a test for an allowlisted provider origin redirecting once to a public HTTP IP on the same port.
- Added a test proving the development exception is rejected in production.
- Backend Node suite: 107 passed, 0 failed, 1 skipped.
- TypeScript `tsc --noEmit`: passed.
- Vite/Vitest could not be run in this Linux environment because the uploaded dependency tree contains Windows native Rolldown bindings, not the Linux native binding. Run `npm.cmd test` and `npm.cmd run build` on the Windows development machine.
