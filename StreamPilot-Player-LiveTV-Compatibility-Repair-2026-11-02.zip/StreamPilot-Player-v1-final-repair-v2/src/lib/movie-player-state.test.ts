import { describe, expect, it } from 'vitest';
import { moviePlayerPresentation } from './movie-player-state';

describe('moviePlayerPresentation', () => {
  it('shows the newly selected movie immediately while authorization is loading', () => {
    expect(moviePlayerPresentation({ id: 'movie-a', name: 'Movie A' }, { grantBusy: true, source: '', playbackStatus: 'idle', grantError: '', playbackError: '' }))
      .toMatchObject({ visible: true, title: 'Movie A', loading: true, error: '' });
  });

  it('keeps the player visible and reports safe authorization or media errors', () => {
    expect(moviePlayerPresentation({ id: 'movie-a', name: 'Movie A' }, { grantBusy: false, source: '', playbackStatus: 'error', grantError: 'Session expired, re-import the playlist.', playbackError: '' }))
      .toMatchObject({ visible: true, loading: false, error: 'Session expired, re-import the playlist.' });
    expect(moviePlayerPresentation({ id: 'movie-a', name: 'Movie A' }, { grantBusy: false, source: '/media/opaque', playbackStatus: 'error', grantError: '', playbackError: 'This file format is not supported by your browser.' }))
      .toMatchObject({ visible: true, loading: false, error: 'This file format is not supported by your browser.' });
  });

  it('switches presentation to the replacement movie without retaining the prior source state', () => {
    expect(moviePlayerPresentation({ id: 'movie-b', name: 'Movie B' }, { grantBusy: true, source: '', playbackStatus: 'idle', grantError: '', playbackError: '' }))
      .toMatchObject({ title: 'Movie B', loading: true, error: '' });
  });
});
