import type { PlaylistItem } from './m3u';

export type ConnectorPlaylistResponse = { items: Array<Omit<PlaylistItem, 'url'>>; playbackNotice?: string; entryLimitReached?: boolean; vodAvailable?: boolean; seriesAvailable?: boolean };
export type PlaybackFailureCategory = 'session_expired' | 'grant_rejected' | 'host_not_allowed' | 'upstream_unreachable' | 'redirect_rejected' | 'manifest_invalid' | 'asset_rejected' | 'media_codec_error' | 'browser_network_error' | 'browser_playback_error';
export type PlaybackFailureStage = 'initial_live_stream' | 'nested_playlist' | 'segment' | 'key' | 'map' | 'redirect' | 'asset';
export type PlaybackDestinationRejection = 'hostname_not_allowlisted' | 'dns_resolution_failed' | 'resolved_address_not_allowed' | 'ip_literal_not_allowed';
export type PlaybackIpRedirectBindingStatus = 'disabled_in_production' | 'missing_or_invalid' | 'source_not_allowlisted' | 'source_mismatch' | 'destination_mismatch';
export type PlaybackUpstreamStage = 'manifest' | 'redirect' | 'asset';
export type PlaybackUpstreamCause = 'dns_failed' | 'connect_refused' | 'connect_timeout' | 'response_timeout' | 'connection_reset' | 'tls_error' | 'upstream_http_status' | 'pinned_lookup_error' | 'unknown';
export type PlaybackFailureDiagnostic = { category: PlaybackFailureCategory; stage?: PlaybackFailureStage; requestPhase?: 'manifest' | 'asset'; redirectCount?: number; ipRedirectBindingStatus?: PlaybackIpRedirectBindingStatus; upstreamStage?: PlaybackUpstreamStage; upstreamCause?: PlaybackUpstreamCause; upstreamHttpStatus?: number; upstreamRequestTarget?: 'source_host' | 'pinned_redirect_destination'; upstreamErrorName?: string; upstreamErrorCode?: string; upstreamErrorCauseCode?: string; upstreamErrorCauseCauseCode?: string; redirectDestinationIp?: string; redirectDestinationPort?: number; rejectedHostname?: string; rejectedScheme?: 'http' | 'https'; destinationRejection?: PlaybackDestinationRejection };

const playbackCategories = new Set<PlaybackFailureCategory>(['session_expired', 'grant_rejected', 'host_not_allowed', 'upstream_unreachable', 'redirect_rejected', 'manifest_invalid', 'asset_rejected', 'media_codec_error', 'browser_network_error', 'browser_playback_error']);
const playbackStages = new Set<PlaybackFailureStage>(['initial_live_stream', 'nested_playlist', 'segment', 'key', 'map', 'redirect', 'asset']);
const playbackDestinationRejections = new Set<PlaybackDestinationRejection>(['hostname_not_allowlisted', 'dns_resolution_failed', 'resolved_address_not_allowed', 'ip_literal_not_allowed']);
const playbackIpRedirectBindingStatuses = new Set<PlaybackIpRedirectBindingStatus>(['disabled_in_production', 'missing_or_invalid', 'source_not_allowlisted', 'source_mismatch', 'destination_mismatch']);
const playbackUpstreamStages = new Set<PlaybackUpstreamStage>(['manifest', 'redirect', 'asset']);
const playbackUpstreamCauses = new Set<PlaybackUpstreamCause>(['dns_failed', 'connect_refused', 'connect_timeout', 'response_timeout', 'connection_reset', 'tls_error', 'upstream_http_status', 'pinned_lookup_error', 'unknown']);
const localDiagnosticToken = /^[A-Za-z0-9_.-]{1,40}$/;

export function isPlaybackFailureCategory(value: unknown): value is PlaybackFailureCategory {
  return typeof value === 'string' && playbackCategories.has(value as PlaybackFailureCategory);
}

export function playbackFailureDiagnostic(value: unknown): PlaybackFailureDiagnostic | undefined {
  if (!value || typeof value !== 'object') return undefined;
  const source = value as { category?: unknown; stage?: unknown; requestPhase?: unknown; redirectCount?: unknown; ipRedirectBindingStatus?: unknown; upstreamStage?: unknown; upstreamCause?: unknown; upstreamHttpStatus?: unknown; upstreamRequestTarget?: unknown; upstreamErrorName?: unknown; upstreamErrorCode?: unknown; upstreamErrorCauseCode?: unknown; upstreamErrorCauseCauseCode?: unknown; redirectDestinationIp?: unknown; redirectDestinationPort?: unknown; rejectedHostname?: unknown; rejectedScheme?: unknown; destinationRejection?: unknown };
  if (!isPlaybackFailureCategory(source.category)) return undefined;
  const diagnostic: PlaybackFailureDiagnostic = { category: source.category };
  if (typeof source.stage === 'string' && playbackStages.has(source.stage as PlaybackFailureStage)) diagnostic.stage = source.stage as PlaybackFailureStage;
  if (source.requestPhase === 'manifest' || source.requestPhase === 'asset') diagnostic.requestPhase = source.requestPhase;
  if (typeof source.redirectCount === 'number' && Number.isInteger(source.redirectCount) && source.redirectCount >= 0 && source.redirectCount <= 3) diagnostic.redirectCount = source.redirectCount;
  if (typeof source.ipRedirectBindingStatus === 'string' && playbackIpRedirectBindingStatuses.has(source.ipRedirectBindingStatus as PlaybackIpRedirectBindingStatus)) diagnostic.ipRedirectBindingStatus = source.ipRedirectBindingStatus as PlaybackIpRedirectBindingStatus;
  if (typeof source.upstreamStage === 'string' && playbackUpstreamStages.has(source.upstreamStage as PlaybackUpstreamStage)) diagnostic.upstreamStage = source.upstreamStage as PlaybackUpstreamStage;
  if (typeof source.upstreamCause === 'string' && playbackUpstreamCauses.has(source.upstreamCause as PlaybackUpstreamCause)) diagnostic.upstreamCause = source.upstreamCause as PlaybackUpstreamCause;
  if (source.upstreamCause === 'upstream_http_status' && typeof source.upstreamHttpStatus === 'number' && Number.isInteger(source.upstreamHttpStatus) && source.upstreamHttpStatus >= 100 && source.upstreamHttpStatus <= 599) diagnostic.upstreamHttpStatus = source.upstreamHttpStatus;
  if (source.upstreamCause === 'unknown' && (source.upstreamRequestTarget === 'source_host' || source.upstreamRequestTarget === 'pinned_redirect_destination')) {
    diagnostic.upstreamRequestTarget = source.upstreamRequestTarget;
    for (const key of ['upstreamErrorName', 'upstreamErrorCode', 'upstreamErrorCauseCode', 'upstreamErrorCauseCauseCode'] as const) {
      if (typeof source[key] === 'string' && localDiagnosticToken.test(source[key])) diagnostic[key] = source[key];
    }
  }
  if (typeof source.redirectDestinationIp === 'string' && source.redirectDestinationIp.length <= 45 && /^(?:\d{1,3}(?:\.\d{1,3}){3}|[a-f0-9:]+)$/i.test(source.redirectDestinationIp) && typeof source.redirectDestinationPort === 'number' && Number.isInteger(source.redirectDestinationPort) && source.redirectDestinationPort >= 1 && source.redirectDestinationPort <= 65_535) {
    diagnostic.redirectDestinationIp = source.redirectDestinationIp.toLowerCase();
    diagnostic.redirectDestinationPort = source.redirectDestinationPort;
  }
  if (typeof source.rejectedHostname === 'string' && /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i.test(source.rejectedHostname)) diagnostic.rejectedHostname = source.rejectedHostname.toLowerCase();
  if (source.rejectedScheme === 'http' || source.rejectedScheme === 'https') diagnostic.rejectedScheme = source.rejectedScheme;
  if (typeof source.destinationRejection === 'string' && playbackDestinationRejections.has(source.destinationRejection as PlaybackDestinationRejection)) diagnostic.destinationRejection = source.destinationRejection as PlaybackDestinationRejection;
  return diagnostic;
}

export function browserPlaybackFailureCategory(kind: 'network' | 'media' | 'unknown'): PlaybackFailureCategory {
  if (kind === 'network') return 'browser_network_error';
  if (kind === 'media') return 'media_codec_error';
  return 'browser_playback_error';
}

const messages: Record<string, string> = {
  invalid_request: 'Check the provider server URL and sign-in details, then try again.',
  http_not_allowed: 'This provider connection was blocked by the current transport policy. Check the provider URL and deployment configuration.',
  destination_not_allowed: 'That provider server address is not permitted by this connector.',
  provider_unreachable: 'The provider server could not be reached.',
  provider_timeout: 'The provider server took too long to respond.',
  provider_http_error: 'The provider returned an HTTP error.',
  provider_response_html: 'The provider returned an HTML page instead of a playlist.',
  provider_response_json: 'The provider returned JSON instead of a playlist.',
  provider_response_unknown: 'The provider response was not a readable M3U playlist.',
  provider_response_m3u_wrong_content_type: 'The provider returned an M3U playlist with an unsupported content type.',
  playlist_too_large: 'The provider playlist is too large to import safely.',
  playlist_invalid: 'The provider returned no readable playlist entries.',
  playback_not_configured: 'Secure provider playback is not configured for an approved playback host.',
  playback_unauthorized: 'Session expired. Re-import the playlist and try again.',
  playback_item_not_found: 'That provider item is not available for playback.',
  rate_limited: 'Too many connector requests were made. Try again shortly.',
  internal_error: 'The playlist connector is temporarily unavailable. Try again later.',
  connector_unavailable: 'The playlist connector returned an invalid or empty response. Ensure the same-origin server is running, then try again.',
};

export class ConnectorResponseError extends Error {
  constructor(code: string, diagnostic?: unknown) {
    const safeDiagnostic = formatDiagnostic(diagnostic);
    super(`${messages[code] || messages.internal_error}${safeDiagnostic ? ` ${safeDiagnostic}` : ''}`);
    this.name = 'ConnectorResponseError';
  }
}

function formatDiagnostic(value: unknown) {
  if (!value || typeof value !== 'object') return '';
  const diagnostic = value as { providerStatus?: unknown; responseCategory?: unknown; importStage?: unknown; importAction?: unknown };
  const parts: string[] = [];
  if (typeof diagnostic.providerStatus === 'number' && Number.isInteger(diagnostic.providerStatus) && diagnostic.providerStatus >= 100 && diagnostic.providerStatus <= 599) parts.push(`Provider HTTP status: ${diagnostic.providerStatus}.`);
  if (typeof diagnostic.responseCategory === 'string' && ['html', 'json', 'm3u', 'unknown', 'empty', 'internal'].includes(diagnostic.responseCategory)) parts.push(`Response category: ${diagnostic.responseCategory}.`);
  if (diagnostic.importStage === 'network' || diagnostic.importStage === 'playlist_stream' || diagnostic.importStage === 'live_json') parts.push(`Import stage: ${diagnostic.importStage}.`);
  if (diagnostic.importAction === 'get_live_categories' || diagnostic.importAction === 'get_live_streams') parts.push(`Xtream action: ${diagnostic.importAction}.`);
  return parts.join(' ');
}

export async function readConnectorResponse(response: Response): Promise<ConnectorPlaylistResponse> {
  const contentType = response.headers.get('content-type')?.toLowerCase() || '';
  const body = await response.text();
  if (!contentType.includes('application/json') || !body.trim()) throw new ConnectorResponseError('connector_unavailable');
  let parsed: unknown;
  try { parsed = JSON.parse(body); } catch { throw new ConnectorResponseError('connector_unavailable'); }
  if (!parsed || typeof parsed !== 'object') throw new ConnectorResponseError('connector_unavailable');
  const payload = parsed as { ok?: unknown; error?: { code?: unknown; diagnostic?: unknown }; items?: unknown; playbackNotice?: unknown; entryLimitReached?: unknown; vodAvailable?: unknown; seriesAvailable?: unknown };
  if (!response.ok || payload.ok !== true) throw new ConnectorResponseError(typeof payload.error?.code === 'string' ? payload.error.code : 'internal_error', payload.error?.diagnostic);
  if (!Array.isArray(payload.items)) throw new ConnectorResponseError('connector_unavailable');
  return {
    items: payload.items as Array<Omit<PlaylistItem, 'url'>>,
    playbackNotice: typeof payload.playbackNotice === 'string' ? payload.playbackNotice : undefined,
    entryLimitReached: typeof payload.entryLimitReached === 'boolean' ? payload.entryLimitReached : undefined,
    vodAvailable: payload.vodAvailable === true,
    seriesAvailable: payload.seriesAvailable === true,
  };
}

export async function readPlaybackGrantResponse(response: Response): Promise<string> {
  const contentType = response.headers.get('content-type')?.toLowerCase() || '';
  const body = await response.text();
  if (!contentType.includes('application/json') || !body.trim()) throw new ConnectorResponseError('connector_unavailable');
  let parsed: unknown;
  try { parsed = JSON.parse(body); } catch { throw new ConnectorResponseError('connector_unavailable'); }
  if (!parsed || typeof parsed !== 'object') throw new ConnectorResponseError('connector_unavailable');
  const payload = parsed as { ok?: unknown; manifestPath?: unknown; error?: { code?: unknown; diagnostic?: unknown } };
  if (!response.ok || payload.ok !== true) throw new ConnectorResponseError(typeof payload.error?.code === 'string' ? payload.error.code : 'internal_error', payload.error?.diagnostic);
  if (typeof payload.manifestPath !== 'string' || !/^\/api\/playback\/[A-Za-z0-9_-]+\/manifest\.m3u8$/.test(payload.manifestPath)) throw new ConnectorResponseError('connector_unavailable');
  return payload.manifestPath;
}

export async function readMovieGrantResponse(response: Response): Promise<string> {
  const contentType = response.headers.get('content-type')?.toLowerCase() || '';
  const body = await response.text();
  if (!contentType.includes('application/json') || !body.trim()) throw new ConnectorResponseError('connector_unavailable');
  let parsed: unknown;
  try { parsed = JSON.parse(body); } catch { throw new ConnectorResponseError('connector_unavailable'); }
  if (!parsed || typeof parsed !== 'object') throw new ConnectorResponseError('connector_unavailable');
  const payload = parsed as { ok?: unknown; mediaPath?: unknown; error?: { code?: unknown; diagnostic?: unknown } };
  if (!response.ok || payload.ok !== true) throw new ConnectorResponseError(typeof payload.error?.code === 'string' ? payload.error.code : 'internal_error', payload.error?.diagnostic);
  if (typeof payload.mediaPath !== 'string' || !/^\/media\/[A-Za-z0-9_-]+$/.test(payload.mediaPath)) throw new ConnectorResponseError('connector_unavailable');
  return payload.mediaPath;
}

export async function readPlaybackFailureCategory(response: Response): Promise<PlaybackFailureCategory | undefined> {
  return (await readPlaybackFailureDiagnostic(response))?.category;
}

export async function readPlaybackFailureDiagnostic(response: Response): Promise<PlaybackFailureDiagnostic | undefined> {
  const contentType = response.headers.get('content-type')?.toLowerCase() || '';
  if (!contentType.includes('application/json')) return undefined;
  let parsed: unknown;
  try { parsed = JSON.parse(await response.text()); } catch { return undefined; }
  const diagnostic = (parsed as { error?: { diagnostic?: { playbackCategory?: unknown; playbackStage?: unknown; requestPhase?: unknown; redirectCount?: unknown; ipRedirectBindingStatus?: unknown; upstreamStage?: unknown; upstreamCause?: unknown; upstreamHttpStatus?: unknown; upstreamRequestTarget?: unknown; upstreamErrorName?: unknown; upstreamErrorCode?: unknown; upstreamErrorCauseCode?: unknown; upstreamErrorCauseCauseCode?: unknown; redirectDestinationIp?: unknown; redirectDestinationPort?: unknown; rejectedHostname?: unknown; rejectedScheme?: unknown; destinationRejection?: unknown } } })?.error?.diagnostic;
  return playbackFailureDiagnostic({ category: diagnostic?.playbackCategory, stage: diagnostic?.playbackStage, requestPhase: diagnostic?.requestPhase, redirectCount: diagnostic?.redirectCount, ipRedirectBindingStatus: diagnostic?.ipRedirectBindingStatus, upstreamStage: diagnostic?.upstreamStage, upstreamCause: diagnostic?.upstreamCause, upstreamHttpStatus: diagnostic?.upstreamHttpStatus, upstreamRequestTarget: diagnostic?.upstreamRequestTarget, upstreamErrorName: diagnostic?.upstreamErrorName, upstreamErrorCode: diagnostic?.upstreamErrorCode, upstreamErrorCauseCode: diagnostic?.upstreamErrorCauseCode, upstreamErrorCauseCauseCode: diagnostic?.upstreamErrorCauseCauseCode, redirectDestinationIp: diagnostic?.redirectDestinationIp, redirectDestinationPort: diagnostic?.redirectDestinationPort, rejectedHostname: diagnostic?.rejectedHostname, rejectedScheme: diagnostic?.rejectedScheme, destinationRejection: diagnostic?.destinationRejection });
}

export function playbackDiagnosticPath(manifestPath: string): string | undefined {
  const match = manifestPath.match(/^\/api\/playback\/([A-Za-z0-9_-]+)\/manifest\.m3u8$/);
  return match ? `/api/playback/${match[1]}/diagnostic` : undefined;
}

export function movieDiagnosticPath(mediaPath: string): string | undefined {
  const match = mediaPath.match(/^\/media\/([A-Za-z0-9_-]+)$/);
  return match ? `/media/${match[1]}/diagnostic` : undefined;
}

export function playbackFailureMessage(diagnostic?: PlaybackFailureDiagnostic | PlaybackFailureCategory): string {
  const value = typeof diagnostic === 'string' ? { category: diagnostic } : diagnostic;
  const browserFailureMessage = value?.category === 'browser_network_error'
    ? ' The browser could not fetch the playback resource and the server did not provide a more specific diagnostic.'
    : value?.category === 'browser_playback_error'
      ? ' The browser reported a playback failure, but it did not identify whether the media format or network request was the cause.'
      : value?.category === 'media_codec_error'
        ? ' The browser media pipeline reported a decoding or format error.'
        : '';
  const redirectNeedsPublicHostname = value?.category === 'host_not_allowed' && value.stage === 'redirect' && value.destinationRejection === 'ip_literal_not_allowed';
  const localDestinationMessage = value?.destinationRejection === 'hostname_not_allowlisted' ? ' Validation: hostname is not in the explicit allowlist.'
    : value?.destinationRejection === 'dns_resolution_failed' ? ' Validation: DNS resolution failed.'
      : value?.destinationRejection === 'resolved_address_not_allowed' ? ' Validation: the resolved address is private or reserved.'
        : value?.destinationRejection === 'ip_literal_not_allowed' ? ' Validation: IP-literal destinations are not allowed.' : '';
  const bindingMessage = value?.ipRedirectBindingStatus === 'disabled_in_production' ? ' Compatibility binding is disabled in production.'
    : value?.ipRedirectBindingStatus === 'missing_or_invalid' ? ' Compatibility binding is missing or invalid in this server process.'
      : value?.ipRedirectBindingStatus === 'source_not_allowlisted' ? ' Compatibility binding source is not in the playback allowlist.'
        : value?.ipRedirectBindingStatus === 'source_mismatch' ? ' Compatibility binding source does not match this redirect.'
          : value?.ipRedirectBindingStatus === 'destination_mismatch' ? ' Compatibility binding destination does not match this redirect.' : '';
  const upstreamFailureMessage = value?.upstreamCause
    ? ` Local diagnostic: stage=${value.upstreamStage ?? 'unknown'}, cause=${value.upstreamCause}${value.upstreamCause === 'upstream_http_status' && value.upstreamHttpStatus ? `, status=${value.upstreamHttpStatus}` : ''}.`
    : '';
  const unknownUpstreamDetail = value?.upstreamCause === 'unknown' && value.upstreamRequestTarget
    ? ` Local diagnostic detail: target=${value.upstreamRequestTarget}, name=${value.upstreamErrorName ?? 'other'}, code=${value.upstreamErrorCode ?? 'other'}, causeCode=${value.upstreamErrorCauseCode ?? 'other'}, nestedCauseCode=${value.upstreamErrorCauseCauseCode ?? 'other'}.`
    : '';
  const redirectDestinationMessage = value?.redirectDestinationIp && value.redirectDestinationPort
    ? ` Local development redirect destination: ${value.redirectDestinationIp.includes(':') ? `[${value.redirectDestinationIp}]` : value.redirectDestinationIp}:${value.redirectDestinationPort}.`
    : '';
  return value
    ? `Playback failed: ${value.category}.${browserFailureMessage}${value.stage ? ` Stage: ${value.stage}.` : ''}${value.requestPhase ? ` Request: ${value.requestPhase}.` : ''}${value.redirectCount !== undefined ? ` Redirects followed: ${value.redirectCount}.` : ''}${value.rejectedScheme ? ` Rejected scheme: ${value.rejectedScheme}.` : ''}${value.rejectedHostname ? ` Rejected host: ${value.rejectedHostname}.` : ''}${localDestinationMessage}${bindingMessage}${upstreamFailureMessage}${unknownUpstreamDetail}${redirectDestinationMessage}${redirectNeedsPublicHostname ? ' The provider must supply a stable public DNS hostname and protocol for this redirect target.' : ''}`
    : 'This stream could not be played in this browser. It may be unavailable, unsupported, or blocked by its source.';
}
