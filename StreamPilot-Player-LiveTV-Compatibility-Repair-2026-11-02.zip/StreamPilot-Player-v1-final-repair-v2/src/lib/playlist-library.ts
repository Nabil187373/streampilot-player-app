import type { PlaylistItem } from './m3u';

export type PlaylistCategory = 'all' | 'favorites' | 'recent' | string;

export type LocalPlaylist = {
  id: string;
  name: string;
  items: PlaylistItem[];
  selectedItemId?: string;
  favoriteIds: string[];
  recentIds: string[];
  activeCategory: PlaylistCategory;
};

export type PlaylistLibrary = {
  playlists: LocalPlaylist[];
  activePlaylistId?: string;
  nextPlaylistNumber: number;
};

export function createPlaylistLibrary(): PlaylistLibrary {
  return { playlists: [], activePlaylistId: undefined, nextPlaylistNumber: 1 };
}

export function activePlaylist(library: PlaylistLibrary): LocalPlaylist | undefined {
  return library.playlists.find((playlist) => playlist.id === library.activePlaylistId);
}

function displayName(library: PlaylistLibrary, requestedName: string): string {
  const base = requestedName.trim() || 'Untitled playlist';
  const names = new Set(library.playlists.map((playlist) => playlist.name.toLocaleLowerCase()));
  if (!names.has(base.toLocaleLowerCase())) return base;
  let suffix = 2;
  while (names.has(`${base} (${suffix})`.toLocaleLowerCase())) suffix += 1;
  return `${base} (${suffix})`;
}

function replaceActive(library: PlaylistLibrary, update: (playlist: LocalPlaylist) => LocalPlaylist): PlaylistLibrary {
  if (!library.activePlaylistId) return library;
  return {
    ...library,
    playlists: library.playlists.map((playlist) => playlist.id === library.activePlaylistId ? update(playlist) : playlist),
  };
}

export function addLocalPlaylist(library: PlaylistLibrary, requestedName: string, items: PlaylistItem[]): PlaylistLibrary {
  const id = `local-${library.nextPlaylistNumber}`;
  const playlist: LocalPlaylist = {
    id,
    name: displayName(library, requestedName),
    items,
    selectedItemId: items[0]?.id,
    favoriteIds: [],
    recentIds: [],
    activeCategory: 'all',
  };
  return {
    playlists: [...library.playlists, playlist],
    activePlaylistId: id,
    nextPlaylistNumber: library.nextPlaylistNumber + 1,
  };
}

export function switchPlaylist(library: PlaylistLibrary, playlistId: string): PlaylistLibrary {
  return library.playlists.some((playlist) => playlist.id === playlistId)
    ? { ...library, activePlaylistId: playlistId }
    : library;
}

export function setActiveCategory(library: PlaylistLibrary, category: PlaylistCategory): PlaylistLibrary {
  return replaceActive(library, (playlist) => ({ ...playlist, activeCategory: category }));
}

export function togglePlaylistFavorite(library: PlaylistLibrary, itemId: string): PlaylistLibrary {
  return replaceActive(library, (playlist) => {
    if (!playlist.items.some((item) => item.id === itemId)) return playlist;
    const favoriteIds = playlist.favoriteIds.includes(itemId)
      ? playlist.favoriteIds.filter((id) => id !== itemId)
      : [...playlist.favoriteIds, itemId];
    return { ...playlist, favoriteIds };
  });
}

export function selectPlaylistItem(library: PlaylistLibrary, itemId: string): PlaylistLibrary {
  return replaceActive(library, (playlist) => {
    if (!playlist.items.some((item) => item.id === itemId)) return playlist;
    return {
      ...playlist,
      selectedItemId: itemId,
      recentIds: [itemId, ...playlist.recentIds.filter((id) => id !== itemId)].slice(0, 24),
    };
  });
}
