export type PlaylistItem = {
  id: string;
  name: string;
  url: string;
  group: string;
  logo?: string;
  tvgId?: string;
  kind: 'live' | 'movie' | 'series' | 'unknown';
  playbackBlocked?: boolean;
  /** Preserved non-secret playlist attributes and player directives. */
  metadata?: Record<string, string>;
};

function readAttribute(line: string, attribute: string): string | undefined {
  const aliases: Record<string, string[]> = {
    'group-title': ['group-title', 'group_title'],
    'tvg-id': ['tvg-id', 'tvg_id'],
    'tvg-logo': ['tvg-logo', 'tvg_logo'],
    'tvg-name': ['tvg-name', 'tvg_name'],
  };
  for (const candidate of aliases[attribute] ?? [attribute]) {
    const escaped = candidate.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');
    const match = line.match(new RegExp(`(?:^|\\s)${escaped}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s,]+))`, 'i'));
    const value = (match?.[1] ?? match?.[2] ?? match?.[3])?.trim();
    if (value) return value;
  }
  return undefined;
}

function readExtinfAttributes(line: string): Record<string, string> {
  const values: Record<string, string> = {};
  const expression = /([a-z0-9_-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,]+))/gi;
  for (const match of line.matchAll(expression)) {
    const key = match[1].toLowerCase();
    if (!['group-title', 'group_title', 'tvg-id', 'tvg_id', 'tvg-logo', 'tvg_logo', 'tvg-name', 'tvg_name'].includes(key)) {
      values[`extinf.${key}`] = (match[2] ?? match[3] ?? match[4] ?? '').trim();
    }
  }
  return values;
}


/** Find the EXTINF title separator without mistaking commas inside quoted attributes for it. */
function findExtinfTitleComma(line: string): number {
  let quote: '"' | "'" | undefined;
  for (let index = line.indexOf(':') + 1; index < line.length; index += 1) {
    const char = line[index];
    if (quote) {
      if (char === quote) quote = undefined;
      continue;
    }
    if (char === '"' || char === "'") {
      quote = char;
      continue;
    }
    if (char === ',') return index;
  }
  return -1;
}

function inferKind(group: string, name: string): PlaylistItem['kind'] {
  const haystack = `${group} ${name}`.toLowerCase();
  if (/series|tv show|season|episode|\bs\d{1,2}\s*e\d{1,3}\b|\b\d{1,2}x\d{1,3}\b/.test(haystack)) return 'series';
  if (/movie|movies|film|cinema|vod/.test(haystack)) return 'movie';
  if (/live|news|sport|sports|documentary|music|kids|radio/.test(haystack)) return 'live';
  return 'unknown';
}

/**
 * Parses bounded M3U text without splitting the entire file into an array.
 * EXTINF's title begins after the FIRST comma; later commas are part of the title.
 */
export function parseM3U(input: string, { maxEntries = 20_000 }: { maxEntries?: number } = {}): PlaylistItem[] {
  if (!Number.isSafeInteger(maxEntries) || maxEntries < 1) throw new RangeError('maxEntries must be a positive safe integer');
  const source = input.replace(/^\uFEFF/, '');
  const items: PlaylistItem[] = [];
  let pending: Omit<PlaylistItem, 'id' | 'url' | 'kind'> | undefined;
  let pendingGroup: string | undefined;
  let lineStart = 0;

  const processLine = (rawLine: string) => {
    const line = rawLine.endsWith('\r') ? rawLine.slice(0, -1).trim() : rawLine.trim();
    if (!line) return;
    if (/^#EXTINF\s*:/i.test(line)) {
      const commaIndex = findExtinfTitleComma(line);
      const title = commaIndex >= 0 ? line.slice(commaIndex + 1).trim() : '';
      const group = readAttribute(line, 'group-title') ?? pendingGroup ?? 'Uncategorized';
      const preservedAttributes = readExtinfAttributes(line);
      pending = {
        name: title || readAttribute(line, 'tvg-name') || 'Untitled channel',
        group,
        logo: readAttribute(line, 'tvg-logo'),
        tvgId: readAttribute(line, 'tvg-id'),
        ...(Object.keys(preservedAttributes).length ? { metadata: preservedAttributes } : {}),
      };
      pendingGroup = undefined;
      return;
    }
    if (/^#EXTGRP\s*:/i.test(line)) {
      const group = line.slice(line.indexOf(':') + 1).trim();
      if (pending) pending.group = group || pending.group;
      else pendingGroup = group || undefined;
      return;
    }
    if (/^#EXTVLCOPT:/i.test(line) || /^#KODIPROP:/i.test(line)) {
      if (pending) {
        const prefix = /^#EXTVLCOPT:/i.test(line) ? 'vlc' : 'kodi';
        const directive = line.slice(line.indexOf(':') + 1).trim();
        const separator = directive.indexOf('=');
        if (separator > 0) {
          const key = directive.slice(0, separator).trim().toLowerCase();
          const value = directive.slice(separator + 1).trim();
          if (key && value && key.length <= 100 && value.length <= 2048) {
            pending.metadata = { ...(pending.metadata ?? {}), [`${prefix}.${key}`]: value };
          }
        }
      }
      return;
    }
    // HLS EXT-X tags and unknown comments are metadata, never stream URLs.
    if (line.startsWith('#')) return;
    if (pending && /^(https?|rtsp|rtmp|udp):\/\//i.test(line)) {
      const identity = `${pending.name}|${line}|${items.length}`;
      items.push({ ...pending, id: stableId(identity), url: line, kind: inferKind(pending.group, pending.name) });
      pending = undefined;
    }
  };

  for (let index = 0; index <= source.length && items.length < maxEntries; index += 1) {
    if (index !== source.length && source.charCodeAt(index) !== 10) continue;
    processLine(source.slice(lineStart, index));
    lineStart = index + 1;
  }
  return items;
}

function stableId(value: string): string {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}
