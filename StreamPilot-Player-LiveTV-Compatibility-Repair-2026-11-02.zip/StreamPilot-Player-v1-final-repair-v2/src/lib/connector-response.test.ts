import { describe, expect, it } from 'vitest';
import { browserPlaybackFailureCategory, ConnectorResponseError, playbackFailureDiagnostic, playbackFailureMessage, readConnectorResponse, readPlaybackFailureCategory, readPlaybackFailureDiagnostic } from './connector-response';

describe('readConnectorResponse', () => {
  it('reads a valid connector response', async () => {
    const response = new Response(JSON.stringify({ ok: true, items: [{ id: '1', name: 'News', group: 'Test', kind: 'live', playbackBlocked: true }] }), { status: 200, headers: { 'content-type': 'application/json' } });
    await expect(readConnectorResponse(response)).resolves.toMatchObject({ items: [{ name: 'News' }] });
  });

  it('fails safely for an empty response body', async () => {
    await expect(readConnectorResponse(new Response('', { status: 502, headers: { 'content-type': 'application/json' } }))).rejects.toBeInstanceOf(ConnectorResponseError);
  });

  it('fails safely for malformed JSON', async () => {
    await expect(readConnectorResponse(new Response('<html>upstream error</html>', { status: 502, headers: { 'content-type': 'text/html' } }))).rejects.toBeInstanceOf(ConnectorResponseError);
  });

  it('maps a JSON error code without exposing a server message', async () => {
    const response = new Response(JSON.stringify({ ok: false, error: { code: 'provider_timeout', message: 'internal upstream details', diagnostic: { importStage: 'network', raw: 'secret' } } }), { status: 504, headers: { 'content-type': 'application/json' } });
    await expect(readConnectorResponse(response)).rejects.toThrow('took too long to respond. Import stage: network.');
  });

  it('identifies which Xtream live API action timed out without exposing credentials', async () => {
    const response = new Response(JSON.stringify({ ok: false, error: { code: 'provider_timeout', diagnostic: { importStage: 'live_json', importAction: 'get_live_streams', username: 'secret-user', password: 'secret-pass' } } }), { status: 504, headers: { 'content-type': 'application/json' } });
    await expect(readConnectorResponse(response)).rejects.toThrow('took too long to respond. Import stage: live_json. Xtream action: get_live_streams.');
    await expect(readConnectorResponse(new Response(JSON.stringify({ ok: false, error: { code: 'provider_timeout', diagnostic: { importStage: 'live_json', importAction: 'secret-action' } } }), { status: 504, headers: { 'content-type': 'application/json' } }))).rejects.toThrow('Import stage: live_json.');
  });

  it('shows only allowlisted status diagnostics', async () => {
    const response = new Response(JSON.stringify({ ok: false, error: { code: 'provider_http_error', diagnostic: { providerStatus: 401, responseCategory: 'html', raw: 'secret response' } } }), { status: 502, headers: { 'content-type': 'application/json' } });
    await expect(readConnectorResponse(response)).rejects.toThrow('Provider HTTP status: 401. Response category: html.');
  });

  it('accepts only fixed playback failure categories', async () => {
    const known = new Response(JSON.stringify({ ok: false, error: { diagnostic: { playbackCategory: 'host_not_allowed', raw: 'private text' } } }), { headers: { 'content-type': 'application/json' } });
    await expect(readPlaybackFailureCategory(known)).resolves.toBe('host_not_allowed');
    const unknown = new Response(JSON.stringify({ ok: false, error: { diagnostic: { playbackCategory: 'https://secret.example/?token=value' } } }), { headers: { 'content-type': 'application/json' } });
    await expect(readPlaybackFailureCategory(unknown)).resolves.toBeUndefined();
  });

  it('keeps only allowlisted local playback diagnostics', async () => {
    const response = new Response(JSON.stringify({ ok: false, error: { diagnostic: { playbackCategory: 'host_not_allowed', playbackStage: 'nested_playlist', requestPhase: 'asset', redirectCount: 1, ipRedirectBindingStatus: 'destination_mismatch', rejectedHostname: 'cdn.example', rejectedScheme: 'https', destinationRejection: 'hostname_not_allowlisted', raw: 'secret response' } } }), { headers: { 'content-type': 'application/json' } });
    await expect(readPlaybackFailureDiagnostic(response)).resolves.toEqual({ category: 'host_not_allowed', stage: 'nested_playlist', requestPhase: 'asset', redirectCount: 1, ipRedirectBindingStatus: 'destination_mismatch', rejectedHostname: 'cdn.example', rejectedScheme: 'https', destinationRejection: 'hostname_not_allowlisted' });
  });

  it('rejects malformed local phase and redirect-count diagnostics', () => {
    expect(playbackFailureDiagnostic({ category: 'host_not_allowed', requestPhase: 'https://secret.example', redirectCount: 4 })).toEqual({ category: 'host_not_allowed' });
  });

  it('gives a safe action when a redirect target has no displayable DNS hostname', () => {
    const message = playbackFailureMessage({ category: 'host_not_allowed', stage: 'redirect', requestPhase: 'asset', redirectCount: 1, ipRedirectBindingStatus: 'destination_mismatch', rejectedScheme: 'http', destinationRejection: 'ip_literal_not_allowed' });
    expect(message).toContain('stable public DNS hostname and protocol');
    expect(message).toContain('IP-literal destinations are not allowed');
    expect(message).toContain('Request: asset. Redirects followed: 1.');
    expect(message).toContain('Compatibility binding destination does not match');
    expect(message).not.toContain('203.0.113.42');
    expect(message).not.toContain('token=');
  });

  it('does not guess that a redirect needs a DNS hostname when diagnostics omit the rejection reason', () => {
    const message = playbackFailureMessage({ category: 'host_not_allowed', stage: 'redirect', requestPhase: 'manifest' });
    expect(message).not.toContain('stable public DNS hostname');
  });

  it('accepts a bounded local-only public redirect address and port, not URL data', () => {
    const diagnostic = playbackFailureDiagnostic({ category: 'host_not_allowed', stage: 'redirect', requestPhase: 'manifest', redirectDestinationIp: '93.184.216.34', redirectDestinationPort: 8080, path: '/secret', query: 'token=value' });
    expect(diagnostic).toEqual({ category: 'host_not_allowed', stage: 'redirect', requestPhase: 'manifest', redirectDestinationIp: '93.184.216.34', redirectDestinationPort: 8080 });
    const message = playbackFailureMessage(diagnostic);
    expect(message).toContain('Local development redirect destination: 93.184.216.34:8080.');
    expect(message).not.toContain('/secret');
    expect(message).not.toContain('token=value');
  });

  it('renders only fixed upstream-attempt categories', () => {
    const diagnostic = playbackFailureDiagnostic({ category: 'upstream_unreachable', stage: 'redirect', requestPhase: 'manifest', redirectCount: 1, upstreamStage: 'redirect', upstreamCause: 'connect_timeout', raw: 'secret upstream failure' });
    expect(diagnostic).toEqual({ category: 'upstream_unreachable', stage: 'redirect', requestPhase: 'manifest', redirectCount: 1, upstreamStage: 'redirect', upstreamCause: 'connect_timeout' });
    const message = playbackFailureMessage(diagnostic);
    expect(message).toContain('stage=redirect, cause=connect_timeout');
    expect(message).not.toContain('secret upstream failure');
  });

  it('keeps browser network failures distinct from decoding failures without exposing raw errors', () => {
    expect(browserPlaybackFailureCategory('network')).toBe('browser_network_error');
    expect(browserPlaybackFailureCategory('media')).toBe('media_codec_error');
    expect(browserPlaybackFailureCategory('unknown')).toBe('browser_playback_error');
    expect(playbackFailureMessage('browser_network_error')).toContain('could not fetch the playback resource');
    expect(playbackFailureMessage('media_codec_error')).toContain('media pipeline reported a decoding or format error');
    expect(playbackFailureMessage('browser_playback_error')).toContain('did not identify whether the media format or network request was the cause');
    expect(playbackFailureMessage('browser_network_error')).not.toContain('Failed to fetch');
  });
});
