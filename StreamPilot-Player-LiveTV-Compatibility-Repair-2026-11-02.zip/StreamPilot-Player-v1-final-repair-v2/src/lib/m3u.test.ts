import { describe, expect, it } from 'vitest';
import { parseM3U } from './m3u';

describe('parseM3U', () => {
  it('reads names, groups, logos, ids, and URLs', () => {
    const source = `#EXTM3U\n#EXTINF:-1 tvg-id="news.one" tvg-logo="https://cdn.example/logo.png" group-title="News",Example News\nhttps://media.example/live.m3u8`;
    expect(parseM3U(source)).toEqual([
      expect.objectContaining({
        name: 'Example News',
        group: 'News',
        logo: 'https://cdn.example/logo.png',
        tvgId: 'news.one',
        url: 'https://media.example/live.m3u8',
        kind: 'live',
      }),
    ]);
  });

  it('ignores invalid rows and handles Windows line endings', () => {
    const source = '#EXTM3U\r\n#EXTINF:-1 group-title="Movies",Sample film\r\nnot-a-url\r\nhttps://media.example/movie.mp4';
    expect(parseM3U(source)).toHaveLength(1);
    expect(parseM3U(source)[0].kind).toBe('movie');
  });

  it('returns an empty list for headers with no entries', () => {
    expect(parseM3U('#EXTM3U\n# this playlist is empty')).toEqual([]);
  });

  it('ignores malformed entries and bounds large local imports without splitting every line first', () => {
    const rows = ['#EXTM3U', '#EXTINF:-1,Missing URL', 'not-a-url'];
    for (let index = 0; index < 20_001; index += 1) rows.push(`#EXTINF:-1 group-title="News",Channel ${index}`, `https://media.example/${index}.m3u8`);
    const items = parseM3U(rows.join('\n'));
    expect(items).toHaveLength(20_000);
    expect(items[0].name).toBe('Channel 0');
    expect(items.at(-1)?.name).toBe('Channel 19999');
  });
});


describe('M3U compatibility', () => {
  it('preserves commas in channel titles and reads single-quoted attributes', () => {
    const items = parseM3U(`#EXTM3U\n#EXTINF:-1 tvg-id='id.1' tvg-logo='https://cdn.example/logo.png' group-title='News, World',BBC News, London\nhttps://media.example/live.m3u8`);
    expect(items[0]).toMatchObject({ name: 'BBC News, London', group: 'News, World', tvgId: 'id.1', logo: 'https://cdn.example/logo.png' });
  });

  it('uses EXTGRP when group-title is absent and applies it to the following entry', () => {
    const items = parseM3U(`#EXTM3U\n#EXTGRP:Documentaries\n#EXTINF:-1,Wildlife, Planet Earth\nhttps://media.example/doc.m3u8`);
    expect(items[0]).toMatchObject({ name: 'Wildlife, Planet Earth', group: 'Documentaries' });
  });

  it('rejects invalid entry limits', () => {
    expect(() => parseM3U('#EXTM3U', { maxEntries: 0 })).toThrow(RangeError);
  });
});

describe('series entry detection', () => {
  it('recognizes common season and episode title patterns even when the group is generic', () => {
    const items = parseM3U(`#EXTM3U\n#EXTINF:-1 group-title="Entertainment",Example Show S01E02 - The Arrival\nhttps://media.example/episode-102.mp4\n#EXTINF:-1 group-title="TV",Another Show 2x03\nhttps://media.example/episode-203.mp4`);
    expect(items.map((item) => item.kind)).toEqual(['series', 'series']);
  });
});


describe('extended playlist metadata', () => {
  it('normalizes underscore aliases and preserves VLC/Kodi directives without applying them as network headers', () => {
    const [item] = parseM3U(`#EXTM3U
#EXTINF:-1 tvg_id="news.one" tvg_logo="https://cdn.example/logo.png" group_title="News" custom-attr="custom",Example News
#EXTVLCOPT:http-user-agent=ExamplePlayer/1.0
#KODIPROP:inputstream.adaptive.manifest_type=hls
https://media.example/live.m3u8`);
    expect(item).toMatchObject({
      name: 'Example News',
      group: 'News',
      tvgId: 'news.one',
      logo: 'https://cdn.example/logo.png',
      metadata: {
        'extinf.custom-attr': 'custom',
        'vlc.http-user-agent': 'ExamplePlayer/1.0',
        'kodi.inputstream.adaptive.manifest_type': 'hls',
      },
    });
  });
});
