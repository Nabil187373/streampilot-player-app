import { describe, expect, it } from 'vitest';
import { activePlaylist, addLocalPlaylist, createPlaylistLibrary, selectPlaylistItem, setActiveCategory, switchPlaylist, togglePlaylistFavorite } from './playlist-library';
import type { PlaylistItem } from './m3u';

const items: PlaylistItem[] = [
  { id: 'one', name: 'News One', url: 'https://media.example/one.m3u8', group: 'News', kind: 'live' },
  { id: 'two', name: 'Sport Two', url: 'https://media.example/two.m3u8', group: 'Sport', kind: 'live' },
];

describe('playlist library', () => {
  it('adds playlists with stable IDs and makes the new playlist active', () => {
    const library = addLocalPlaylist(createPlaylistLibrary(), 'Provider', items);
    expect(activePlaylist(library)).toMatchObject({ id: 'local-1', name: 'Provider', selectedItemId: 'one' });
  });

  it('keeps Xtream live metadata in the active playlist consumed by Live TV', () => {
    const xtreamItems: PlaylistItem[] = [
      { id: 'provider-0', name: 'Provider News', url: '', group: 'News', kind: 'live', playbackBlocked: true },
      { id: 'provider-1', name: 'Provider Sport', url: '', group: 'Sport', kind: 'live', playbackBlocked: true },
    ];
    const library = addLocalPlaylist(createPlaylistLibrary(), 'Provider playlist', xtreamItems);
    expect(activePlaylist(library)).toMatchObject({
      name: 'Provider playlist',
      selectedItemId: 'provider-0',
      items: xtreamItems,
    });
  });

  it('disambiguates duplicate display names without merging playlists', () => {
    const first = addLocalPlaylist(createPlaylistLibrary(), 'Provider', items);
    const second = addLocalPlaylist(first, 'provider', items);
    expect(second.playlists.map((playlist) => playlist.name)).toEqual(['Provider', 'provider (2)']);
  });

  it('switches playlists while retaining independent category, favorite, selection, and history state', () => {
    let library = addLocalPlaylist(createPlaylistLibrary(), 'A', items);
    library = togglePlaylistFavorite(library, 'two');
    library = setActiveCategory(library, 'Sport');
    library = selectPlaylistItem(library, 'two');
    library = addLocalPlaylist(library, 'B', [{ ...items[0], id: 'other' }]);
    library = selectPlaylistItem(library, 'other');
    library = switchPlaylist(library, 'local-1');
    expect(activePlaylist(library)).toMatchObject({ activeCategory: 'Sport', selectedItemId: 'two', favoriteIds: ['two'], recentIds: ['two'] });
    library = switchPlaylist(library, 'local-2');
    expect(activePlaylist(library)).toMatchObject({ selectedItemId: 'other', favoriteIds: [], recentIds: ['other'] });
  });

  it('does not change state for an unknown playlist or item', () => {
    const library = addLocalPlaylist(createPlaylistLibrary(), 'A', items);
    expect(switchPlaylist(library, 'missing')).toBe(library);
    expect(selectPlaylistItem(library, 'missing')).toEqual(library);
  });
});
