import type { PlaylistItem } from './m3u';

type TimeoutHandle = ReturnType<typeof setTimeout>;
type TimerApi = Pick<typeof globalThis, 'setTimeout' | 'clearTimeout'>;

export type AutoplayResult = 'playing' | 'muted' | 'manual';

export function createLivePlaybackScheduler({ delayMs = 500, timers = globalThis }: { delayMs?: number; timers?: TimerApi } = {}) {
  let timer: TimeoutHandle | undefined;
  let controller: AbortController | undefined;

  function cancel() {
    if (timer) timers.clearTimeout(timer);
    timer = undefined;
    controller?.abort();
    controller = undefined;
  }

  return {
    select(item: PlaylistItem | null, start: (item: PlaylistItem, signal: AbortSignal) => void) {
      cancel();
      if (!item || item.kind !== 'live') return;
      const nextController = new AbortController();
      controller = nextController;
      timer = timers.setTimeout(() => {
        timer = undefined;
        if (!nextController.signal.aborted) start(item, nextController.signal);
      }, delayMs);
    },
    cancel,
  };
}

export async function playWithMutedFallback(video: Pick<HTMLMediaElement, 'muted' | 'play'>): Promise<AutoplayResult> {
  try {
    await video.play();
    return 'playing';
  } catch (error) {
    if (!(typeof error === 'object' && error !== null && 'name' in error && error.name === 'NotAllowedError') || video.muted) return 'manual';
  }
  video.muted = true;
  try {
    await video.play();
    return 'muted';
  } catch {
    return 'manual';
  }
}
