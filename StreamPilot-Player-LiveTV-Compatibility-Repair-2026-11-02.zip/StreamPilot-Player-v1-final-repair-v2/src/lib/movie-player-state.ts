export type MoviePlayerSelection = { id: string; name: string };

export function moviePlayerPresentation(selection: MoviePlayerSelection | undefined, { grantBusy, source, playbackStatus, grantError, playbackError }: {
  grantBusy: boolean;
  source: string;
  playbackStatus: 'idle' | 'loading' | 'ready' | 'playing' | 'error';
  grantError: string;
  playbackError: string;
}) {
  const error = grantError || playbackError;
  return {
    visible: Boolean(selection),
    title: selection?.name ?? '',
    loading: Boolean(selection) && !error && (grantBusy || Boolean(source) && playbackStatus === 'loading'),
    error,
  };
}
