import { describe, expect, it, vi } from 'vitest';
import type { PlaylistItem } from './m3u';
import { createLivePlaybackScheduler, playWithMutedFallback } from './live-playback-controller';

const live = (id: string): PlaylistItem => ({ id, name: id, url: `https://example.test/${id}.m3u8`, group: 'Test', kind: 'live' });

describe('live playback controller', () => {
  it('starts a selected live channel once after the debounce', () => {
    vi.useFakeTimers();
    const start = vi.fn();
    const scheduler = createLivePlaybackScheduler();
    scheduler.select(live('one'), start);
    vi.advanceTimersByTime(499);
    expect(start).not.toHaveBeenCalled();
    vi.advanceTimersByTime(1);
    expect(start).toHaveBeenCalledTimes(1);
    expect(start.mock.calls[0][0].id).toBe('one');
    vi.useRealTimers();
  });

  it('starts only the final rapid selection and aborts the previous request', () => {
    vi.useFakeTimers();
    const start = vi.fn();
    const scheduler = createLivePlaybackScheduler();
    scheduler.select(live('one'), start);
    scheduler.select(live('two'), start);
    vi.advanceTimersByTime(500);
    expect(start).toHaveBeenCalledTimes(1);
    expect(start.mock.calls[0][0].id).toBe('two');

    const firstSignal = start.mock.calls[0][1] as AbortSignal;
    scheduler.select(live('three'), start);
    expect(firstSignal.aborted).toBe(true);
    vi.advanceTimersByTime(500);
    expect(start).toHaveBeenCalledTimes(2);
    expect(start.mock.calls[1][0].id).toBe('three');
    vi.useRealTimers();
  });

  it('does not schedule movies or series', () => {
    vi.useFakeTimers();
    const start = vi.fn();
    const scheduler = createLivePlaybackScheduler();
    scheduler.select({ ...live('movie'), kind: 'movie' }, start);
    vi.advanceTimersByTime(500);
    expect(start).not.toHaveBeenCalled();
    vi.useRealTimers();
  });

  it('retries a browser autoplay rejection once while muted, then falls back', async () => {
    const rejected = new DOMException('blocked', 'NotAllowedError');
    const video = { muted: false, play: vi.fn().mockRejectedValueOnce(rejected).mockResolvedValueOnce(undefined) };
    await expect(playWithMutedFallback(video)).resolves.toBe('muted');
    expect(video.muted).toBe(true);
    expect(video.play).toHaveBeenCalledTimes(2);

    const blocked = { muted: false, play: vi.fn().mockRejectedValue(new DOMException('blocked', 'NotAllowedError')) };
    await expect(playWithMutedFallback(blocked)).resolves.toBe('manual');
    expect(blocked.play).toHaveBeenCalledTimes(2);
  });
});
