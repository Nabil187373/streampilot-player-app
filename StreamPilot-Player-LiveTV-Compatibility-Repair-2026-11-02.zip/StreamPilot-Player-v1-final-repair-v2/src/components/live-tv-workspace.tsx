import { useDeferredValue, useEffect, useMemo, useRef, useState, type KeyboardEvent } from 'react';
import { Heart, ListVideo, Search, Star, Tv2, Upload } from 'lucide-react';
import { activePlaylist, selectPlaylistItem, setActiveCategory, switchPlaylist, togglePlaylistFavorite, type PlaylistCategory, type PlaylistLibrary } from '../lib/playlist-library';
import type { PlaylistItem } from '../lib/m3u';

const ROW_HEIGHT = 64;
const OVERSCAN = 7;

type Props = {
  library: PlaylistLibrary;
  onLibraryChange: (library: PlaylistLibrary) => void;
  onAddPlaylist: () => void;
  onChooseChannel: (item: PlaylistItem) => void;
  busy?: boolean;
};

function isTypingTarget(target: EventTarget | null) {
  return target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement || (target instanceof HTMLElement && target.isContentEditable);
}

export function LiveTvWorkspace({ library, onLibraryChange, onAddPlaylist, onChooseChannel, busy = false }: Props) {
  const playlist = activePlaylist(library);
  const [search, setSearch] = useState('');
  const deferredSearch = useDeferredValue(search.trim().toLocaleLowerCase());
  const [scrollTop, setScrollTop] = useState(0);
  const listRef = useRef<HTMLDivElement>(null);
  const channelRefs = useRef(new Map<string, HTMLButtonElement>());

  useEffect(() => {
    setSearch('');
    setScrollTop(0);
    listRef.current?.scrollTo({ top: 0 });
  }, [playlist?.id]);

  const categories = useMemo(() => {
    if (!playlist) return [];
    const groups = new Map<string, number>();
    playlist.items.forEach((item) => groups.set(item.group, (groups.get(item.group) ?? 0) + 1));
    return [
      { id: 'all', label: 'All channels', count: playlist.items.length },
      { id: 'favorites', label: 'Favorites', count: playlist.favoriteIds.length },
      { id: 'recent', label: 'Recently watched', count: playlist.recentIds.length },
      ...[...groups.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([group, count]) => ({ id: `group:${group}`, label: group, count })),
    ];
  }, [playlist]);

  const channels = useMemo(() => {
    if (!playlist) return [];
    const recent = new Set(playlist.recentIds);
    return playlist.items.filter((item) => {
      const category = playlist.activeCategory;
      const categoryMatches = category === 'all'
        || (category === 'favorites' && playlist.favoriteIds.includes(item.id))
        || (category === 'recent' && recent.has(item.id))
        || (category.startsWith('group:') && item.group === category.slice('group:'.length));
      return categoryMatches && (!deferredSearch || `${item.name} ${item.group} ${item.tvgId ?? ''}`.toLocaleLowerCase().includes(deferredSearch));
    });
  }, [playlist, deferredSearch]);

  const start = Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - OVERSCAN);
  const end = Math.min(channels.length, Math.ceil((scrollTop + 510) / ROW_HEIGHT) + OVERSCAN);
  const visibleChannels = channels.slice(start, end);

  function changeCategory(category: PlaylistCategory) {
    onLibraryChange(setActiveCategory(library, category));
    setScrollTop(0);
    listRef.current?.scrollTo({ top: 0 });
  }

  function choose(item: PlaylistItem) {
    onLibraryChange(selectPlaylistItem(library, item.id));
    onChooseChannel(item);
  }

  function handleKeyDown(event: KeyboardEvent<HTMLElement>) {
    if (!playlist || isTypingTarget(event.target)) return;
    const focusedChannelId = document.activeElement instanceof HTMLElement ? document.activeElement.dataset.channelId : undefined;
    const currentIndex = Math.max(0, channels.findIndex((item) => item.id === (focusedChannelId || playlist.selectedItemId)));
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      if (!channels.length) return;
      event.preventDefault();
      const offset = event.key === 'ArrowDown' ? 1 : -1;
      const item = channels[Math.min(channels.length - 1, Math.max(0, currentIndex + offset))];
      channelRefs.current.get(item.id)?.focus();
      return;
    }
    if (event.key === 'Enter' || event.key === ' ') {
      const item = channels[currentIndex];
      if (!item) return;
      event.preventDefault();
      choose(item);
      return;
    }
    if (event.key === 'ArrowLeft') {
      event.preventDefault();
      event.currentTarget.querySelector<HTMLButtonElement>('.live-tv-category.is-active')?.focus();
      return;
    }
    if (event.key === 'ArrowRight') {
      event.preventDefault();
      channelRefs.current.get(channels[currentIndex]?.id ?? '')?.focus();
      return;
    }
    if (event.key === 'Escape' || event.key === 'BrowserBack') {
      event.preventDefault();
      if (search) setSearch('');
      else document.getElementById('live-tv-playlist-selector')?.focus();
    }
  }

  if (!playlist) {
    return <section className="live-tv-empty"><Tv2 size={36} /><h1>Live TV is ready for your playlists</h1><p>Import an authorised M3U or M3U8 playlist to browse channels in a focused TV layout.</p><button className="button-primary" onClick={onAddPlaylist}><Upload size={16} /> Add local playlist</button></section>;
  }

  return <section className="live-tv-workspace" onKeyDown={handleKeyDown}>
    <header className="live-tv-header">
      <div><span className="live-tv-kicker">LIVE TV</span><h1>Watch your way</h1></div>
      <div className="playlist-picker-wrap">
        <label htmlFor="live-tv-playlist-selector">Active playlist</label>
        <div className="playlist-picker-actions">
          <select id="live-tv-playlist-selector" value={playlist.id} onChange={(event) => onLibraryChange(switchPlaylist(library, event.target.value))}>
            {library.playlists.map((source) => <option key={source.id} value={source.id}>{source.name}</option>)}
          </select>
          <button className="live-tv-add" onClick={onAddPlaylist} disabled={busy}><Upload size={15} /> Add</button>
        </div>
      </div>
    </header>

    <div className="live-tv-layout">
      <aside className="live-tv-categories" aria-label="Channel categories">
        <label className="live-tv-search"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search channels" aria-label="Search channels" /></label>
        <div className="live-tv-category-list" role="listbox" aria-label="Channel category">
          {categories.map((category) => <button key={category.id} className={`live-tv-category ${playlist.activeCategory === category.id ? 'is-active' : ''}`} onClick={() => changeCategory(category.id)} role="option" aria-selected={playlist.activeCategory === category.id}>
            <span>{category.id === 'favorites' ? <Heart size={15} /> : category.id === 'recent' ? <Star size={15} /> : category.id === 'all' ? <ListVideo size={15} /> : <span className="category-dot" />}{category.label}</span><strong>{category.count}</strong>
          </button>)}
        </div>
      </aside>

      <section className="live-tv-channel-panel" aria-label="Channels">
        <div className="live-tv-panel-heading"><div><span>CHANNELS</span><strong>{channels.length} available</strong></div><span>{playlist.name}</span></div>
        <div className="live-tv-channel-list" ref={listRef} onScroll={(event) => setScrollTop(event.currentTarget.scrollTop)} role="listbox" aria-label="Playlist channels">
          <div style={{ height: channels.length * ROW_HEIGHT, position: 'relative' }}>
            <div style={{ transform: `translateY(${start * ROW_HEIGHT}px)` }}>
              {visibleChannels.map((item, index) => {
                const absoluteIndex = start + index;
                const selected = item.id === playlist.selectedItemId;
                const favorite = playlist.favoriteIds.includes(item.id);
                return <button key={item.id} data-channel-id={item.id} ref={(node) => { if (node) channelRefs.current.set(item.id, node); else channelRefs.current.delete(item.id); }} className={`live-tv-channel ${selected ? 'is-selected' : ''}`} onClick={() => choose(item)} role="option" aria-selected={selected}>
                  <span className="live-tv-number">{String(absoluteIndex + 1).padStart(3, '0')}</span>
                  <span className="live-tv-logo">{item.logo ? <img src={item.logo} alt="" onError={(event) => { event.currentTarget.style.display = 'none'; }} /> : <Tv2 size={18} />}</span>
                  <span className="live-tv-channel-copy"><strong>{item.name}</strong><small>{item.group}</small></span>
                  <span className="live-tv-channel-tools">{favorite && <Heart size={14} fill="currentColor" aria-label="Favorite" />}<span className="channel-type">{item.url.toLowerCase().includes('.m3u8') ? 'HLS' : 'LIVE'}</span></span>
                </button>;
              })}
            </div>
          </div>
        </div>
        <button className={`live-tv-favorite ${playlist.favoriteIds.includes(playlist.selectedItemId ?? '') ? 'is-favorite' : ''}`} disabled={!playlist.selectedItemId} onClick={() => playlist.selectedItemId && onLibraryChange(togglePlaylistFavorite(library, playlist.selectedItemId))}><Heart size={15} fill={playlist.favoriteIds.includes(playlist.selectedItemId ?? '') ? 'currentColor' : 'none'} /> {playlist.favoriteIds.includes(playlist.selectedItemId ?? '') ? 'Remove favorite' : 'Add favorite'}</button>
      </section>

    </div>
  </section>;
}
