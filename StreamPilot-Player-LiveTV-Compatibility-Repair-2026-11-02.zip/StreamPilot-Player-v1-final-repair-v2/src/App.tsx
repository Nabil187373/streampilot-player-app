import { useCallback, useEffect, useMemo, useRef, useState, type RefObject } from 'react';
import Hls from 'hls.js';
import {
  Activity, AlertCircle, ArrowDownToLine, ArrowRight, Check, ChevronDown,
  CircleHelp, Clapperboard, Film, FolderOpen, Heart, Home, KeyRound,
  ListVideo, MonitorPlay, MoreHorizontal, Play, Plus, Search, Settings2,
  ShieldCheck, Signal, Sparkles, Tv2, Upload, Wifi, X,
} from 'lucide-react';
import { parseM3U, type PlaylistItem } from './lib/m3u';
import { ConnectorResponseError, browserPlaybackFailureCategory, movieDiagnosticPath, playbackDiagnosticPath, playbackFailureDiagnostic, playbackFailureMessage, readConnectorResponse, readMovieGrantResponse, readPlaybackGrantResponse, type PlaybackFailureCategory, type PlaybackFailureDiagnostic } from './lib/connector-response';
import { LiveTvWorkspace } from './components/live-tv-workspace';
import { activePlaylist, addLocalPlaylist, createPlaylistLibrary, togglePlaylistFavorite, type PlaylistLibrary } from './lib/playlist-library';
import { createLivePlaybackScheduler, playWithMutedFallback } from './lib/live-playback-controller';
import { moviePlayerPresentation } from './lib/movie-player-state';

const DEMO_STREAM = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8';
const MAX_LOCAL_PLAYLIST_BYTES = 40 * 1024 * 1024;
const LOCAL_PLAYLIST_ENTRY_LIMIT = 20_000;
const COMPACT_CHANNEL_COUNT = 4;
const CHANNEL_PAGE_SIZE = 24;
const VOD_PAGE_SIZE = 100;
type View = 'Library' | 'Live TV' | 'Movies' | 'Series' | 'Favorites';
type Modal = 'playlist' | 'xtream' | 'activation' | null;
type VodCategory = { id: string; name: string };
type VodMovie = { id: string; name: string; icon?: string; year?: string; rating?: string };
type SeriesEpisode = { id: string; title: string; season: string; seasonName?: string; episodeNumber?: string; icon?: string; plot?: string };
type AudioTrackOption = { id: number; label: string; language?: string; codec?: string };
type HlsAudioTrackApi = Hls & {
  audioTracks: Array<{ id: number; name?: string; lang?: string; audioCodec?: string; type?: string }>;
  audioTrack: number;
};

async function readVodResponse(response: Response): Promise<Record<string, unknown>> {
  const contentType = response.headers.get('content-type')?.toLowerCase() || '';
  const body = await response.text();
  if (!contentType.includes('application/json') || !body.trim()) throw new ConnectorResponseError('connector_unavailable');
  let payload: unknown;
  try { payload = JSON.parse(body); } catch { throw new ConnectorResponseError('connector_unavailable'); }
  if (!payload || typeof payload !== 'object') throw new ConnectorResponseError('connector_unavailable');
  const value = payload as { ok?: unknown; error?: { code?: unknown } };
  if (!response.ok || value.ok !== true) throw new ConnectorResponseError(typeof value.error?.code === 'string' ? value.error.code : 'internal_error');
  return payload as Record<string, unknown>;
}

function asVodCategories(value: unknown): VodCategory[] {
  if (!Array.isArray(value)) throw new ConnectorResponseError('connector_unavailable');
  return value.flatMap((category) => category && typeof category === 'object' && typeof (category as VodCategory).id === 'string' && typeof (category as VodCategory).name === 'string'
    ? [{ id: (category as VodCategory).id, name: (category as VodCategory).name }]
    : []);
}

function asVodMovies(value: unknown): VodMovie[] {
  if (!Array.isArray(value)) throw new ConnectorResponseError('connector_unavailable');
  return value.flatMap((movie) => {
    if (!movie || typeof movie !== 'object' || typeof (movie as VodMovie).id !== 'string' || typeof (movie as VodMovie).name !== 'string') return [];
    const source = movie as VodMovie;
    return [{ id: source.id, name: source.name, ...(typeof source.icon === 'string' ? { icon: source.icon } : {}), ...(typeof source.year === 'string' ? { year: source.year } : {}), ...(typeof source.rating === 'string' ? { rating: source.rating } : {}) }];
  });
}

const demoItem: PlaylistItem = {
  id: 'demo-big-buck-bunny',
  name: 'Big Buck Bunny · HLS test stream',
  url: DEMO_STREAM,
  group: 'Sample media',
  kind: 'live',
};

function moviePlaybackFailureMessage(diagnostic?: PlaybackFailureDiagnostic | PlaybackFailureCategory) {
  const category = typeof diagnostic === 'string' ? diagnostic : diagnostic?.category;
  if (category === 'host_not_allowed' || category === 'redirect_rejected') {
    const detail = typeof diagnostic === 'object' ? playbackFailureMessage(diagnostic) : '';
    return `Provider movie server not permitted.${detail ? ` ${detail}` : ''}`;
  }
  if (category === 'session_expired') return 'Session expired, re-import the playlist.';
  if (category === 'media_codec_error') return 'This file format is not supported by your browser.';
  return playbackFailureMessage(diagnostic);
}

function useHls(videoRef: RefObject<HTMLVideoElement | null>, url: string, sourceId?: string, autoPlay = false, nativeVideoErrorMessage?: string, failureMessage = playbackFailureMessage) {
  const [error, setError] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'ready' | 'playing' | 'error'>('idle');
  const [mutedAutoplay, setMutedAutoplay] = useState(false);
  const [audioTracks, setAudioTracks] = useState<AudioTrackOption[]>([]);
  const [selectedAudioTrack, setSelectedAudioTrack] = useState(-1);
  const [audioWarning, setAudioWarning] = useState('');
  const hlsRef = useRef<Hls | null>(null);
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !url) {
      setStatus('idle');
      setMutedAutoplay(false);
      setAudioTracks([]);
      setSelectedAudioTrack(-1);
      setAudioWarning('');
      hlsRef.current = null;
      return;
    }
    setError('');
    setStatus('loading');
    setMutedAutoplay(false);
    setAudioTracks([]);
    setSelectedAudioTrack(-1);
    setAudioWarning('');
    hlsRef.current = null;
    video.muted = false;
    let hls: Hls | undefined;
    let autoplayAttempted = false;
    const onCanPlay = () => {
      setStatus('ready');
      if (!autoPlay || autoplayAttempted) return;
      autoplayAttempted = true;
      void playWithMutedFallback(video).then((result) => {
        if (cancelled) return;
        if (result === 'muted') setMutedAutoplay(true);
      });
    };
    const onPlaying = () => setStatus('playing');
    let cancelled = false;
    const fail = (diagnostic?: PlaybackFailureDiagnostic | PlaybackFailureCategory) => { if (!cancelled) { setStatus('error'); setError(failureMessage(diagnostic)); } };
    let renewalAttempted = false;
    const renewExpiredGrant = async () => {
      const match = url.match(/^\/api\/playback\/([A-Za-z0-9_-]+)\/manifest\.m3u8$/);
      if (!match || renewalAttempted) return false;
      renewalAttempted = true;
      try {
        const response = await fetch('/api/playback/grants/renew', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'content-type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ grantId: match[1] }),
        });
        const renewedPath = await readPlaybackGrantResponse(response);
        if (cancelled) return true;
        setError(''); setStatus('loading');
        if (hls) { hls.stopLoad(); hls.loadSource(renewedPath); }
        else { video.src = renewedPath; video.load(); if (autoPlay) void video.play().catch(() => {}); }
        return true;
      } catch { return false; }
    };
    const diagnostic = async () => {
      const path = playbackDiagnosticPath(url) ?? movieDiagnosticPath(url);
      if (!path) return undefined;
      try {
        const response = await fetch(path, { credentials: 'same-origin', cache: 'no-store' });
        if (!response.ok) return undefined;
        let value: unknown;
        try { value = JSON.parse(await response.text()); } catch { return undefined; }
        const direct = playbackFailureDiagnostic(value);
        if (direct) return direct;
        const nested = value as { error?: { diagnostic?: { playbackCategory?: unknown } } };
        return playbackFailureDiagnostic({ category: nested.error?.diagnostic?.playbackCategory });
      } catch { return undefined; }
    };
    // Native video errors do not reliably distinguish a failed request from an
    // unsupported codec. Prefer the server's session-bound diagnostic; otherwise
    // report the uncertainty rather than incorrectly blaming the codec.
    const onVideoError = () => { void (async () => {
      if (await renewExpiredGrant()) return;
      const category = await diagnostic();
      if (category) { fail(category); return; }
      if (!cancelled && nativeVideoErrorMessage) { setStatus('error'); setError(nativeVideoErrorMessage); return; }
      fail(browserPlaybackFailureCategory('unknown'));
    })(); };
    video.addEventListener('canplay', onCanPlay);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('error', onVideoError);

    const start = async () => {
      if (cancelled) return;
      if (video.canPlayType('application/vnd.apple.mpegurl')) video.src = url;
      else if (Hls.isSupported() && /\.m3u8(?:$|\?)/i.test(url)) {
        hls = new Hls({ enableWorker: true, lowLatencyMode: false, backBufferLength: 30 });
        hlsRef.current = hls;
        hls.on(Hls.Events.AUDIO_TRACKS_UPDATED, () => {
          const engine = hls as HlsAudioTrackApi;
          const tracks = (engine.audioTracks ?? []).map((track, index) => ({
            id: track.id ?? index,
            label: track.name?.trim() || track.lang?.trim() || `Audio ${index + 1}`,
            ...(track.lang ? { language: track.lang } : {}),
            ...(track.audioCodec ? { codec: track.audioCodec } : {}),
          }));
          setAudioTracks(tracks);
          setSelectedAudioTrack(engine.audioTrack >= 0 ? engine.audioTrack : (tracks[0]?.id ?? -1));

          // Prefer an advertised AAC track when the provider's default codec
          // cannot be decoded by this browser.
          const defaultTrack = (engine.audioTracks ?? []).find((track) => track.id === engine.audioTrack)
            ?? (engine.audioTracks ?? [])[0];
          const defaultCodec = defaultTrack?.audioCodec;
          const codecSupported = !defaultCodec || typeof MediaSource === 'undefined'
            || MediaSource.isTypeSupported(`audio/mp4; codecs="${defaultCodec}"`);
          if (!codecSupported) {
            const compatible = (engine.audioTracks ?? []).find((track) =>
              track.audioCodec && /^(mp4a|aac)/i.test(track.audioCodec)
              && (typeof MediaSource === 'undefined' || MediaSource.isTypeSupported(`audio/mp4; codecs="${track.audioCodec}"`)));
            if (compatible) {
              engine.audioTrack = compatible.id;
              setSelectedAudioTrack(compatible.id);
              setAudioWarning('');
            } else {
              setAudioWarning(`This browser may not decode the provider's ${defaultCodec} audio track. The provider must offer a browser-compatible audio track, such as AAC.`);
            }
          } else {
            setAudioWarning('');
          }
        });
        hls.on(Hls.Events.AUDIO_TRACK_SWITCHED, (_event, data) => {
          const id = (data as { id?: number } | undefined)?.id;
          if (typeof id === 'number') setSelectedAudioTrack(id);
        });
        hls.loadSource(url);
        hls.attachMedia(video);
        hls.on(Hls.Events.ERROR, (_event, data) => {
          if (!data.fatal) return;
          if (data.type === Hls.ErrorTypes.NETWORK_ERROR && Number((data as unknown as { response?: { code?: number } }).response?.code) === 401) {
            void renewExpiredGrant().then((renewed) => { if (!renewed) void diagnostic().then((category) => fail(category ?? browserPlaybackFailureCategory('network'))); });
            return;
          }
          const fallback = data.type === Hls.ErrorTypes.NETWORK_ERROR
            ? browserPlaybackFailureCategory('network')
            : data.type === Hls.ErrorTypes.MEDIA_ERROR
              ? browserPlaybackFailureCategory('media')
              : browserPlaybackFailureCategory('unknown');
          // A server-side manifest/asset failure is more specific than Hls.js's
          // generic event type. Its diagnostic is session-bound and allowlisted.
          void diagnostic().then((category) => fail(category ?? fallback));
        });
      } else video.src = url;
    };
    void start();
    return () => {
      cancelled = true;
      hls?.destroy();
      if (hlsRef.current === hls) hlsRef.current = null;
      video.removeEventListener('canplay', onCanPlay);
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('error', onVideoError);
      video.pause();
      video.removeAttribute('src');
      video.load();
    };
  }, [autoPlay, failureMessage, nativeVideoErrorMessage, sourceId, url, videoRef]);
  const selectAudioTrack = useCallback((trackId: number) => {
    const engine = hlsRef.current as HlsAudioTrackApi | null;
    if (!engine || !Number.isInteger(trackId)) return;
    engine.audioTrack = trackId;
    setSelectedAudioTrack(trackId);
  }, []);
  const unmute = useCallback(async () => {
    const video = videoRef.current;
    if (!video) return false;
    video.muted = false;
    try {
      await video.play();
      setMutedAutoplay(false);
      return true;
    } catch {
      return false;
    }
  }, [videoRef]);
  return { error, status, mutedAutoplay, unmute, audioTracks, selectedAudioTrack, selectAudioTrack, audioWarning };
}

function useDebouncedLiveSource(selected: PlaylistItem | null) {
  const [source, setSource] = useState<{ id: string; url: string } | null>(null);
  const [error, setError] = useState('');
  const [isStarting, setIsStarting] = useState(false);
  const schedulerRef = useRef<ReturnType<typeof createLivePlaybackScheduler> | null>(null);
  if (!schedulerRef.current) schedulerRef.current = createLivePlaybackScheduler();

  useEffect(() => {
    const scheduler = schedulerRef.current!;
    setSource(null);
    setError('');
    setIsStarting(selected?.kind === 'live');
    scheduler.select(selected, (item, signal) => {
      void (async () => {
        try {
          let url = item.url;
          if (item.playbackBlocked) {
            const response = await fetch('/api/playback/grants', {
              method: 'POST', credentials: 'same-origin', signal,
              headers: { 'content-type': 'application/json', Accept: 'application/json' },
              body: JSON.stringify({ itemId: item.id }),
            });
            url = await readPlaybackGrantResponse(response);
          }
          if (!signal.aborted) setSource({ id: item.id, url });
        } catch (reason) {
          if (!signal.aborted) setError(reason instanceof Error ? reason.message : 'Secure playback could not be authorized.');
        } finally {
          if (!signal.aborted) setIsStarting(false);
        }
      })();
    });
    return scheduler.cancel;
  }, [selected]);

  useEffect(() => () => schedulerRef.current?.cancel(), []);
  return { source, error, isStarting };
}

function App() {
  const [view, setView] = useState<View>('Library');
  const [search, setSearch] = useState('');
  const [items, setItems] = useState<PlaylistItem[]>([]);
  const [selected, setSelected] = useState<PlaylistItem | null>(null);
  const [modal, setModal] = useState<Modal>(null);
  const [notice, setNotice] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [playlistName, setPlaylistName] = useState('');
  const [playlistLibrary, setPlaylistLibrary] = useState<PlaylistLibrary>(() => createPlaylistLibrary());
  const [remotePlaylistName, setRemotePlaylistName] = useState('me');
  const [remotePlaylistUrl, setRemotePlaylistUrl] = useState('');
  const [xtreamServer, setXtreamServer] = useState('');
  const [xtreamUsername, setXtreamUsername] = useState('');
  const [xtreamPassword, setXtreamPassword] = useState('');
  const [visibleLimit, setVisibleLimit] = useState(COMPACT_CHANNEL_COUNT);
  const [importBusy, setImportBusy] = useState(false);
  const [vodAvailable, setVodAvailable] = useState(false);
  const [seriesAvailable, setSeriesAvailable] = useState(false);
  const [seriesCategories, setSeriesCategories] = useState<VodCategory[]>([]);
  const [seriesCategoryId, setSeriesCategoryId] = useState<string>();
  const [seriesItems, setSeriesItems] = useState<VodMovie[]>([]);
  const [seriesHasMore, setSeriesHasMore] = useState(false);
  const [seriesSelected, setSeriesSelected] = useState<VodMovie>();
  const [seriesEpisodes, setSeriesEpisodes] = useState<SeriesEpisode[]>([]);
  const [seriesLoading, setSeriesLoading] = useState(false);
  const [seriesError, setSeriesError] = useState('');
  const [vodCategories, setVodCategories] = useState<VodCategory[]>([]);
  const [vodCategoryId, setVodCategoryId] = useState<string>();
  const [vodMovies, setVodMovies] = useState<VodMovie[]>([]);
  const [vodHasMore, setVodHasMore] = useState(false);
  const [vodCategoriesLoading, setVodCategoriesLoading] = useState(false);
  const [vodMoviesLoading, setVodMoviesLoading] = useState(false);
  const [vodError, setVodError] = useState('');
  const [movieSelected, setMovieSelected] = useState<VodMovie>();
  const [movieSource, setMovieSource] = useState('');
  const [movieGrantBusy, setMovieGrantBusy] = useState(false);
  const [movieGrantError, setMovieGrantError] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const movieVideoRef = useRef<HTMLVideoElement>(null);
  const { source: liveSource, error: liveSourceError, isStarting: liveSourceStarting } = useDebouncedLiveSource(selected);
  const playbackUrl = selected?.kind === 'live' ? (liveSource?.id === selected.id ? liveSource.url : '') : (selected?.url ?? '');
  const { error: playbackError, status: playbackStatus, mutedAutoplay, unmute, audioTracks: liveAudioTracks, selectedAudioTrack: liveSelectedAudioTrack, selectAudioTrack: selectLiveAudioTrack, audioWarning: liveAudioWarning } = useHls(videoRef, playbackUrl, selected?.id, selected?.kind === 'live');
  const { error: moviePlaybackError, status: moviePlaybackStatus, mutedAutoplay: movieMutedAutoplay, unmute: unmuteMovie, audioTracks: movieAudioTracks, selectedAudioTrack: movieSelectedAudioTrack, selectAudioTrack: selectMovieAudioTrack, audioWarning: movieAudioWarning } = useHls(movieVideoRef, movieSource, movieSelected?.id, true, 'This file format is not supported by your browser.', moviePlaybackFailureMessage);
  const moviePlayer = moviePlayerPresentation(movieSelected, { grantBusy: movieGrantBusy, source: movieSource, playbackStatus: moviePlaybackStatus, grantError: movieGrantError, playbackError: moviePlaybackError });

  const visibleItems = useMemo(() => {
    const q = search.toLowerCase().trim();
    return items.filter((item) => {
      const matchesView = view === 'Library'
        || (view === 'Live TV' && (item.kind === 'live' || item.kind === 'unknown'))
        || (view === 'Movies' && item.kind === 'movie')
        || (view === 'Series' && item.kind === 'series')
        || (view === 'Favorites' && favorites.includes(item.id));
      const matchesQuery = !q || `${item.name} ${item.group} ${item.tvgId ?? ''}`.toLowerCase().includes(q);
      return matchesView && matchesQuery;
    });
  }, [items, view, search, favorites]);

  const groups = useMemo(() => [...new Set(items.map((item) => item.group))], [items]);
  const renderedItems = useMemo(() => visibleItems.slice(0, visibleLimit), [visibleItems, visibleLimit]);
  const remainingItems = Math.max(0, visibleItems.length - visibleLimit);
  const visibleVodMovies = useMemo(() => {
    const query = search.trim().toLowerCase();
    return !query ? vodMovies : vodMovies.filter((movie) => `${movie.name} ${movie.year ?? ''}`.toLowerCase().includes(query));
  }, [search, vodMovies]);

  useEffect(() => {
    setVisibleLimit(COMPACT_CHANNEL_COUNT);
  }, [items, view, search]);

  function showMessage(type: 'success' | 'error' | 'info', text: string) {
    setNotice({ type, text });
  }

  function resetVodCatalogue(available = false, hasSeries = available) {
    setVodAvailable(available); setVodCategories([]); setVodCategoryId(undefined); setVodMovies([]); setVodHasMore(false); setVodError(''); setMovieSelected(undefined); setMovieSource(''); setMovieGrantError('');
    setSeriesAvailable(hasSeries); setSeriesCategories([]); setSeriesCategoryId(undefined); setSeriesItems([]); setSeriesHasMore(false); setSeriesSelected(undefined); setSeriesEpisodes([]); setSeriesError('');
  }

  const loadVodCategories = useCallback(async () => {
    if (!vodAvailable || vodCategoriesLoading) return;
    setVodCategoriesLoading(true); setVodError('');
    try {
      const response = await fetch('/api/catalog/xtream/vod/categories', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', Accept: 'application/json' }, body: '{}' });
      setVodCategories(asVodCategories((await readVodResponse(response)).categories));
    } catch (error) {
      setVodError(error instanceof Error ? error.message : 'Movie categories are unavailable.');
    } finally { setVodCategoriesLoading(false); }
  }, [vodAvailable, vodCategoriesLoading]);

  const loadVodMovies = useCallback(async (categoryId: string, offset = 0) => {
    if (vodMoviesLoading) return;
    setVodMoviesLoading(true); setVodError('');
    try {
      const response = await fetch('/api/catalog/xtream/vod/items', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ categoryId, offset, limit: VOD_PAGE_SIZE }) });
      const page = await readVodResponse(response);
      const movies = asVodMovies(page.items);
      setVodCategoryId(categoryId);
      setVodMovies((current) => offset === 0 ? movies : [...current, ...movies]);
      setVodHasMore(page.hasMore === true);
    } catch (error) {
      setVodError(error instanceof Error ? error.message : 'Movie items are unavailable.');
    } finally { setVodMoviesLoading(false); }
  }, [vodMoviesLoading]);

  const loadSeriesCategories = useCallback(async () => {
    if (!seriesAvailable || seriesLoading || seriesCategories.length) return;
    setSeriesLoading(true); setSeriesError('');
    try {
      const response = await fetch('/api/catalog/xtream/series/categories', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', Accept: 'application/json' }, body: '{}' });
      setSeriesCategories(asVodCategories((await readVodResponse(response)).categories));
    } catch (error) { setSeriesError(error instanceof Error ? error.message : 'Series categories are unavailable.'); }
    finally { setSeriesLoading(false); }
  }, [seriesAvailable, seriesLoading, seriesCategories.length]);

  const loadSeriesItems = useCallback(async (categoryId: string, offset = 0) => {
    if (seriesLoading) return;
    setSeriesLoading(true); setSeriesError(''); setSeriesCategoryId(categoryId);
    if (offset === 0) { setSeriesSelected(undefined); setSeriesEpisodes([]); setSeriesItems([]); setSeriesHasMore(false); }
    try {
      const response = await fetch('/api/catalog/xtream/series/items', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ categoryId, offset, limit: VOD_PAGE_SIZE }) });
      const page = await readVodResponse(response);
      const nextItems = asVodMovies(page.items);
      setSeriesItems((current) => offset === 0 ? nextItems : [...current, ...nextItems]);
      setSeriesHasMore(page.hasMore === true);
    } catch (error) { setSeriesError(error instanceof Error ? error.message : 'Series are unavailable.'); }
    finally { setSeriesLoading(false); }
  }, [seriesLoading]);

  const chooseSeries = useCallback(async (series: VodMovie) => {
    if (seriesLoading) return;
    setSeriesLoading(true); setSeriesError(''); setSeriesSelected(series); setSeriesEpisodes([]); setMovieSelected(undefined); setMovieSource(''); setMovieGrantError('');
    try {
      const response = await fetch('/api/catalog/xtream/series/episodes', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ seriesId: series.id }) });
      const payload = await readVodResponse(response);
      setSeriesEpisodes(Array.isArray(payload.episodes) ? payload.episodes.filter((episode): episode is SeriesEpisode => Boolean(episode && typeof episode === 'object' && typeof (episode as SeriesEpisode).id === 'string' && typeof (episode as SeriesEpisode).title === 'string' && typeof (episode as SeriesEpisode).season === 'string')) : []);
    } catch (error) { setSeriesError(error instanceof Error ? error.message : 'Episodes are unavailable.'); }
    finally { setSeriesLoading(false); }
  }, [seriesLoading]);

  const chooseEpisode = useCallback(async (episode: SeriesEpisode) => {
    if (movieGrantBusy) return;
    movieVideoRef.current?.pause(); movieVideoRef.current?.removeAttribute('src'); movieVideoRef.current?.load();
    setSelected(null);
    setMovieGrantBusy(true); setMovieGrantError(''); setMovieSelected({ id: episode.id, name: episode.title, ...(episode.icon ? { icon: episode.icon } : {}) }); setMovieSource('');
    try {
      const response = await fetch('/api/media/grants', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ episodeId: episode.id }) });
      setMovieSource(await readMovieGrantResponse(response));
    } catch (error) { setMovieGrantError(error instanceof Error ? error.message : 'Episode playback could not be authorized.'); }
    finally { setMovieGrantBusy(false); }
  }, [movieGrantBusy]);

  const chooseMovie = useCallback(async (movie: VodMovie) => {
    if (movieGrantBusy) return;
    movieVideoRef.current?.pause(); movieVideoRef.current?.removeAttribute('src'); movieVideoRef.current?.load();
    setMovieGrantBusy(true); setVodError(''); setMovieGrantError(''); setSelected(null); setMovieSelected(movie); setMovieSource('');
    try {
      const response = await fetch('/api/media/grants', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ movieId: movie.id }) });
      setMovieSource(await readMovieGrantResponse(response));
    } catch (error) {
      setMovieGrantError(error instanceof Error ? error.message : 'Movie playback could not be authorized.');
    } finally { setMovieGrantBusy(false); }
  }, [movieGrantBusy]);

  useEffect(() => {
    if (view === 'Movies' && vodAvailable && !vodCategories.length && !vodCategoriesLoading && !vodError) void loadVodCategories();
    if (view === 'Series' && seriesAvailable && !seriesCategories.length && !seriesLoading && !seriesError) void loadSeriesCategories();
  }, [view, vodAvailable, vodCategories.length, vodCategoriesLoading, vodError, loadVodCategories, seriesAvailable, seriesCategories.length, seriesLoading, seriesError, loadSeriesCategories]);

  async function loadFile(file?: File) {
    if (!file) return;
    if (!/\.(m3u|m3u8|txt)$/i.test(file.name)) {
      showMessage('error', 'Choose an M3U, M3U8, or text playlist file.');
      return;
    }
    if (file.size > MAX_LOCAL_PLAYLIST_BYTES) {
      showMessage('error', 'This local playlist is larger than the 40 MiB in-memory import limit. Export a smaller authorised playlist to import it safely.');
      return;
    }
    setImportBusy(true);
    try {
      const text = await file.text();
      const parsedCandidate = parseM3U(text, { maxEntries: LOCAL_PLAYLIST_ENTRY_LIMIT + 1 });
      const entryLimitReached = parsedCandidate.length > LOCAL_PLAYLIST_ENTRY_LIMIT;
      const parsed = parsedCandidate.slice(0, LOCAL_PLAYLIST_ENTRY_LIMIT);
      if (!parsed.length) {
        showMessage('error', 'No playable entries were found. Check that the file contains #EXTINF entries followed by stream URLs.');
        return;
      }
      const nextLibrary = addLocalPlaylist(playlistLibrary, file.name, parsed);
      setItems(parsed);
      setSelected(parsed[0]);
      setView('Library');
      setSearch('');
      setPlaylistName(file.name);
      setFavorites([]);
      setPlaylistLibrary(nextLibrary);
      resetVodCatalogue();
      setModal(null);
      showMessage(entryLimitReached ? 'info' : 'success', entryLimitReached
        ? `Imported the first ${parsed.length.toLocaleString()} entries from ${file.name}. The 20,000-entry safety limit was reached; narrow the playlist to import additional entries.`
        : `Imported ${parsed.length} entries from ${file.name}. The player displays channels in small pages to stay responsive.`);
    } catch {
      showMessage('error', 'The playlist file could not be read.');
    } finally {
      setImportBusy(false);
    }
  }

  async function loadXtream() {
    if (!xtreamServer.trim() || !xtreamUsername.trim() || !xtreamPassword) {
      showMessage('error', 'Enter a provider server URL, username, and password.');
      return;
    }
    let xtreamUrl: URL;
    try { xtreamUrl = new URL(xtreamServer.trim()); } catch {
      showMessage('error', 'Enter a valid HTTP or HTTPS provider server URL.');
      return;
    }
    if (!['http:', 'https:'].includes(xtreamUrl.protocol)) {
      showMessage('error', 'Enter a valid HTTP or HTTPS provider server URL.');
      return;
    }
    if (xtreamUrl.protocol === 'http:' && !window.confirm('This provider uses unencrypted HTTP. Your username, password, and stream traffic may be visible to other parties on the network. Continue only if you trust this provider and network. Continue?')) return;
    setImportBusy(true);
    try {
      const response = await fetch('/api/playlist/xtream', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ serverUrl: xtreamServer.trim(), username: xtreamUsername.trim(), password: xtreamPassword }) });
      const payload = await readConnectorResponse(response);
      if (!payload.items.length) throw new Error('The provider returned no readable playlist entries.');
      const imported = payload.items.map((item) => ({ ...item, url: '' }));
      // Keep Xtream channels in the same playlist-library model consumed by
      // LiveTvWorkspace. Previously this flow updated only the Library's
      // separate `items` state, so the Library preview could play channels
      // while the dedicated Live TV page incorrectly showed its empty state.
      const nextLibrary = addLocalPlaylist(playlistLibrary, 'Provider playlist', imported);
      setPlaylistLibrary(nextLibrary);
      setItems(imported);
      setFavorites([]);
      setSelected(null);
      setPlaylistName(activePlaylist(nextLibrary)?.name ?? 'Provider playlist');
      setView('Live TV');
      setSearch('');
      setModal(null);
      resetVodCatalogue(payload.vodAvailable === true, payload.seriesAvailable === true);
      showMessage('info', payload.playbackNotice || `Imported ${imported.length} provider entries.`);
    } catch (error) {
      showMessage('error', error instanceof Error ? error.message : 'The provider playlist could not be imported safely.');
    } finally {
      setXtreamPassword('');
      setImportBusy(false);
    }
  }

  async function loadRemotePlaylist() {
    const displayName = remotePlaylistName.trim() || 'me';
    let parsedUrl: URL;
    try { parsedUrl = new URL(remotePlaylistUrl.trim()); } catch {
      showMessage('error', 'Enter a full HTTP or HTTPS playlist URL.');
      return;
    }
    if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
      showMessage('error', 'Enter a full HTTP or HTTPS playlist URL.');
      return;
    }
    if (parsedUrl.protocol === 'http:' && !window.confirm('This playlist uses unencrypted HTTP. The playlist URL and its contents may be visible to other parties on the network. Continue only if you trust this provider and network. Continue?')) return;
    setImportBusy(true);
    try {
      // The browser never fetches the URL. The same-origin connector validates
      // its destination and returns metadata only, not the playlist or stream URLs.
      const response = await fetch('/api/playlist/remote', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ playlistUrl: remotePlaylistUrl.trim() }) });
      const payload = await readConnectorResponse(response);
      if (!payload.items.length) throw new Error('The provider returned no readable playlist entries.');
      const imported = payload.items.map((item) => ({ ...item, url: '' }));
      const nextLibrary = addLocalPlaylist(playlistLibrary, displayName, imported);
      setPlaylistLibrary(nextLibrary);
      setItems(imported);
      setFavorites([]);
      setSelected(null);
      setPlaylistName(activePlaylist(nextLibrary)?.name ?? displayName);
      setView('Live TV');
      setSearch('');
      setRemotePlaylistUrl('');
      setRemotePlaylistName('me');
      setModal(null);
      resetVodCatalogue(payload.vodAvailable === true, payload.seriesAvailable === true);
      showMessage('info', payload.playbackNotice || `Imported ${imported.length} provider entries.`);
    } catch (error) {
      showMessage('error', error instanceof Error ? error.message : 'The remote playlist could not be imported safely.');
    } finally {
      setImportBusy(false);
    }
  }

  function importDemo() {
    const example: PlaylistItem[] = [
      { ...demoItem, id: 'demo-bunny', name: 'Big Buck Bunny · HLS test stream', group: 'Sample media' },
    ];
    setItems(example);
    setSelected(example[0]);
    setPlaylistName('Public test stream');
    resetVodCatalogue();
    setView('Library');
    setModal(null);
    showMessage('info', 'Loaded a public HLS test stream for playback checks. It is sample media, not a bundled channel service.');
  }

  function toggleFavorite(item: PlaylistItem) {
    setFavorites((current) => current.includes(item.id) ? current.filter((id) => id !== item.id) : [...current, item.id]);
    if (activePlaylist(playlistLibrary)?.items.some((candidate) => candidate.id === item.id)) {
      setPlaylistLibrary((current) => togglePlaylistFavorite(current, item.id));
    }
  }

  function updatePlaylistLibrary(nextLibrary: PlaylistLibrary) {
    setPlaylistLibrary(nextLibrary);
    const active = activePlaylist(nextLibrary);
    if (!active) return;
    setItems(active.items);
    setFavorites(active.favoriteIds);
    setPlaylistName(active.name);
    // Switching sources should not trigger a fresh playback request automatically.
    if (activePlaylist(playlistLibrary)?.id !== active.id) setSelected(null);
  }

  async function chooseItem(item: PlaylistItem) {
    setMovieSelected(undefined);
    setMovieSource('');
    setMovieGrantError('');
    if (item.kind === 'live') {
      setSelected(item);
      return;
    }
    if (item.playbackBlocked) {
      setImportBusy(true);
      try {
        const response = await fetch('/api/playback/grants', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ itemId: item.id }) });
        const manifestPath = await readPlaybackGrantResponse(response);
        setSelected({ ...item, url: manifestPath, playbackBlocked: false });
      } catch (error) {
        showMessage('error', error instanceof Error ? error.message : 'Secure playback could not be authorized.');
      } finally {
        setImportBusy(false);
      }
      return;
    }
    setSelected(item);
    if (/^rtsp:|^rtmp:|^udp:/i.test(item.url)) {
      showMessage('info', 'This source uses a protocol that typical web browsers do not play directly. TV or native playback support must be evaluated separately.');
    }
  }

  const nav = [
    { label: 'Library' as View, icon: Home, count: items.length },
    { label: 'Live TV' as View, icon: Signal },
    { label: 'Movies' as View, icon: Film },
    { label: 'Series' as View, icon: Clapperboard },
    { label: 'Favorites' as View, icon: Heart, count: favorites.length },
  ];

  const isMovieActive = Boolean(movieSelected);
  const activePlayerTitle = isMovieActive ? movieSelected?.name : selected?.name;
  const activePlayerError = isMovieActive ? (movieGrantError || moviePlaybackError) : (liveSourceError || playbackError);
  const activePlayerLoading = isMovieActive
    ? (movieGrantBusy || moviePlaybackStatus === 'loading')
    : (liveSourceStarting || playbackStatus === 'loading');
  const activeMutedAutoplay = isMovieActive ? movieMutedAutoplay : mutedAutoplay;
  const activeAudioTracks = isMovieActive ? movieAudioTracks : liveAudioTracks;
  const activeSelectedAudioTrack = isMovieActive ? movieSelectedAudioTrack : liveSelectedAudioTrack;
  const activeAudioWarning = isMovieActive ? movieAudioWarning : liveAudioWarning;
  const selectActiveAudioTrack = isMovieActive ? selectMovieAudioTrack : selectLiveAudioTrack;
  const playerPreview = <div className={`player-card persistent-player-card ${activePlayerTitle ? "has-media" : "no-media"}`}>
    <div className="player-card-top"><div><span className="player-label">NOW IN PLAYER</span><h3>{activePlayerTitle ? (activePlayerTitle.length > 28 ? `${activePlayerTitle.slice(0, 27)}…` : activePlayerTitle) : 'Select a stream'}</h3></div><button className="icon-button" onClick={() => !isMovieActive && selected && toggleFavorite(selected)} disabled={!selected || isMovieActive} aria-label="Add selected stream to favorites"><Heart size={18} fill={selected && favorites.includes(selected.id) ? 'currentColor' : 'none'} /></button></div>
    <div className="video-frame">
      <video ref={videoRef} controls playsInline preload="metadata" aria-label="Selected playlist stream" style={{ display: isMovieActive ? 'none' : 'block' }} />
      <video ref={movieVideoRef} controls playsInline preload="metadata" aria-label="Selected movie or episode" style={{ display: isMovieActive ? 'block' : 'none' }} />
      {!activePlayerTitle && <div className="video-overlay"><MonitorPlay size={30} /><span>Select a stream to play</span></div>}
      {activePlayerTitle && activePlayerLoading && <div className="video-overlay"><MonitorPlay size={30} /><span>Loading stream…</span></div>}
      <div className="video-corner-label"><span className="live-dot" /> {isMovieActive ? 'VOD' : 'LIVE'}</div>
    </div>
    {activePlayerError ? <div className="player-error"><AlertCircle size={15} /> {activePlayerError}</div> : <div className="player-meta"><span><Signal size={14} /> {isMovieActive ? 'Movie / episode playback' : 'Live playback'}</span><span><ShieldCheck size={14} /> Session protected</span></div>}
    {activeAudioWarning && <div className="player-audio-warning"><AlertCircle size={13} /> {activeAudioWarning}</div>}
    {activeAudioTracks.length > 1 && <label className="player-audio-track"><span>Audio track</span><select aria-label="Audio track" value={activeSelectedAudioTrack} onChange={(event) => selectActiveAudioTrack(Number(event.target.value))}>{activeAudioTracks.map((track) => <option key={track.id} value={track.id}>{track.label}{track.codec ? ` · ${track.codec}` : ''}</option>)}</select></label>}
    {activeMutedAutoplay && <button className="button-ghost dark player-unmute" onClick={() => { void (isMovieActive ? unmuteMovie() : unmute()).then((started) => { if (!started) showMessage('info', 'Use the video play control to start playback with sound.'); }); }}>Enable sound</button>}
  </div>;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <button className="brand" onClick={() => setView('Library')} aria-label="StreamPilot Player home">
          <span className="brand-mark"><span /><span /><span /></span>
          <span className="brand-copy"><strong>stream<span>pilot</span></strong><small>PLAYER</small></span>
        </button>

        <div className="sidebar-label">YOUR SPACE</div>
        <nav className="nav-list" aria-label="Main navigation">
          {nav.map(({ label, icon: Icon, count }) => (
            <button key={label} className={`nav-item ${view === label ? 'active' : ''}`} onClick={() => setView(label)}>
              <Icon size={18} strokeWidth={1.8} />
              <span>{label}</span>
              {typeof count === 'number' && count > 0 && <span className="nav-count">{count}</span>}
            </button>
          ))}
        </nav>

        <div className="sidebar-divider" />
        <div className="sidebar-label">PLAYLISTS</div>
        <button className="playlist-side-item" onClick={() => setModal('playlist')}>
          <span className="playlist-dot purple"><ListVideo size={15} /></span>
          <span className="playlist-side-name">{playlistName || 'Add a playlist'}</span>
          <Plus size={16} />
        </button>
        {groups.slice(0, 4).map((group) => <div className="group-row" key={group}><span className="group-dot" />{group}</div>)}

        <div className="sidebar-bottom">
          <div className="status-mini"><span className="status-light" /><span>Player prototype</span></div>
          <button className="nav-item subtle" onClick={() => showMessage('info', 'Settings, account sync, activation API and multi-device management are part of the next implementation phase.')}><Settings2 size={18} /><span>Settings</span></button>
          <div className="sidebar-footnote">V1 FOUNDATION · LOCAL MODE</div>
        </div>
      </aside>

      <main className="main-panel">
        <header className="topbar">
          <div className="mobile-brand"><span className="brand-mark"><span /><span /><span /></span><strong>stream<span>pilot</span></strong></div>
          <div className="breadcrumb"><span>Player</span><span className="crumb-slash">/</span><strong>{view}</strong></div>
          <div className="topbar-actions">
            <label className="searchbox"><Search size={17} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search your library" aria-label="Search your library" /><kbd>⌘ K</kbd></label>
            <button className="activation-pill" onClick={() => setModal('activation')}><KeyRound size={15} /><span>Activate Player</span><span className="unverified-dot" /></button>
            <button className="avatar-button" onClick={() => showMessage('info', 'Account sync will be added with the secure StreamPilot activation API.')} aria-label="Account details">SP</button>
          </div>
        </header>

        <div className="content-wrap">
          {notice && <div className={`notice ${notice.type}`} role="status"><span className="notice-icon">{notice.type === 'success' ? <Check size={16} /> : notice.type === 'error' ? <AlertCircle size={16} /> : <CircleHelp size={16} />}</span><span>{notice.text}</span><button onClick={() => setNotice(null)} aria-label="Dismiss message"><X size={15} /></button></div>}

          {view === 'Live TV' ? <LiveTvWorkspace
            library={playlistLibrary}
            onLibraryChange={updatePlaylistLibrary}
            onAddPlaylist={() => setModal('playlist')}
            onChooseChannel={(item) => void chooseItem(item)}
            busy={importBusy}
          /> : view === 'Movies' ? <section className="vod-workspace" aria-labelledby="vod-heading">
            <div className="section-head"><div><div className="section-eyebrow">XTREAM VOD CATALOGUE</div><h1 id="vod-heading">Movies</h1><p>Categories and movie metadata load only when you open them. Playback uses a short-lived, session-bound media grant.</p></div></div>
            {!vodAvailable ? <div className="empty-state"><div className="empty-illustration"><Film size={33} /></div><h3>Movie catalogue unavailable</h3><p>Import an authorised Xtream get.php playlist to browse its server-held movie catalogue.</p></div> : <div className="vod-layout">
              <aside className="vod-categories" aria-label="Movie categories">
                <div className="vod-panel-label">CATEGORIES</div>
                {vodCategoriesLoading && <p className="vod-status">Loading categories…</p>}
                {!vodCategoriesLoading && vodCategories.map((category) => <button key={category.id} className={`vod-category ${vodCategoryId === category.id ? 'is-active' : ''}`} onClick={() => void loadVodMovies(category.id)} disabled={vodMoviesLoading}>{category.name}</button>)}
                {!vodCategoriesLoading && !vodCategories.length && !vodError && <p className="vod-status">No movie categories were returned.</p>}
              </aside>
              <div className="vod-items">
                <div className="vod-panel-label">{vodCategoryId ? (vodCategories.find((category) => category.id === vodCategoryId)?.name ?? 'MOVIES') : 'SELECT A CATEGORY'}</div>
                {vodError && <div className="player-error"><AlertCircle size={15} /> {vodError}</div>}
                {vodMoviesLoading && <p className="vod-status">Loading movie metadata…</p>}
                {!vodMoviesLoading && vodCategoryId && <><div className="vod-grid">
                  {visibleVodMovies.map((movie) => <button className={`vod-card ${movieSelected?.id === movie.id ? 'is-active' : ''}`} key={movie.id} onClick={() => void chooseMovie(movie)} disabled={movieGrantBusy}>
                    <div className="vod-art">{movie.icon ? <img src={movie.icon} alt="" onError={(event) => { event.currentTarget.style.display = 'none'; }} /> : <Film size={25} />}</div>
                    <div><strong title={movie.name}>{movie.name}</strong><small>{[movie.year, movie.rating ? `Rating ${movie.rating}` : undefined].filter(Boolean).join(' · ') || 'Provider metadata'}</small></div>
                  </button>)}
                </div>{!visibleVodMovies.length && <p className="vod-status">No matching movie metadata was returned.</p>}
                {vodHasMore && <button className="button-ghost dark" onClick={() => vodCategoryId && void loadVodMovies(vodCategoryId, vodMovies.length)} disabled={vodMoviesLoading}>Load more movies</button>}</>}
                {!vodCategoryId && !vodMoviesLoading && <p className="vod-status">Choose a category to load up to {VOD_PAGE_SIZE} movie records.</p>}
              </div>
            </div>}
            {moviePlayer.visible && <section className="movie-player" aria-label="Movie player">
              <div><div className="vod-panel-label">NOW PLAYING</div><strong>{moviePlayer.title}</strong></div>
              {moviePlayer.loading && <p className="vod-status">Authorizing and loading movie…</p>}
              {moviePlayer.error && <div className="player-error"><AlertCircle size={15} /> {moviePlayer.error}</div>}
              {movieMutedAutoplay && <button className="button-ghost dark" onClick={() => { void unmuteMovie().then((started) => { if (!started) showMessage('info', 'Use the movie controls to start playback with sound.'); }); }}>Unmute</button>}
            </section>}
            <div className="library-bottom-hint"><span><ShieldCheck size={14} /> Movie metadata stays separate from playback authorization.</span><span>Playback is restricted to a short-lived, session-bound media route.</span></div>
          </section> : view === 'Series' && seriesAvailable ? <section className="vod-workspace" aria-labelledby="series-heading">
            <div className="section-head"><div><div className="section-eyebrow">XTREAM SERIES CATALOGUE</div><h1 id="series-heading">Series</h1><p>Browse shows, seasons and episodes from your authorised provider. Episode URLs remain server-side.</p></div></div>
            <div className="vod-layout">
              <aside className="vod-categories" aria-label="Series categories"><div className="vod-panel-label">CATEGORIES</div>{seriesLoading && !seriesCategories.length && <p className="vod-status">Loading categories…</p>}{seriesCategories.map((category) => <button key={category.id} className={`vod-category ${seriesCategoryId === category.id ? 'is-active' : ''}`} onClick={() => void loadSeriesItems(category.id)} disabled={seriesLoading}>{category.name}</button>)}{!seriesLoading && !seriesCategories.length && !seriesError && <p className="vod-status">This provider returned no series categories.</p>}</aside>
              <div className="vod-items"><div className="vod-panel-label">{seriesSelected?.name ?? (seriesCategoryId ? seriesCategories.find((category) => category.id === seriesCategoryId)?.name : 'SELECT A CATEGORY')}</div>
                {seriesError && <div className="player-error"><AlertCircle size={15} /> {seriesError}</div>}
                {seriesLoading && <p className="vod-status">Loading series information…</p>}
                {!seriesSelected && <div className="vod-grid">{seriesItems.map((series) => <button className="vod-card" key={series.id} onClick={() => void chooseSeries(series)} disabled={seriesLoading}><div className="vod-art">{series.icon ? <img src={series.icon} alt="" onError={(event) => { event.currentTarget.style.display = 'none'; }} /> : <Clapperboard size={25} />}</div><div><strong title={series.name}>{series.name}</strong><small>{series.year ?? 'Series'}</small></div></button>)}</div>}{!seriesSelected && seriesHasMore && <button className="button-ghost dark" onClick={() => seriesCategoryId && void loadSeriesItems(seriesCategoryId, seriesItems.length)} disabled={seriesLoading}>Load more series</button>}
                {seriesSelected && <><button className="button-ghost dark" onClick={() => setSeriesSelected(undefined)}>← Back to series</button>{[...new Set(seriesEpisodes.map((episode) => episode.season))].sort((a,b) => Number(a)-Number(b)).map((season) => <section key={season} className="series-season"><h3>{seriesEpisodes.find((episode) => episode.season === season)?.seasonName ?? `Season ${season}`}</h3><div className="series-episode-list">{seriesEpisodes.filter((episode) => episode.season === season).map((episode) => <button className="vod-category" key={episode.id} onClick={() => void chooseEpisode(episode)} disabled={movieGrantBusy}><span>{episode.episodeNumber ? `Episode ${episode.episodeNumber} · ` : ''}{episode.title}</span></button>)}</div></section>)}{!seriesEpisodes.length && !seriesLoading && <p className="vod-status">No episodes were returned for this series.</p>}</>}
                {!seriesSelected && !seriesItems.length && !seriesLoading && seriesCategoryId && <p className="vod-status">No series were returned for this category.</p>}
                {!seriesCategoryId && !seriesLoading && <p className="vod-status">Choose a category to browse available shows.</p>}
              </div>
            </div>
            {moviePlayer.visible && <section className="movie-player" aria-label="Episode player"><div><div className="vod-panel-label">NOW PLAYING</div><strong>{moviePlayer.title}</strong></div>{moviePlayer.loading && <p className="vod-status">Authorizing and loading episode…</p>}{moviePlayer.error && <div className="player-error"><AlertCircle size={15} /> {moviePlayer.error}</div>}</section>}
          </section> : <>

          <section className="welcome-row">
            <div>
              <div className="eyebrow"><Sparkles size={14} /> YOUR ENTERTAINMENT, ORGANIZED</div>
              <h1>One place for your <span>playlists.</span></h1>
              <p>Connect your own playlist, discover what’s inside, and play your authorized streams.</p>
            </div>
            <div className="local-badge"><span className="live-dot" />LOCAL PROTOTYPE</div>
          </section>

          <section className="hero-layout">
            <div className="hero-copy-card">
              <div className="hero-orb orb-one" /><div className="hero-orb orb-two" /><div className="hero-grid" />
              <div className="hero-card-inner">
                <div className="hero-kicker"><span className="kicker-mark"><Activity size={13} /></span> STREAM WITHOUT THE CLUTTER</div>
                <h2>Your content.<br /><em>Your way.</em></h2>
                <p>Bring your own M3U playlist into a cleaner, more focused player experience. Your content stays yours.</p>
                <div className="hero-actions">
                  <button className="button-primary" onClick={() => setModal('playlist')}><Upload size={16} /> Import playlist <ArrowRight size={15} /></button>
                  <button className="button-ghost" onClick={() => setModal('xtream')}><Plus size={16} /> Connect Xtream</button>
                </div>
                <div className="hero-trust"><ShieldCheck size={15} /> Designed around your playlists and your devices</div>
              </div>
            </div>

          </section>

          <section className="stat-strip">
            <div className="stat"><span className="stat-icon lavender"><ListVideo size={17} /></span><div><strong>{items.length}</strong><span>Playlist entries</span></div></div>
            <div className="stat"><span className="stat-icon blue"><FolderOpen size={17} /></span><div><strong>{groups.length}</strong><span>Categories found</span></div></div>
            <div className="stat"><span className="stat-icon rose"><Heart size={17} /></span><div><strong>{favorites.length}</strong><span>Favorites</span></div></div>
            <div className="stat stat-right"><span className="stat-icon green"><Wifi size={17} /></span><div><strong>Local</strong><span>Data mode</span></div></div>
          </section>

          <section className="library-section">
            <div className="section-head"><div><div className="section-eyebrow">YOUR COLLECTION</div><h2>{view === 'Library' ? 'From your library' : view}</h2><p>{view === 'Library' ? 'Pick up where you left off or choose a stream to start.' : `Browse ${view.toLowerCase()} entries from your imported playlist.`}</p></div><div className="section-tools"><span className="result-count">{visibleItems.length} {visibleItems.length === 1 ? 'item' : 'items'}</span>{visibleItems.length > COMPACT_CHANNEL_COUNT && <button className="sort-button" onClick={() => setVisibleLimit((current) => current < visibleItems.length ? Math.min(current + CHANNEL_PAGE_SIZE, visibleItems.length) : COMPACT_CHANNEL_COUNT)}>{remainingItems > 0 ? `Show ${Math.min(remainingItems, CHANNEL_PAGE_SIZE)} more` : 'Compact view'} <ChevronDown size={15} /></button>}<button className="icon-button more-button" onClick={() => setModal('playlist')} aria-label="More playlist options"><MoreHorizontal size={19} /></button></div></div>

            {visibleItems.length > 0 ? <div className="channel-grid">
              {renderedItems.map((item, index) => (
                <article className={`channel-card ${selected?.id === item.id ? 'selected' : ''}`} key={item.id}>
                  <button className="channel-main" onClick={() => void chooseItem(item)}>
                    <div className={`channel-art art-${index % 5}`}>
                      {item.logo ? <img src={item.logo} alt="" onError={(e) => { e.currentTarget.style.display = 'none'; }} /> : <span className="art-graphic"><Tv2 size={27} strokeWidth={1.3} /></span>}
                      <span className="art-tag">{item.kind === 'unknown' ? 'PLAYLIST' : item.kind.toUpperCase()}</span>
                      {selected?.id === item.id && <span className="selected-chip"><Check size={12} /> SELECTED</span>}
                    </div>
                    <div className="channel-card-body"><strong title={item.name}>{item.name}</strong><span>{item.group}</span><div className="channel-card-foot"><span className="stream-state"><span /> Source added</span><span className="channel-duration">{item.url.toLowerCase().includes('.m3u8') ? 'HLS' : 'STREAM'}</span></div></div>
                  </button>
                  <button className={`card-favorite ${favorites.includes(item.id) ? 'is-favorite' : ''}`} onClick={() => toggleFavorite(item)} aria-label={favorites.includes(item.id) ? `Remove ${item.name} from favorites` : `Add ${item.name} to favorites`}><Heart size={16} fill={favorites.includes(item.id) ? 'currentColor' : 'none'} /></button>
                </article>
              ))}
            </div> : <div className="empty-state"><div className="empty-illustration"><ListVideo size={33} /></div><h3>{view === 'Favorites' ? 'Your favorites start here' : 'Your library is ready when you are'}</h3><p>{view === 'Favorites' ? 'Tap the heart on any playlist entry to save it here.' : 'Import an M3U/M3U8 file or load a public test stream to check the player.'}</p><div className="empty-actions"><button className="button-primary" onClick={() => setModal('playlist')}><Upload size={16} /> Import playlist</button><button className="button-ghost dark" onClick={importDemo}><Play size={15} /> Load test stream</button></div></div>}

            <div className="library-bottom-hint"><span><ShieldCheck size={14} /> StreamPilot Player does not provide a channel catalogue.</span><span>Only add playlists and streams you are authorized to use.</span></div>
          </section>

          </>}

          <footer className="prototype-footer"><div className="footer-brand"><span className="brand-mark small"><span /><span /><span /></span><strong>streampilot</strong></div><span>Player foundation · v0.1.0</span><span className="footer-separator">•</span><span>Activation and account sync not connected</span><button onClick={() => showMessage('info', 'This first build is a local proof of concept. The next phases are Xtream server integration, activation API, and platform-specific clients.')}><CircleHelp size={14} /> What is prototype mode?</button></footer>
        </div>
      </main>

      <aside className="persistent-player-dock" aria-label="Persistent media player">{playerPreview}</aside>

      {modal && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setModal(null); }}>
        <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="modal-title">
          <button className="modal-close" onClick={() => setModal(null)} aria-label="Close modal"><X size={19} /></button>
          {modal === 'playlist' && <>
            <div className="modal-icon"><Upload size={21} /></div><div className="modal-eyebrow">PLAYLIST SETUP</div><h2 id="modal-title">Bring your playlist</h2><p className="modal-description">Load your own M3U or M3U8 playlist. In this prototype, playlist entries remain in memory and are cleared when you refresh.</p>
            <button className="upload-dropzone" disabled={importBusy} onClick={() => fileInput.current?.click()}><span className="upload-cloud"><ArrowDownToLine size={23} /></span><strong>Choose a playlist file</strong><span>Browse for .m3u, .m3u8 or .txt</span><span className="upload-button-label">Browse files</span></button>
            <input ref={fileInput} className="visually-hidden" type="file" accept=".m3u,.m3u8,.txt,audio/x-mpegurl,application/vnd.apple.mpegurl" disabled={importBusy} onChange={(e) => void loadFile(e.target.files?.[0])} />
            <div className="modal-divider"><span>REMOTE M3U / M3U8</span></div>
            <p className="field-help">The URL is sent only to this app&apos;s same-origin connector for validation and import. Do not share playlist URLs that contain credentials.</p>
            <label className="field-label" htmlFor="remote-playlist-name">Playlist name</label><input id="remote-playlist-name" className="text-field" value={remotePlaylistName} onChange={(event) => setRemotePlaylistName(event.target.value)} placeholder="me" maxLength={120} />
            <label className="field-label" htmlFor="remote-playlist-url">Full playlist URL</label><input id="remote-playlist-url" className="text-field" value={remotePlaylistUrl} onChange={(event) => setRemotePlaylistUrl(event.target.value)} placeholder="https:// or http:// provider playlist URL" inputMode="url" autoComplete="off" />
            <button className="button-primary full-width" disabled={importBusy} onClick={() => void loadRemotePlaylist()}>{importBusy ? 'Importing…' : 'Import remote playlist'} <ArrowRight size={16} /></button>
            <div className="modal-divider"><span>XTREAM CODES</span></div><p className="field-help">Use the existing secure Xtream connector for authorised provider credentials.</p>
            <button className="button-ghost dark full-width" disabled={importBusy} onClick={() => setModal('xtream')}><Signal size={15} /> Connect Xtream Codes</button>
            <button className="button-text" disabled={importBusy} onClick={importDemo}><Play size={14} /> Load public HLS test stream instead</button>
          </>}
          {modal === 'xtream' && <>
            <div className="modal-icon blue-icon"><Signal size={21} /></div><div className="modal-eyebrow">PROVIDER CONNECTION</div><h2 id="modal-title">Connect Xtream Codes</h2><p className="modal-description">Credentials are sent only to this app&apos;s same-origin connector for this request. They are not stored in this prototype and are cleared from the password field after the request.</p>
            <label className="field-label" htmlFor="xtream-server">Server URL</label><input id="xtream-server" className="text-field" value={xtreamServer} onChange={(event) => setXtreamServer(event.target.value)} placeholder="https:// or http:// provider server:port" autoComplete="url" />
            <label className="field-label" htmlFor="xtream-user">Username</label><input id="xtream-user" className="text-field" value={xtreamUsername} onChange={(event) => setXtreamUsername(event.target.value)} placeholder="Provider username" autoComplete="username" />
            <label className="field-label" htmlFor="xtream-password">Password</label><input id="xtream-password" className="text-field" value={xtreamPassword} onChange={(event) => setXtreamPassword(event.target.value)} type="password" placeholder="Provider password" autoComplete="current-password" />
            <div className="security-note"><ShieldCheck size={16} /><span>HTTP and HTTPS are supported. HTTP is unencrypted and can expose your username, password, playlist and stream traffic; the app asks you to confirm before connecting.</span></div>
            <button className="button-primary full-width" disabled={importBusy} onClick={() => void loadXtream()}>{importBusy ? 'Connecting…' : 'Import provider metadata'} <ArrowRight size={16} /></button>
          </>}
          {modal === 'activation' && <>
            <div className="modal-icon violet-icon"><KeyRound size={21} /></div><div className="modal-eyebrow">STREAM PILOT LICENSE</div><h2 id="modal-title">Activate your Player</h2><p className="modal-description">The website activation service has not been connected yet. This screen shows the planned activation step; it will not validate or activate a license in this build.</p>
            <label className="field-label" htmlFor="activation-code">Activation code</label><input id="activation-code" className="text-field code-field" placeholder="XXXX-XXXX-XXXX" autoComplete="off" />
            <div className="security-note"><ShieldCheck size={16} /><span>Production activation will validate the code, license state, expiry and device limit on the server.</span></div>
            <button className="button-primary full-width" onClick={() => { setModal(null); showMessage('info', 'Activation is only a planned UI step. No code was validated, and no device was linked.'); }}>Continue <ArrowRight size={16} /></button>
          </>}
        </section>
      </div>}
    </div>
  );
}

export default App;
