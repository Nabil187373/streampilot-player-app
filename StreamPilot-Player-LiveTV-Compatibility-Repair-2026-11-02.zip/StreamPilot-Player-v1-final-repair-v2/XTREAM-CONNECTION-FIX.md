# Xtream connection flow correction

The **Connect Xtream Codes** action now calls the Xtream `player_api.php` endpoints (`get_live_categories` and `get_live_streams`) rather than treating the connection as an M3U `get.php` download. This is required to create the server-held catalogue descriptor used by the lazy VOD and Series catalogue APIs.

M3U file and remote-M3U imports remain separate workflows. They continue to parse playlist entries and do not claim that an M3U file automatically provides a server-side Xtream VOD catalogue.

## Verification in the build environment

- Backend Node tests: 103 passed, 0 failed, 1 skipped (local X.509 fixture unavailable).
- TypeScript: `tsc --noEmit` passed.
- Vite/Vitest execution could not be completed in this build environment because the available dependency tree lacks the Rolldown native optional binding. Reinstall dependencies on the target Windows machine before running the full test and production build commands.
